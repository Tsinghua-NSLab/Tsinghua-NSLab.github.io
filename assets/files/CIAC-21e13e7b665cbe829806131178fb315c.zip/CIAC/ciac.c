/*
**   $Id: ciac.c,v2
** 
**   ciac.c
**
*/  
  
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
  
#include "ciac.h"

#include <time.h>
  
/*
*
*/ 
#define MEMASSERT(p,s) if(!p){printf("ciac-No Memory: %s!\n",s);exit(0);}

/*
*
*/ 
static int max_memory = 0;
static int match_number = 0;

static int ciac_dfa_size = 0;
static int ciac_match_item_size = 0;

static int s_verbose=0;

/*
*
*/ 
typedef struct ciac_summary_s
{
      unsigned    num_states;
      unsigned    num_transitions;
      CIAC_STRUCT ciac;

}ciac_summary_t;

/*
*
*/ 
static ciac_summary_t summary={0,0}; 

/*
** Case Translation Table 
*/ 
static unsigned char xlatcase[256];
/*
*
*/ 
void ciacPrintSummaryInfo()
{
	printf("CIAC DFA size = %.2f KB\n",(float)ciac_dfa_size/1024);
       printf("ciac match_item_size = %.2f KB\n",(float)ciac_match_item_size/1024);
}

static
void
init_xlatcase() 
{
  int i;
  for (i = 0; i < 256; i++)
    {
      xlatcase[i] = toupper(i);
    }
}
/*
*    Case Conversion
*/ 
static 
inline 
void
ConvertCaseEx (unsigned char *d, unsigned char *s, int m) 
{
  int i;
  for (i=0; i < m; i++)
    {
      d[i] = xlatcase[ s[i] ];
    }
}

/*
*
*/ 
static void *
CIAC_MALLOC (int n) 
{
  void *p;
  p = malloc (n);
  if (p)
    max_memory += n;
  return p;
}


/*
*
*/ 
static void
CIAC_FREE (void *p) 
{
  if (p)
    free (p);
}


/*
*    Simple QUEUE NODE
*/ 
typedef struct _qnode
{
  int state;
   struct _qnode *next;
}
QNODE;

/*
*    Simple QUEUE Structure
*/ 
typedef struct _queue
{
  QNODE * head, *tail;
  int count;
}
QUEUE;

/*
*   Initialize the queue
*/ 
static void
queue_init (QUEUE * s) 
{
  s->head = s->tail = 0;
  s->count= 0;
}

/*
*  Find a State in the queue
*/ 
static int
queue_find (QUEUE * s, int state) 
{
  QNODE * q;
  q = s->head;
  while( q )
  {
      if( q->state == state ) return 1;
      q = q->next;
  }
  return 0;
}

/*
*  Add Tail Item to queue (FiFo/LiLo)
*/ 
static void
queue_add (QUEUE * s, int state) 
{
  QNODE * q;

  if( queue_find( s, state ) ) return;  

  if (!s->head)
  {
      q = s->tail = s->head = (QNODE *) CIAC_MALLOC (sizeof (QNODE));
      MEMASSERT (q, "queue_add");
      q->state = state;
      q->next = 0;
  }
  else
  {
      q = (QNODE *) CIAC_MALLOC (sizeof (QNODE));
      q->state = state;
      q->next = 0;
      s->tail->next = q;
      s->tail = q;
  }
  s->count++;
}


/*
*  Remove Head Item from queue
*/ 
static int
queue_remove (QUEUE * s) 
{
  int state = 0;
  QNODE * q;
  if (s->head)
  {
      q       = s->head;
      state   = q->state;
      s->head = s->head->next;
      s->count--;

      if( !s->head )
      {
	  s->tail = 0;
	  s->count = 0;
      }
      CIAC_FREE (q);
  }
  return state;
}


/*
*   Return items in the queue
*/ 
static int
queue_count (QUEUE * s) 
{
  return s->count;
}


/*
*  Free the queue
*/ 
static void
queue_free (QUEUE * s) 
{
  while (queue_count (s))
    {
      queue_remove (s);
    }
}

/*
*  Get Next State-NFA
*/
static 
int List_GetNextState( CIAC_STRUCT * ciac, int state, unsigned int input )
{
  ciac_trans_node_t * t = ciac->ciacTransTable[state];

  while( t )
  {
    if( t->key == input )
    {
        return t->next_state;
    }
    t=t->next;
  }

  if( state == 0 ) return 0;
  
  return CIAC_FAIL_STATE; /* Fail state ??? */
}

/*
*  Get Next State-DFA
*/
static 
int List_GetNextState2( CIAC_STRUCT * ciac, int state, unsigned int input )
{
  ciac_trans_node_t * t = ciac->ciacTransTable[state];

  while( t )
  {
    if( t->key == input )
    {
      return t->next_state;
    }
    t = t->next;
  }

  return 0; /* default state */
}
/*
*  Put Next State - Head insertion, and transition updates
*/
static 
int List_PutNextState( CIAC_STRUCT * ciac, int state, unsigned int input, int next_state )
{
  ciac_trans_node_t * p;
  ciac_trans_node_t * tnew;

 // printf("   List_PutNextState: state=%d, input='%c', next_state=%d\n",state,input,next_state);


  /* Check if the transition already exists, if so just update the next_state */
  p = ciac->ciacTransTable[state];
  while( p )
  {
    if( p->key == input )  /* transition already exists- reset the next state */
    {
        p->next_state = next_state;
        return 0;    
    }
    p=p->next;
  }

  /* Definitely not an existing transition - add it */
  tnew = (ciac_trans_node_t*) CIAC_MALLOC(sizeof(ciac_trans_node_t));
  if( !tnew ) return -1; 

  tnew->key        = input;
  tnew->next_state = next_state;
  tnew->next       = 0;

  tnew->next = ciac->ciacTransTable[state];
  ciac->ciacTransTable[state] = tnew; 

  ciac->ciacNumTrans++;
  
  return 0; 
}

/*
*   Free the ciac pattern list 
*/
static 
int List_FreePatternList( CIAC_STRUCT * ciac )
{
  CIAC_PATTERN *p;

  if( !ciac->ciacPatterns) return 0;

  while(ciac->ciacPatterns)
  {
      p=ciac->ciacPatterns;
      ciac->ciacPatterns=p->next;
      //free(p->patrn);
      //free(p->casepatrn);
      //free(p->id);
      free(p);
  }

   return 0;
}

/*
*   Free the entire transition table 
*/
static 
int List_FreeTransTable( CIAC_STRUCT * ciac )
{
  int i;
  ciac_trans_node_t * t, *p;

  if( !ciac->ciacTransTable ) return 0;

  for(i=0;i< ciac->ciacMaxStates;i++)
  {  
     t = ciac->ciacTransTable[i];

     while( t )
     {
       p = t->next;
       free(t);      
       t = p;
       max_memory -= sizeof(ciac_trans_node_t);
     }
   }

   free(ciac->ciacTransTable);

   max_memory -= sizeof(void*) * ciac->ciacMaxStates;

   ciac->ciacTransTable = 0;

   return 0;
}


/*
*    Print the trans table to stdout
*/
static 
int List_PrintTransTable( CIAC_STRUCT * ciac )
{
  int i;
  ciac_trans_node_t * t;
  CIAC_PATTERN * patrn;

  if( !ciac->ciacTransTable ) return 0;

  printf("Print Transition Table- %d active states\n",ciac->ciacNumStates);

  for(i=0;i< ciac->ciacNumStates;i++)
  {  
     t = ciac->ciacTransTable[i];

     printf("state %3d: ",i);

     while( t )
     { 
       if( isprint(t->key) )
         printf("%3c->%-5d\t",t->key,t->next_state);
       else
         printf("%3d->%-5d\t",t->key,t->next_state);

       t = t->next;
     }

     patrn =ciac->ciacMatchList[i];

     while( patrn )
     {
         printf("%.*s ",patrn->n,patrn->patrn);
 
         patrn = patrn->next;
     }

     printf("\n");
   }
   return 0;
}


/*
*   Converts row of states from list to a full vector format
*/ 
static 
int List_ConvToFull(CIAC_STRUCT * ciac, ciac_state_t state, ciac_state_t * full )
{
    int tcnt = 0;
    ciac_trans_node_t * t = ciac->ciacTransTable[ state ];

    memset(full,0,sizeof(ciac_state_t)*ciac->ciacAlphabetSize);
   
    if( !t ) return 0;

    while(t)
    {
      full[ t->key ] = t->next_state;
      tcnt++;
      t = t->next;
    }
    return tcnt;
}

/*
*   Copy a Match List Entry - don't dup the pattern data
*/ 
static CIAC_PATTERN*
CopyMatchListEntry (CIAC_PATTERN * px) 
{
  CIAC_PATTERN * p;

  p = (CIAC_PATTERN *) CIAC_MALLOC (sizeof (CIAC_PATTERN));
  ciac_match_item_size += sizeof (CIAC_PATTERN);
  MEMASSERT (p, "CopyMatchListEntry");

  memcpy (p, px, sizeof (CIAC_PATTERN));

  p->next = 0;

  return p;
}


/*
*  Add a pattern to the list of patterns terminated at this state.
*  Insert at front of list.
*/ 
static void
AddMatchListEntry (CIAC_STRUCT * ciac, int state, CIAC_PATTERN * px) 
{
  CIAC_PATTERN * p;

  p = (CIAC_PATTERN *) CIAC_MALLOC (sizeof (CIAC_PATTERN));
  ciac_match_item_size += sizeof (CIAC_PATTERN);
  
  MEMASSERT (p, "AddMatchListEntry");

  memcpy (p, px, sizeof (CIAC_PATTERN));

  p->next = ciac->ciacMatchList[state];

  ciac->ciacMatchList[state] = p;
}


static void
AddPatternStates (CIAC_STRUCT * ciac, CIAC_PATTERN * p) 
{
  int            state, next, n;
  unsigned char *pattern;

  n       = p->n;
  pattern = p->patrn;
  state   = 0;

  if(0)printf(" Begin AddPatternStates: ciacNumStates=%d\n",ciac->ciacNumStates);
  if(0)printf("    adding '%.*s', nocase=%d\n", n,p->patrn, p->nocase );
  
  /* 
  *  Match up pattern with existing states
  */ 
  for (; n > 0; pattern++, n--)
  {
      if(s_verbose)printf(" find char='%c'\n", *pattern );

      next = List_GetNextState(ciac,state,*pattern);
      if (next == CIAC_FAIL_STATE || next == 0)
	 {
             break;
	 }
      state = next;
  }
  
  /*
  *   Add new states for the rest of the pattern bytes, 1 state per byte
  */ 
  for (; n > 0; pattern++, n--)
  {
      if(s_verbose)printf(" add char='%c' state=%d NumStates=%d\n", *pattern, state, ciac->ciacNumStates );

      ciac->ciacNumStates++; 
      List_PutNextState(ciac,state,*pattern,ciac->ciacNumStates);
      state = ciac->ciacNumStates;
  }

  AddMatchListEntry (ciac, state, p );

  if(s_verbose)printf(" End AddPatternStates: ciacNumStates=%d\n",ciac->ciacNumStates);
}

/*
*   Build A Non-Deterministic Finite Automata
*   The keyword state table must already be built, via AddPatternStates().
*/ 
static void
Build_NFA (CIAC_STRUCT * ciac) 
{
    int r, s, i;
    QUEUE q, *queue = &q;
    ciac_state_t     * FailState = ciac->ciacFailState;
    CIAC_PATTERN ** MatchList = ciac->ciacMatchList;
    CIAC_PATTERN  * mlist,* px;
  
    /* Init a Queue */ 
    queue_init (queue);

  
    /* Add the state 0 transitions 1st, the states at depth 1, fail to state 0 */ 
    for (i = 0; i < ciac->ciacAlphabetSize; i++)
    {
      s = List_GetNextState2(ciac,0,i);
      if( s )
      {
	  queue_add (queue, s);
	  FailState[s] = 0;
      }
    }
  
    /* Build the fail state successive layer of transitions */ 
    while (queue_count (queue) > 0)
    {
        r = queue_remove (queue);
      
	/* Find Final States for any Failure */ 
	for (i = 0; i < ciac->ciacAlphabetSize; i++)
	{
           int fs, next;

           s = List_GetNextState(ciac,r,i);

           if( s != CIAC_FAIL_STATE )
	   { 
                queue_add (queue, s);
 
	        fs = FailState[r];

		/* 
		 *  Locate the next valid state for 'i' starting at fs 
		 */ 
		while( (next=List_GetNextState(ciac,fs,i)) == CIAC_FAIL_STATE )
		{
		  fs = FailState[fs];
		}
	      
		/*
		 *  Update 's' state failure state to point to the next valid state
		 */ 
		FailState[s] = next;
	      
		/*
		 *  Copy 'next'states MatchList to 's' states MatchList, 
		 *  we copy them so each list can be CIAC_FREE'd later,
		 *  else we could just manipulate pointers to fake the copy.
		 */ 
		for( mlist = MatchList[next]; 
                     mlist;
		     mlist = mlist->next)
		{
		    px = CopyMatchListEntry (mlist);
  
		    /* Insert at front of MatchList */ 
		    px->next = MatchList[s];
		    MatchList[s] = px;
		}
	    }
	}
    }
  
    /* Clean up the queue */ 
    queue_free (queue);

    if( s_verbose)printf("End Build_NFA: NumStates=%d\n",ciac->ciacNumStates);
}

/*
*   Build Deterministic Finite Automata from the NFA
*/ 
static void
Convert_NFA_To_DFA (CIAC_STRUCT * ciac) 
{
    int i, r, s, cFailState;
    QUEUE  q, *queue = &q;
    ciac_state_t * FailState = ciac->ciacFailState;
  
    /* Init a Queue */
    queue_init (queue);
  
    /* Add the state 0 transitions 1st */
    for(i=0; i<ciac->ciacAlphabetSize; i++)
    {
      s = List_GetNextState(ciac,0,i);
      if ( s != 0 )
      {
	  queue_add (queue, s);
      }
    }
  
    /* Start building the next layer of transitions */
    while( queue_count(queue) > 0 )
    {
        r = queue_remove(queue);
      
	/* Process this states layer */ 
	for (i = 0; i < ciac->ciacAlphabetSize; i++)
	{
	  s = List_GetNextState(ciac,r,i);

	  if( s != CIAC_FAIL_STATE && s!= 0)
	  {
	      queue_add (queue, s);
	  }
	  else
	  {
              cFailState = List_GetNextState(ciac,FailState[r],i);

              if( cFailState != 0 && cFailState != CIAC_FAIL_STATE )
              {
                  List_PutNextState(ciac,r,i,cFailState);
              }
	  }
	}
    }
  
    /* Clean up the queue */ 
    queue_free (queue);

    if(s_verbose)printf("End Convert_NFA_To_DFA: NumStates=%d\n",ciac->ciacNumStates);

}

/*
*
*  Convert a row lists for the state table to a full vector format
*
*/
static int 
Conv_List_To_Full(CIAC_STRUCT * ciac) 
{
  int         tcnt, k;
  ciac_state_t * p;
  ciac_state_t ** NextState = ciac->ciacNextState;

  for(k=0;k<ciac->ciacMaxStates;k++)
  {
    p = CIAC_MALLOC( sizeof(ciac_state_t) * (ciac->ciacAlphabetSize+2) );
    if(!p) return -1;

    tcnt = List_ConvToFull( ciac, (ciac_state_t)k, p+2 );

    NextState[k] = p; /* now we have a full format row vector  */
  }

  return 0;
}
/*
*  Create a new AC state machine
*/ 
CIAC_STRUCT * ciacNew () 
{
  CIAC_STRUCT * p;

  init_xlatcase ();

  p = (CIAC_STRUCT *) CIAC_MALLOC (sizeof (CIAC_STRUCT));
  MEMASSERT (p, "ciacNew");
  ciac_match_item_size += sizeof (CIAC_STRUCT);

  if (p)
  {
    memset (p, 0, sizeof (CIAC_STRUCT));

    // Some defaults
    p->ciacAlphabetSize      = 256;
  }
  
  return p;
}
/*
*   Add a pattern to the list of patterns for this state machine
*
*/ 
int
ciacAddPattern (CIAC_STRUCT * p, unsigned char *pat, int n, int nocase,
		int offset, int depth, void * id, int iid) 
{
  CIAC_PATTERN * plist;

  plist = (CIAC_PATTERN *) CIAC_MALLOC (sizeof (CIAC_PATTERN));
  MEMASSERT (plist, "ciacAddPattern");

  plist->patrn = (unsigned char *) CIAC_MALLOC ( n );
  MEMASSERT (plist->patrn, "ciacAddPattern");

  ConvertCaseEx(plist->patrn, pat, n);
  
  plist->casepatrn = (unsigned char *) CIAC_MALLOC ( n );
  MEMASSERT (plist->casepatrn, "ciacAddPattern");
  
  memcpy (plist->casepatrn, pat, n);
 // printf("%.*s\"",n,plist->casepatrn);
  plist->n      = n;
  plist->nocase = nocase;
  plist->offset = offset;
  plist->depth  = depth;
  plist->id     = id;
  plist->iid    = iid;

  plist->next     = p->ciacPatterns;
  p->ciacPatterns = plist;

  return 0;
}
/*
*   Add a Key to the list of key+data pairs
*/ 
int ciacAddKey(CIAC_STRUCT * p, unsigned char *key, int klen, int nocase, void * data)
{
  CIAC_PATTERN * plist;

  plist = (CIAC_PATTERN *) CIAC_MALLOC (sizeof (CIAC_PATTERN));
  MEMASSERT (plist, "ciacAddPattern");
 
  plist->patrn = (unsigned char *) CIAC_MALLOC (klen);
  memcpy (plist->patrn, key, klen);

  plist->casepatrn = (unsigned char *) CIAC_MALLOC (klen);
  memcpy (plist->casepatrn, key, klen);

  plist->n      = klen;
  plist->nocase = nocase;
  plist->offset = 0;
  plist->depth  = 0;
  plist->id     = 0;
  plist->iid = 0;

  plist->next = p->ciacPatterns;
  p->ciacPatterns = plist;

  return 0;
}


/*
*   Compile State Machine - NFA or DFA and Full or Banded or Sparse or SparseBands
*/ 
int
ciacCompile (CIAC_STRUCT * ciac) 
{
    int               k;
    CIAC_PATTERN    * plist;
  
    /* Count number of states */ 
    for (plist = ciac->ciacPatterns; plist != NULL; plist = plist->next)
    {
     ciac->ciacMaxStates += plist->n;
    }
    ciac->ciacMaxStates++; /* one extra */

    /* Alloc a List based State Transition table */
    ciac->ciacTransTable =(ciac_trans_node_t**) CIAC_MALLOC(sizeof(ciac_trans_node_t*) * ciac->ciacMaxStates );
    MEMASSERT (ciac->ciacTransTable, "ciacCompile");

    memset (ciac->ciacTransTable, 0, sizeof(ciac_trans_node_t*) * ciac->ciacMaxStates);

    if(s_verbose)printf ("ciac-Max Memory-TransTable Setup: %d bytes, %d states, %d active states\n", max_memory,ciac->ciacMaxStates,ciac->ciacNumStates);

    /* Alloc a failure table - this has a failure state, and a match list for each state */
    ciac->ciacFailState =(ciac_state_t*) CIAC_MALLOC(sizeof(ciac_state_t) * ciac->ciacMaxStates );
    MEMASSERT (ciac->ciacFailState, "ciacCompile");

    memset (ciac->ciacFailState, 0, sizeof(ciac_state_t) * ciac->ciacMaxStates );

    /* Alloc a MatchList table - this has a list of pattern matches for each state, if any */
    ciac->ciacMatchList=(CIAC_PATTERN**) CIAC_MALLOC(sizeof(CIAC_PATTERN*) * ciac->ciacMaxStates );
    ciac_dfa_size += sizeof(CIAC_PATTERN*) * ciac->ciacMaxStates ;
    MEMASSERT (ciac->ciacMatchList, "ciacCompile");

    memset (ciac->ciacMatchList, 0, sizeof(CIAC_PATTERN*) * ciac->ciacMaxStates );

    if(s_verbose)printf ("ciac-Max Memory- MatchList Table Setup: %d bytes, %d states, %d active states\n", max_memory,ciac->ciacMaxStates,ciac->ciacNumStates);
 
    /* Alloc a separate state transition table == in state 's' due to event 'k', transition to 'next' state */
    ciac->ciacNextState=(ciac_state_t**)CIAC_MALLOC( ciac->ciacMaxStates * sizeof(ciac_state_t*) );
    
    MEMASSERT(ciac->ciacNextState, "ciacCompile-NextState");

    for (k = 0; k < ciac->ciacMaxStates; k++)
    {
      ciac->ciacNextState[k]=(ciac_state_t*)0;
    }

    if(s_verbose)printf ("ciac-Max Memory-Table Setup: %d bytes, %d states, %d active states\n", max_memory,ciac->ciacMaxStates,ciac->ciacNumStates);
     
    /* Initialize state zero as a branch */ 
    ciac->ciacNumStates = 0;
  
    /* Add the 0'th state,  */
    //ciac->ciacNumStates++; 
 
    /* Add each Pattern to the State Table - This forms a keywords state table  */ 
    for (plist = ciac->ciacPatterns; plist != NULL; plist = plist->next)
    {
        AddPatternStates (ciac, plist);
    }

    ciac->ciacNumStates++;

    if(s_verbose)printf ("ciac-Max Trie List Memory : %d bytes, %d states, %d active states\n", 
                 max_memory,ciac->ciacMaxStates,ciac->ciacNumStates);

    if(s_verbose)List_PrintTransTable( ciac );
  
      /* Build the NFA */
      if(s_verbose)printf("Build_NFA\n");

      Build_NFA (ciac);

      if(s_verbose)printf("NFA-Trans-Nodes: %d\n",ciac->ciacNumTrans);
      //if(s_verbose)printf("ciac-Max NFA List Memory  : %d bytes, %d states / %d active states\n", max_memory,ciac->ciacMaxStates,ciac->ciacNumStates);

      //if(s_verbose)List_PrintTransTable( ciac );
  
       /* Convert the NFA to a DFA */ 
       if(s_verbose)printf("Convert_NFA_To_DFA\n");

       Convert_NFA_To_DFA (ciac);
  
       if(s_verbose)printf("DFA-Trans-Nodes: %d\n",ciac->ciacNumTrans);
	 

      if( Conv_Full_DFA_To_CHARINDEX( ciac ) )
            return -1;

    if(s_verbose)printf ("ciac-Max Memory-Final: %d bytes, %d states, %d active states\n", max_memory,ciac->ciacMaxStates,ciac->ciacNumStates);

    /* Accrue Summary State Stats */
    summary.num_states      += ciac->ciacNumStates;
    summary.num_transitions += ciac->ciacNumTrans;

    memcpy( &summary.ciac, ciac, sizeof(CIAC_STRUCT));
    
    return 0;
}


/*
*   Free all memory
*/ 
  void
ciacFree (CIAC_STRUCT * ciac) 
{
    int k;
    CIAC_PATTERN * p;
    for(k=0;k<ciac->ciacMaxStates;k++)
  {
      while(ciac->ciacMatchList[k])
      	{
      p=ciac->ciacMatchList[k];
      ciac->ciacMatchList[k]=p->next;
	  free(p->casepatrn);
	  free(p->id);
	  free(p->patrn);
  	free(p);
      	}
  }
  free(ciac->ciacMatchList);
  for(k=0;k<ciac->ciacNumStates;k++)
  {
  	free(ciac->ciacNextState[k]);
  }
  free(ciac->ciacNextState);
  
}

/*
*   Convert DFA memory usage TO char indexed DFA 
*
*/ 
int 
Conv_Full_DFA_To_CHARINDEX(CIAC_STRUCT * ciac) 
{
  int          cnt, m, k, i,state;
  ciac_state_t  * p;
  ciac_state_t  * p1;
  ciac_state_t ** NextState = ciac->ciacNextState;
  ciac_state_t ** NS_CharIndex;
  ciac_state_t    full[MAX_ALPHABET_SIZE];
  CIAC_PATTERN ** MatchList = ciac->ciacMatchList;
  
  //convert the transnode DFA to full matrix format
  for(k=0;k<ciac->ciacMaxStates;k++)
  {

    List_ConvToFull(ciac, (ciac_state_t)k, full );

    p = malloc (sizeof(ciac_state_t)*(ciac->ciacAlphabetSize) );
       if(!p) return -1;
    memcpy(p,full,ciac->ciacAlphabetSize*sizeof(ciac_state_t));   

    NextState[k] = p; /* now we are a full formatted state transition array  */
  }

  // Free data structure do not used anymore
	 /*Free up the ciac Pattern list*/
	 List_FreePatternList(ciac);
	 /* Free up the Table Of Transition Lists */
     List_FreeTransTable( ciac );
	 /*Free up Fail state table*/
	 free(ciac->ciacFailState);

//using thre 256 matix to mark the non-zero column in standard DFA
  memset(full,0,sizeof(ciac_state_t)*ciac->ciacAlphabetSize);
  cnt=0;
  for(k=0;k<ciac->ciacAlphabetSize;k++)
  {
  	for(state=0;state<ciac->ciacNumStates;state++)
  	{
  		p=NextState[state];
		if(p[k] != 0 && p[k] != CIAC_FAIL_STATE)
		{
			full[cnt]=(ciac_state_t)k;
			cnt++;
			break;
		}
  	}
  }

  //convert to character_indexed
  NS_CharIndex = CIAC_MALLOC(sizeof(ciac_state_t*)*(ciac->ciacAlphabetSize) );
  ciac_dfa_size += sizeof(ciac_state_t*)*(ciac->ciacAlphabetSize) ;
  m = sizeof(ciac_state_t)*(ciac->ciacNumStates);
  //p = CIAC_MALLOC(m);
  //ciac_dfa_size += m;
  p = CIAC_MALLOC(m*(cnt+1));
  ciac_dfa_size += m*(cnt+1);
  printf("num states=%d\n",ciac->ciacNumStates);
  printf("num char =%d\n",cnt+1);
  for(i=0;i<ciac->ciacAlphabetSize;i++)
  	NS_CharIndex[i]=p;
  m=sizeof(ciac_state_t)*(ciac->ciacNumStates);
  memset(p,0,m);
  for(k=1;k<cnt+1;k++)
  {
  	//p = CIAC_MALLOC(m);
	//ciac_dfa_size += m;
	p = p+ciac->ciacNumStates;
	i=(int)full[k-1];
  	for(state=0;state<ciac->ciacNumStates;state++)
  	{
  		p1=NextState[state];
		p[state]=p1[i];
  	}
	NS_CharIndex[i]=p;
  }

/*free the old next state structure*/
  for(k=0;k<ciac->ciacMaxStates;k++)
  {
  	free(ciac->ciacNextState[k]);
  }
  free(ciac->ciacNextState);
  //
  ciac->ciacNextState=NS_CharIndex;
  
  return 0;
}

inline int ciacSearch(CIAC_STRUCT * ciac, unsigned char *Tx, int n,
	    int (*Match) (void * id, int index, void *data), void *data) 
{
	CIAC_PATTERN   * mlist;
	unsigned char   * Tend;
	unsigned char   * T;
	unsigned char   * Tc;
	int               index;
	ciac_state_t         state;
	//ciac_state_t       * ps; 
	//unsigned char     sindex;
	ciac_state_t      ** NextState = ciac->ciacNextState;
	CIAC_PATTERN  ** MatchList = ciac->ciacMatchList;
	int               nfound    = 0;
	int i = 0;

	T    = Tx;
	Tc   = Tx;
	Tend = Tx + n;
 
	for( state = 0; T < Tend; T++ )
	{
		//sindex = xlatcase[ T[0] ];
		state  = NextState[xlatcase[ T[0] ]][state];
		//printf("state=%d ",state);
		//ps     = NextState[sindex];
		
		// check the current state for a pattern match 
		for( mlist = MatchList[state];mlist!= NULL;mlist = mlist->next )
		{
			index = T - mlist->n - Tc +1;
			if( mlist->nocase )
			{
				nfound++;
				if (Match (mlist->id, index, data))
					return nfound;
			}
			else
			{
				if( memcmp (mlist->casepatrn, Tx + index, mlist->n ) == 0 )
				{
					nfound++;
					if (Match (mlist->id, index, data))
						return nfound;
				}
			}		
		}
		//state=ps[state];
	}

	return 0;
}

void Print_ciac(CIAC_STRUCT * ciac)
{
    ciac_state_t  ** NextState = ciac->ciacNextState;
    ciac_state_t  * p;
    int  state;
    int i;
    for(i=0;i<ciac->ciacAlphabetSize;i++)
    {
    	p=NextState[i];
	for(state=0;state<ciac->ciacNumStates;state++)
		printf("  %d",p[state]);
	printf("\n");
    }
}
//#ifdef ACSMX_MAIN

/* 
*    A Match is found
*/ 
 int
MatchFound (void* id, int index, void *data) 
{
	 match_number++;
	 return 0;
}
/*
*
*/ 
int main () 
{
  int nocase;
  CIAC_STRUCT * ciac;
  char pattern[110];
  unsigned char a;//section1: search "content"
  int len, i,j;
  char text[1024*16];
  clock_t start, finish;
  double  duration;
  FILE * my_in_file; 
  FILE * T;
  my_in_file = fopen("sr914.dat", "rb");
  T = fopen("sr914.dat", "rb");
   
  ciac = ciacNew ();
  if( !ciac )
  {
     printf("ciac-no memory\n");
     exit(0);
  }
  
  nocase = 0;
  
  len=0;
  j = 0;

  while(!feof(my_in_file))
  { 
	  fseek(my_in_file,j,0);
	  a = fgetc(my_in_file);
	  if(a=='\x17')
	  {
		  pattern[len]='\0';
		  //printf("pat=%s\n",pattern);
		  ciacAddPattern (ciac, pattern, len, nocase, 0, 0, 0, 0);
		  len=0;
	  }
	  else
	  {
		  pattern[len]=a;
		  len+=1;
	  }
	  j++;
  }
  printf("j = %d\n",j);
  fclose(my_in_file);
  
  printf("Patterns added\n");

  ciacCompile (ciac);

 
  for(i=0;i<13536;i++)
  {
      fseek(T,i,0);
      a = fgetc(T);
	  text[i]=a;
  }
 
  fclose(T);
  
  //Get current date and time
  //match_number = 0;
  start = clock();
  
  for(i=0;i<100;i++)
 {
	 ciacSearch (ciac, text, 13536, MatchFound, 0);
  }
  finish = clock();
  
  duration = (double)(finish - start) / CLOCKS_PER_SEC;
  
  //ciacFree (ciac);
  printf("match number = %d\n",match_number);
  printf( "%f seconds\n", duration );
  printf("DFA size = %.2f KB\n",(float)ciac_dfa_size/1024);
  printf("ciac_match_item_size = %.2f KB\n",(float)ciac_match_item_size/1024);
  printf ("normal pgm end\n");
  return 0;
}
//#endif /*  */



