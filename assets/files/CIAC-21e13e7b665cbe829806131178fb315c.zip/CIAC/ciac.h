/*
**   CIAC.H 
**
**   Version 2.0
**
**   Copyright (C) 2005,2006  Jianming Yu
**   Copyright (C) 2005,2006 Tsinghua University.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#ifndef CIAC_H
#define CIAC_H

#ifdef WIN32

#ifdef inline
#undef inline
#endif

#define inline __inline

#endif

/*
*   DEFINES and Typedef's
*/
#define MAX_ALPHABET_SIZE 256     

/*
   FAIL STATE for 1,2,or 4 bytes for state transitions

   Uncomment this define to use 32 bit state values
   #define AC32
*/

/* #define AC32 */

//#ifdef AC32

typedef  unsigned int   ciac_state_t;
#define CIAC_FAIL_STATE  0xffffffff

//#else

//typedef    unsigned short ciac_state_t;
//#define CIAC_FAIL_STATE 0xffff

//#endif

/*
*
*/
typedef 
struct _ciac_pattern
{      
    struct  _ciac_pattern *next;

    unsigned char         *patrn;
    unsigned char         *casepatrn;
    int      n;
    int      nocase;
    int      offset;
    int      depth;
    void *   id;
    int      iid;

} CIAC_PATTERN;

/*
*    transition nodes  - either 8 or 12 bytes
*/
typedef 
struct ciac_trans_node_s {

  ciac_state_t    key;           /* The character that got us here - sized to keep structure aligned on 4 bytes */
                              /* to better the caching opportunities. A value that crosses the cache line */
                              /* forces an expensive reconstruction, typing this as acstate_t stops that. */
  ciac_state_t    next_state;    /*  */
  struct ciac_trans_node_s * next; /* next transition for this state */

} ciac_trans_node_t;


/*
*   Aho-Corasick State Machine Struct - one per group of pattterns
*/
typedef struct {
  
	int ciacMaxStates;  
	int ciacNumStates;  

	CIAC_PATTERN    * ciacPatterns;
        ciac_state_t        * ciacFailState;
        CIAC_PATTERN   ** ciacMatchList;

        /* list of transitions in each state, this is used to build the nfa & dfa */
        /* after construction we convert to CIAC matrix and free */
        /* the transition lists */
        ciac_trans_node_t ** ciacTransTable;

        ciac_state_t ** ciacNextState;
        
	int          ciacNumTrans;
        int          ciacAlphabetSize;

}CIAC_STRUCT;

/*
*   Prototypes
*/
CIAC_STRUCT * ciacNew ();
int ciacAddPattern( CIAC_STRUCT * p, unsigned char * pat, int n,
                    int nocase, int offset, int depth, void *  id, int iid );
int ciacCompile ( CIAC_STRUCT * ciac );
void ciacFree ( CIAC_STRUCT * ciac );
int Conv_Full_DFA_To_CHARINDEX(CIAC_STRUCT * ciac) ;
inline int ciacSearch(CIAC_STRUCT * ciac, unsigned char *Tx, int n,
	    int (*Match) (void * id, int index, void *data), void *data) ;
void Print_ciac(CIAC_STRUCT * ciac);
#endif
