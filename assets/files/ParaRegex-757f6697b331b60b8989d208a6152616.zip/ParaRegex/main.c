/*
 * File:   main.c
 * Author: Michela Becchi
 * Email:  mbecchi@cse.wustl.edu
 * Organization: Applied Research Laboratory
 *
 * Description: This is the main entry file
 *
 */

#include "stdinc.h"
#include "nfa.h"
#include "smr.h"
#include "dfa.h"
#include "hybrid_fa.h"
#include "parser.h"
#include "trace.h"
#include "time.h"
#include <sys/time.h>
#include <pthread.h>

/*
 * Program entry point.
 * Please modify the main() function to add custom code.
 * The options allow to create a DFA from a list of regular expressions.
 * If a single single DFA cannot be created because state explosion occurs, then a list of DFA
 * is generated (see MAX_DFA_SIZE in dfa.h).
 * Additionally, the DFA can be exported in proprietary format for later re-use, and be imported.
 * Moreover, export to DOT format (http://www.graphviz.org/) is possible.
 * Finally, processing a trace file is an option.
 */


#ifndef CUR_VER
#define CUR_VER		"Michela  Becchi 1.4.1"
#endif

int VERBOSE;
int DEBUG;

//#define NUM_THREADS 9

state_t final_state;
set<unsigned int> accepted_rules;

/*
 * Returns the current version string
 */
void version(){
    printf("version:: %s\n", CUR_VER);
}

/* usage */
static void usage()
{
	fprintf(stderr,"\n");
    fprintf(stderr, "Usage: regex [options]\n");
    fprintf(stderr, "             [--parse|-p <regex_file> [--m|--i] | --import|-i <in_file> ]\n");
    fprintf(stderr, "             [--export|-e  <out_file>][--graph|-g <dot_file>]\n");
    fprintf(stderr, "             [--trace|-t <trace_file>]\n");
	fprintf(stderr, "             [-l <out_log>]\n");
	fprintf(stderr, "             [-n <n thread>]\n");
    fprintf(stderr, "             [--hfa]\n\n");
    fprintf(stderr, "\nOptions:\n");
    fprintf(stderr, "    --help,-h       print this message\n");
    fprintf(stderr, "    --version,-r    print version number\n");
    fprintf(stderr, "    --verbose,-v    basic verbosity level \n");
    fprintf(stderr, "    --debug,  -d    enhanced verbosity level \n");
	fprintf(stderr, "\nOther:\n");
	fprintf(stderr, "    --parse,-p <regex_file>          process regex file\n");
	fprintf(stderr, "    --m,--i                          m modifier, ignore case\n");
	fprintf(stderr, "    --import,-i <in_file>            import DFA from file\n");
	fprintf(stderr, "    --export,-e <out_file>           export DFA to file\n");
	fprintf(stderr, "    --graph,-g <dot_file>            export DFA in DOT format into specified file\n");
    fprintf(stderr, "    --trace,-t <trace_file>          trace file to be processed\n");
	fprintf(stderr, "    --traverse_states,-l <out_log>   traverse all states as start\n");
    fprintf(stderr, "    --hfa                            generate the hybrid-FA\n");
    fprintf(stderr, "\n");
    exit(0);
}

/* configuration */
static struct conf {
	char *regex_file;
	char *in_file;
	char *out_file;
	char *out_log;
	char *dot_file;
	char *trace_file;
	bool i_mod;
	bool m_mod;
	bool verbose;
	bool debug;
	bool hfa;
    int threads_num;
} config;

/* initialize the configuration */
void init_conf(){
	config.regex_file=NULL;
	config.in_file=NULL;
	config.out_file=NULL;
	config.out_log=NULL;
	config.dot_file=NULL;
	config.trace_file=NULL;
	config.i_mod=false;
	config.m_mod=false;
	config.debug=false;
	config.verbose=false;
	config.hfa=false;
    config.threads_num=1;
}

/* print the configuration */
void print_conf(){
	fprintf(stderr,"\nCONFIGURATION: \n");
	if (config.regex_file) fprintf(stderr, "- RegEx file: %s\n",config.regex_file);
	if (config.in_file) fprintf(stderr, "- DFA import file: %s\n",config.in_file);
	if (config.out_file) fprintf(stderr, "- DFA export file: %s\n",config.out_file);
	if (config.out_log) fprintf(stderr, "- Log in file: %s\n",config.out_log);
	if (config.dot_file) fprintf(stderr, "- DOT file: %s\n",config.dot_file);
	if (config.trace_file) fprintf(stderr,"- Trace file: %s\n",config.trace_file);
	if (config.i_mod) fprintf(stderr,"- ignore case selected\n");
	if (config.m_mod) fprintf(stderr,"- m modifier selected\n");
	if (config.verbose && !config.debug) fprintf(stderr,"- verbose mode\n");
	if (config.debug) fprintf(stderr,"- debug mode\n");
	if (config.hfa)   fprintf(stderr,"- hfa generation invoked\n");
	if (config.threads_num)   fprintf(stderr,"- using %d threads\n", config.threads_num);
}

/* parse the main call parameters */
static int parse_arguments(int argc, char **argv)
{
	int i=1;
    if (argc < 2) {
        usage();
		return 0;
    }
    while(i<argc){
    	if(strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0){
    		usage();
    		return 0;
    	}else if(strcmp(argv[i], "-r") == 0 || strcmp(argv[i], "--version") == 0){
    		version();
    		return 0;
    	}else if(strcmp(argv[i], "-v") == 0 || strcmp(argv[i], "--verbose") == 0){
    		config.verbose=1;
    	}else if(strcmp(argv[i], "-d") == 0 || strcmp(argv[i], "--debug") == 0){
    		config.debug=1;
    	}else if(strcmp(argv[i], "--hfa") == 0){
    	    		config.hfa=1;
    	}else if(strcmp(argv[i], "-g") == 0 || strcmp(argv[i], "--graph") == 0){
    		i++;
    		if(i==argc){
    			fprintf(stderr,"Dot file name missing.\n");
    			return 0;
    		}
    		config.dot_file=argv[i];
    	}else if(strcmp(argv[i], "-i") == 0 || strcmp(argv[i], "--import") == 0){
    		i++;
    		if(i==argc){
    			fprintf(stderr,"Import file name missing.\n");
    			return 0;
    		}
    		config.in_file=argv[i];
    	}else if(strcmp(argv[i], "-e") == 0 || strcmp(argv[i], "--export") == 0){
    		i++;
    		if(i==argc){
    			fprintf(stderr,"Export file name missing.\n");
    			return 0;
    		}
    		config.out_file=argv[i];
		}else if(strcmp(argv[i], "-l") == 0){
			i++;
			if(i==argc){
				fprintf(stderr,"Log file name missing.\n");
				return 0;
			}
			config.out_log=argv[i];
    	}else if(strcmp(argv[i], "-p") == 0 || strcmp(argv[i], "--parse") == 0){
    		i++;
    		if(i==argc){
    			fprintf(stderr,"Regular expression file name missing.\n");
    			return 0;
    		}
    		config.regex_file=argv[i];
    	}else if(strcmp(argv[i], "-t") == 0 || strcmp(argv[i], "--trace") == 0){
    		i++;
    		if(i==argc){
    			fprintf(stderr,"Trace file name missing.\n");
    			return 0;
    		}
    		config.trace_file=argv[i];
    	}else if(strcmp(argv[i], "-n") == 0){
    		i++;
    		if(i==argc){
    			fprintf(stderr,"Threads num missing.\n");
    			return 0;
    		}
    		config.threads_num=strtol(argv[i], NULL, 10);
    	}else if(strcmp(argv[i], "--m") == 0){
			config.m_mod=true;
		}else if(strcmp(argv[i], "--i") == 0){
			config.i_mod=true;
    	}else{
    		fprintf(stderr,"Ignoring invalid option %s\n",argv[i]);
    	}
    	i++;
    }
	return 1;
}

/* check that the given file can be read/written */
void check_file(char *filename, const char *mode){
	FILE *file=fopen(filename,mode);
	if (file==NULL){
		fprintf(stderr,"Unable to open file %s in %s mode",filename,mode);
		fatal("\n");
	}else fclose(file);
}

struct thread_args {
    DFA *dfa;
    SMR *smr;
    trace *tr;   
};

void *traverse_para(void *arguments){
    struct thread_args *args = (struct thread_args *)arguments;
    args->tr->traverse_by_smr(args->dfa, args->smr);
    return NULL;
};

void smr_merge(SMR *smr, int num){
    int ii;
    if (num==0){
        state_t start_state = 0;
        final_state = smr->get_msns()[0]->current_state;
        for(int jj=0;jj<smr->get_arns().size();jj++)
            if (smr->get_arns()[jj]->states_map[start_state])
                accepted_rules.insert(smr->get_arns()[jj]->rule_id);
    }else{
        for(ii=0;ii<smr->get_msns().size();ii++)
            if(smr->get_msns()[ii]->states_map[final_state]) break;
        state_t start_state = final_state;
        final_state =smr->get_msns()[ii]->current_state;
        for(int jj=0;jj<smr->get_arns().size();jj++)
            if (smr->get_arns()[jj]->states_map[start_state])
                accepted_rules.insert(smr->get_arns()[jj]->rule_id);
    }
};

/*
 *  MAIN - entry point
 */
int main(int argc, char **argv){

	//read configuration
	init_conf();
	while(!parse_arguments(argc,argv)) usage();
	print_conf();
	VERBOSE=config.verbose;
	DEBUG=config.debug; if (DEBUG) VERBOSE=1;

	//check that it is possible to open the files
	if (config.regex_file!=NULL) check_file(config.regex_file,"r");
	if (config.in_file!=NULL) check_file(config.in_file,"r");
	if (config.out_file!=NULL) check_file(config.out_file,"w");
	if (config.out_log!=NULL) check_file(config.out_log,"w");
	if (config.dot_file!=NULL) check_file(config.dot_file,"w");
	//if (config.trace_file!=NULL) check_file(config.trace_file,"r");

	// check that either a regex file or a DFA import file are given as input
	if (config.regex_file==NULL && config.in_file==NULL){
		fatal("No data file - please use either a regex or a DFA import file\n");
	}
	if (config.regex_file!=NULL && config.in_file!=NULL){
		printf("DFA will be imported from the Regex file. Import file will be ignored\n");
	}

	/* FA declaration */
	NFA *nfa=NULL;  	// NFA
	DFA *dfa=NULL;		// DFA
	dfa_set *dfas=NULL; // set of DFAs, in case a single DFA for all RegEx in the set is not possible
	HybridFA *hfa=NULL; // Hybrid-FA

	// if regex file is provided, parses it and instantiate the corresponding NFA.
	// if feasible, convert the NFA to DFA
	if (config.regex_file!=NULL){
		FILE *regex_file=fopen(config.regex_file,"r");
		fprintf(stderr,"\nParsing the regular expression file %s ...\n",config.regex_file);
		regex_parser *parse=new regex_parser(config.i_mod,config.m_mod);
		nfa = parse->parse(regex_file);
		nfa->remove_epsilon();
		nfa->reduce();
		dfa=nfa->nfa2dfa();
		if (dfa==NULL) printf("Max DFA size %d exceeded during creation: the DFA was not generated\n",MAX_DFA_SIZE);
		//else dfa->minimize();
		fclose(regex_file);
		delete parse;
	}

	// if a regex file is not provided, import the DFA
	if (config.regex_file==NULL && config.in_file!=NULL){
		FILE *in_file=fopen(config.in_file,"r");
		fprintf(stderr,"\nImporting from file %s ...\n",config.in_file);
		dfa=new DFA();
		dfa->get(in_file);
		fclose(in_file);
	}

	// DFA export
	if (dfa!=NULL && config.out_file!=NULL){
		FILE *out_file=fopen(config.out_file,"w");
		fprintf(stderr,"\nExporting to file %s ...\n",config.out_file);
		dfa->put(out_file);
		fclose(out_file);
	}

	// DOT file generation
	if (dfa!=NULL && config.dot_file!=NULL){
		FILE *dot_file=fopen(config.dot_file,"w");
		fprintf(stderr,"\nExporting to DOT file %s ...\n",config.dot_file);
		char string[100];
		if (config.regex_file!=NULL) sprintf(string,"source: %s",config.regex_file);
		else sprintf(string,"source: %s",config.in_file);
		dfa->to_dot(dot_file, string);
		fclose(dot_file);
	}

	// HFA generation
	if (config.hfa){
		if (nfa==NULL) fatal("Impossible to build a Hybrid-FA if no NFA is given.");
		hfa=new HybridFA(nfa);
		if (hfa->get_head()->size()<100000) hfa->minimize();
		printf("HFA:: head size=%d, tail size=%d, number of tails=%d, border size=%ld\n",hfa->get_head()->size(),hfa->get_tail_size(),hfa->get_num_tails(),hfa->get_border()->size());
	}

	// trace file traversal
	if (config.trace_file){
//		trace *tr=new trace(config.trace_file);
//		if (nfa!=NULL) tr->traverse(nfa);
//
		struct timeval start,end;
		gettimeofday(&start,NULL);
	    if (dfa!=NULL){
            int NUM_THREADS = config.threads_num;

            pthread_t tHandles[NUM_THREADS];
            struct thread_args tParams[NUM_THREADS];

            for(int i=0;i<NUM_THREADS;i++){
                char temp_trace_file[80] = "";
                char temp_buffer[80] = "";
                strcpy(temp_trace_file, config.trace_file);
                sprintf(temp_buffer, "_%d", i);
                strcat(temp_trace_file, temp_buffer);

                tParams[i].tr = new trace(temp_trace_file);
                tParams[i].smr = new SMR(dfa,(i==0));
                tParams[i].dfa = dfa;
                if (pthread_create(&tHandles[i],NULL,&traverse_para,(void *) &tParams[i])==0){
                    printf("Thread %d begins...\n",i);
                }
            }
            for(int i=0;i<NUM_THREADS;i++){
                pthread_join(tHandles[i], NULL);
            }

            for(int i=0;i<NUM_THREADS;i++){
                smr_merge(tParams[i].smr,i);
            }
            printf("final state is:\n%u\n",final_state);
            printf("matched rules:\n");
            for(set<unsigned int>::iterator iter = accepted_rules.begin();iter!=accepted_rules.end();iter++){
                printf("%u ",(unsigned int)*iter);
            }
            gettimeofday(&end,NULL);
            printf("\n>> %d thread time: %ldms\n",config.threads_num, (end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000);

            char temp_str[80] = "";
            char temp_str2[80] = "";
            strcpy(temp_str, "time_log_O");
            sprintf(temp_str2, "%d_%d", O_OPTION, config.threads_num);
            strcat(temp_str, temp_str2);
            FILE *time_log_file=fopen(temp_str,"a+");
            fprintf(time_log_file,"%d\t%s\t%s\t%ld\n",config.threads_num, config.trace_file, config.in_file, (end.tv_sec-start.tv_sec)*1000+(end.tv_usec-start.tv_usec)/1000);
            fclose(time_log_file);
        }
	}


	// if the DFA was not generated because of state blow-up during NFA-DFA transformation,
	// then generate multiple DFAs
	if (config.regex_file!=NULL && dfa==NULL){
		printf("\nCreating multiple DFAs...\n");
		FILE *re_file=fopen(config.regex_file,"r");
		regex_parser *parser=new regex_parser(config.i_mod,config.m_mod);
		dfas = parser->parse_to_dfa(re_file);
		printf("%ld DFAs created\n",dfas->size());
		fclose(re_file);
		delete parser;
		int idx=0;
		FOREACH_DFASET(dfas,it) {
			printf("DFA #%d::  size=%d\n",idx,(*it)->size());
			if (config.out_file!=NULL){
				char out_file[100];
				sprintf(out_file,"%s%d",config.out_file,idx);
				FILE *file=fopen(out_file,"w");
				fprintf(stderr,"Exporting DFA #%d to file %s ...\n",idx,out_file);
				(*it)->put(file);
				fclose(file);
				idx++;
			}
		}
	}

	/*
	 * ADD YOUR CODE HERE
	 * This is the right place to call the compression algorithms (see dfa.h, nfa.h),
	 * and analyze your data structures.
	 */

	/* BEGIN USER CODE */

	// write your code here

	/* END USER CODE */

	/* Automata de-allocation */

	if (nfa!=NULL) delete nfa;
	if (dfa!=NULL) delete dfa;
	if (dfas!=NULL){
		FOREACH_DFASET(dfas,it) delete (*it);
		delete dfas;
	}
	if (hfa!=NULL) delete hfa;

	return 0;

}

