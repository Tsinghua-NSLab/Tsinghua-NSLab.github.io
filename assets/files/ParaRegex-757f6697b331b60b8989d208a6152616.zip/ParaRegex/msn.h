/*
 * File:   msn.h
 * Author: Zhe Fu
 * Email:  fooozhe@gmail.com
 * Organization: NSLab
 *
 * Description:
 * 
 * 		Implements a MSN (Middle State Node).
 * 
 */

#ifndef __MSN_H               
#define __MSN_H

#include "stdinc.h"
#include <set>
#include <iostream>
#include <boost/dynamic_bitset.hpp>

using namespace std;

class MSN;

class MSN {

public:	

    /* current state of this MSN */
    state_t current_state;
    
    boost::dynamic_bitset<> states_map;

    set<unsigned int> accepted_rules;
 
	/* instantiates a new MSN */
	MSN(unsigned states_num, state_t the_state, bool set_1=true){
        current_state = the_state;
        states_map.resize(states_num, false);
        if(set_1) states_map[current_state] = true;
    }
	
    MSN(MSN *old_msn, state_t new_state){
        current_state = new_state;
        states_map.resize(old_msn->states_map.size(), false);
        states_map = old_msn->states_map;
        accepted_rules = old_msn->accepted_rules;
    }
	/* deallocates the MSN */
	//~MSN();
	
    MSN& operator=(const MSN& msn1){
        current_state = msn1.current_state;
        states_map = msn1.states_map;
        accepted_rules = msn1.accepted_rules;
        return *this;
    }
};

class ARN {

public:

    unsigned int rule_id;
    boost::dynamic_bitset<> states_map;

    ARN(unsigned int the_rule, boost::dynamic_bitset<> the_states_map){
        rule_id = the_rule;
        states_map = the_states_map;
    }
};


#endif /*__MSN_H*/
