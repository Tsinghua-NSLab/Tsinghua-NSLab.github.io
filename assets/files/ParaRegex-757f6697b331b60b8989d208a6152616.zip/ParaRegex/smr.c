/*
 *
 * File:   smr.c
 * Author: Zhe Fu
 * Email:  fooozhe@gmail.com
 * Organization: NSLab
 *
 * Description:
 * 
 * 		Implements a SMR (Part Matching State).
 * 
 */

#include "dfa.h"
#include "nfa.h"
#include "smr.h"
#include "msn.h"
#include <stdio.h>
#include <set>
#include "dheap.h"
#include <sys/time.h>

using namespace std;


SMR::SMR(DFA *dfa, bool isFirst){
    MSN *temp;
	_size = dfa->size();
	_depth = 0;
	cache_map = (int  *)allocate_array(_size, sizeof(int));
    memset(cache_map, 0, _size*sizeof(int));
    if(!isFirst){
        for (state_t s=0;s<_size;s++){
            temp = new MSN(_size, s);
            msn_set.push_back(temp);
        }
    }else{
        temp = new MSN(_size, 0);
        msn_set.push_back(temp);
    }
    //delete temp;
}

SMR::~SMR(){
    free(cache_map);
}

void SMR::add_rules(DFA *dfa, MSN *msn, state_t next_state){
    linked_set *ls=dfa->accepts(next_state);
    while(ls!=NULL){
        if (VERBOSE) printf("rule %d matched at position %u\n",ls->value(),_depth);
        msn->accepted_rules.insert(ls->value());
        bool found = false;
        for(int i = 0;i < arn_set.size();i++){
            if (arn_set[i]->rule_id == ls->value()) {
                found = true;
                arn_set[i]->states_map |= msn->states_map;
                break;
            }
        }
        if (!found) {
            ARN *temp_arn;
            temp_arn = new ARN(ls->value(), msn->states_map);
            arn_set.push_back(temp_arn);
        }
        ls=ls->succ();
    }	
    free(ls);
}

void SMR::get_next_states(DFA *dfa, symbol_t c){
    if (msn_set.size() == 1){
        state_t old_state = msn_set[0]->current_state;
        state_t next_state = dfa->get_next_state(old_state, (unsigned char)c);
        msn_set[0]->current_state = next_state;
        if(!dfa->accepts(next_state)->empty()){
            add_rules(dfa, msn_set[0], next_state);
        }
    }else if (msn_set.size() == 2){
        for (int ii=0;ii<2;ii++){
            state_t old_state = msn_set[ii]->current_state;
            state_t next_state = dfa->get_next_state(old_state, (unsigned char)c);
            msn_set[ii]->current_state = next_state;
            if(!dfa->accepts(next_state)->empty()){
                add_rules(dfa, msn_set[ii], next_state);
            }
        }
        if (msn_set[0]->current_state == msn_set[1]->current_state){
            msn_set[0]->states_map |= msn_set[1]->states_map;
            msn_set.erase(--msn_set.end());
        }
    }else{
        MSN *temp_msn;
        vector<MSN*> temp_set;
        state_t next_state;
        state_t old_state=-1;
        memset(cache_map, 0, _size*sizeof(int));

        for (unsigned long i=0;i<msn_set.size();i++){
            old_state = msn_set[i]->current_state;
            next_state = dfa->get_next_state(old_state, (unsigned char)c);

            if (cache_map[next_state]==0) {
                temp_msn = new MSN(msn_set[i], next_state);

                if(!dfa->accepts(next_state)->empty()){
                    add_rules(dfa, temp_msn, next_state);
                }

                temp_set.push_back(temp_msn);
                cache_map[next_state] = 1;

            } else {
                for(unsigned long j=0;j<temp_set.size();j++){
                    if(temp_set[j]->current_state == next_state){
                        temp_set[j]->states_map |= msn_set[i]->states_map;
                        temp_set[j]->accepted_rules.insert(msn_set[i]->accepted_rules.begin(),msn_set[i]->accepted_rules.end());

                        if(!dfa->accepts(next_state)->empty()){
                            add_rules(dfa, temp_set[j], next_state);
                        }
                    }
                }
            }
        }
        msn_set = temp_set;
        //delete temp_msn;
    }
    _depth++;
}

void SMR::print_states(){
    for (unsigned long i=0;i<msn_set.size();i++){
        printf("%u ", msn_set[i]->current_state);
    }
    printf("\n");
}

void SMR::print_cache_map(){
    for (unsigned int i=0;i<_size;i++){
        printf("%d ", cache_map[i]);
    }
    printf("\n");
}

void SMR::print_msns(){
    printf("current msns of SMR: %lu current msns...\n",msn_set.size());
    for(unsigned long i=0;i<msn_set.size();i++){
 
    	printf("==========\n");
    	printf("current state:\n%u\n",msn_set[i]->current_state);
    	printf("states map:\n");
        for(unsigned long j=0;j<_size;j++){
            printf("%d\t",(int)msn_set[i]->states_map[j]);
        }
    	printf("\naccepted rules:\n");
        for(set<unsigned int>::iterator iter = msn_set[i]->accepted_rules.begin();iter!=msn_set[i]->accepted_rules.end();iter++){
            printf("%d\t",(int)*iter);
        }
    	printf("\n==========\n");
        printf("\n");
    }
}

void SMR::print_arns(){
    printf("current arns of SMR: %lu current arns...\n",arn_set.size());
    for(unsigned long i=0;i<arn_set.size();i++){
 
    	printf("==========\n");
    	printf("current rule id:\n%u\n",arn_set[i]->rule_id);
    	printf("states map:\n");
        for(unsigned long j=0;j<_size;j++){
            printf("%d\t",(int)arn_set[i]->states_map[j]);
        }
    	printf("\n==========\n");
        printf("\n");
    }
}

void SMR::dump_msns(FILE *log){
    printf("Dumping current msns of SMR: %lu current msns...\n",msn_set.size());
    fprintf(log, "%lu\n", msn_set.size());
    for(unsigned long i=0;i<msn_set.size();i++){
    	fprintf(log,"%u\n",msn_set[i]->current_state);
        for(unsigned long j=0;j<_size;j++){
            fprintf(log,"%d\t",(int)msn_set[i]->states_map[j]);
        }
        fprintf(log, "\n");
        for(set<unsigned int>::iterator iter = msn_set[i]->accepted_rules.begin();iter!=msn_set[i]->accepted_rules.end();iter++){
            fprintf(log,"%d\t",(int)*iter);
        }
        fprintf(log, "\n");
    }
}
	
void SMR::dump_states(FILE *log){
    printf("Dumping unique states of SMR: %lu unique states...\n",msn_set.size());
    fprintf(log, "%lu\n", msn_set.size());
    for(unsigned long i=0;i<msn_set.size();i++){
    	fprintf(log,"%u\t",msn_set[i]->current_state);
    }
    fprintf(log, "\n");
}
