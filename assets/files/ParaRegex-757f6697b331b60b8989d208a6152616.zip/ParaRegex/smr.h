/*
 * File:   smr.h
 * Author: Zhe Fu
 * Email:  fooozhe@gmail.com
 * Organization: NSLab
 *
 * Description:
 * 
 * 		Implements a SMR (Segmental Matching Result).
 * 
 */

#ifndef __SMR_H               
#define __SMR_H

#include "stdinc.h"
#include "int_set.h"
#include "linked_set.h"
#include "wgraph.h"
#include "rpartition.h"
#include "dfa.h"
#include "msn.h"
#include <vector>

using namespace std;

class SMR;

class SMR {

    vector<MSN*> msn_set;

    vector<ARN*> arn_set;

    //vector<state_t> cache_map;

    int* cache_map;

    unsigned int _depth;

    unsigned int _size;
             
public:	

	/* instantiates a new SMR */
	SMR(DFA *dfa, bool isFirst=false);
	
	/* deallocates the SMR */
	~SMR();
	
	/* returns the number of states in the original DFA */
	unsigned int size();

	/* returns input depth */
	unsigned int depth();

    /* returns the number of msns */
    unsigned int num();

	/* sets the depth in the SMR */
	void set_depth(unsigned int n);

	/* returns the next states from current states on symbol c */
	void get_next_states(DFA *dfa, symbol_t c);
	
	/* returns the array of acceptstate pointers */
	linked_set **get_accepted_rules();
	
	/* returns msn vector */
	vector<MSN*> get_msns();

	/* returns arn vector */
	vector<ARN*> get_arns();

	/* print current states */
	void print_states();

	/* print states map*/
    void print_cache_map();

    void print_msns();

    void print_arns();

	/* dumps all msns*/
	void dump_msns(FILE *log);
	
	/* dumps unique states */
	void dump_states(FILE *log);

    void add_rules(DFA *dfa, MSN *msn, state_t the_state);

	/* dumps the DFA into file for later import */
	/* void put(FILE *file, char *comment=NULL); */
	
	/* imports the SMR from file */
	/* void get(FILE *file); */
};

inline unsigned int SMR::size(){ return _size;}

inline unsigned int SMR::depth(){return _depth;}

inline unsigned int SMR::num(){return msn_set.size();}

inline void SMR::set_depth(unsigned int n){_depth = n;}

inline vector<MSN*> SMR::get_msns(){return msn_set;}

inline vector<ARN*> SMR::get_arns(){return arn_set;}

#endif /*__SMR_H*/
