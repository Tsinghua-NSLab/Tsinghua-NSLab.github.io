/*
** Copyright (C) 2009-2014 Mischa Sandberg <mischasan@gmail.com>
**
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU Lesser General Public License Version 3 as
** published by the Free Software Foundation.  You may not use, modify or
** distribute this program under any other version of the GNU Lesser General
** Public License.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU Lesser General Public License for more details.
**
** You should have received a copy of the GNU Lesser General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

#include "msutil.h"
#include "tap.h"
#include "acism.h"
#include "strmat.h"
#include "strmat_seqary.h"
#include "strmat_match.h"

static int nmatches;
static int on_match(int,int,void*);
int candidate_state[MAX_CANDIDATES+1][MAX_QTY+1] = {-1};
MATCHES matchlist, matchtail, newmatch;
extern int seq_start;
extern int seq_end;

int acism_mmap_x()
{
    plan_tests(2);
    nmatches = 0;

    FILE *pfp = fopen("acism.tmp", "r");
    if (!pfp) die(": unable to open acism.tmp:");

    MEMREF text = bufref(slurp("text.tmp"));
    if (nilref(text)) die(": unable to load text.tmp:");

    ACISM *psp = acism_mmap(pfp);
    ok(psp, "acism_mmap returned");
    fclose(pfp);
    double t0 = tick();
    struct timeval stop, start;
    gettimeofday(&start, NULL);
    
    ok(!acism_scan(psp, text, on_match, NULL),
        "mmap-ed acism object works");

    fprintf(stderr, "Found %d matches\n", nmatches);
    gettimeofday(&stop, NULL);
    printf("Took %f milliseconds!\n", (float)((stop.tv_sec * 1000000 + stop.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec))/1000);
    acism_dump(psp, PS_STATS, stderr, NULL);
    acism_destroy(psp);

    return exit_status();
}

static int
on_match(int s, int t, void *c)
{
    // ++nmatches;
    STRING *res;
    int i, pos, matchcount, candidate_index, match_id; 

    match_id = s + 1;
    res = get_element(match_id);
    pos = t - res->length + 1;
    
    for (i = 0; i < res->qty; i++)
    {
        if(res->sig[i] > seq_end)
            continue;
        candidate_index = check_sig(res, i, match_id, pos, candidate_state);
        if(!candidate_index || res->not_search[i] == 't'){
            continue;
        }
        if(candidate_index == 2)
            candidate_state[res->sig[i]][0] = pos;
        if((res->next_substring[i][0] == -1) && (strcmp(res->next_op[i],"BOT") == 0)){
            newmatch = alloc_match();
            if (newmatch == NULL) {
                free_matches(matchlist);
                mprintf("Memory Error:  Ran out of memory.\n");
                return 0;
            }
            newmatch->type = SET_EXACT;
            newmatch->lend = candidate_state[res->sig[i]][0];
            newmatch->rend = pos + res->length - 1;
            newmatch->id = match_id;

            if (matchlist == NULL){
                matchlist = matchtail = newmatch;
            }
            else {
                matchtail->next = newmatch;
                matchtail = newmatch;
            }
            ++nmatches;
        }else{
            candidate_state[res->sig[i]][res->seq[i]] = pos + res->length;

            // if (strchr(res->next_op[i], '+') != NULL){
            //     // plus_candidates.top[2]++;
            //     // plus_candidates.tmp_candidates[plus_candidates.top[2]] = insertion_index;
            //     // candidates.handled[insertion_index] = 1;
            // }
        }
    }
    (void)s, (void)t, (void)c;
    return 0;
}
