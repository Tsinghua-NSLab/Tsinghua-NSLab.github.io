#!/bin/bash

input="generated-input.txt"
matchable="matchable.txt"
rm -f "$input"
rm -f "$matchable"

inputSize=60000
correctProbability=0
wrongProbability=-1

snort24c=`cat "pat.txt"` #snort24-c.txt
snort24w=`cat "snort24-w.txt"`

echo "TYPE:  Text" > "$input"
echo "IDENT:  " >> "$input"
echo "TITLE:  Fib 30" >> "$input"
echo "ALPHABET:  ASCII" >> "$input"
echo "QTY:  1" >> "$input"
echo "SIG:  -1" >> "$input"
echo "SEQ:  -1" >> "$input"
echo "NOT:  FALSE" >> "$input"
echo "NEXT OPERATOR:  BOT" >> "$input"
echo "PREV OPERATOR:  F" >> "$input"
echo "NEXT SUBSTRING:  -1" >> "$input"
echo "PREV SUBSTRING:  -1" >> "$input"

a=1
pattern=""
patternLen=0
while [  $patternLen -lt $inputSize ]; do
	correctSig=$((RANDOM % 100))
	if [ $correctSig -lt $correctProbability ] 
	then
		line=$(((RANDOM % 45459) + 1))
		sig=`echo "$snort24c" | head -n $line | tail -n 1`
		echo "$line: $sig" >> "$matchable"
		len=`echo "$sig" | wc -c`
		pattern="$pattern$sig"
		patternLen=$(($patternLen + $len - 1))
	else
		wrongSig=$((RANDOM % 100))
		if [ $wrongSig -lt $wrongProbability ] 
		then
			line=$(((RANDOM % 139) + 1))
			sig=`echo "$snort24w" | head -n $line | tail -n 1`
			len=`echo "$sig" | wc -c`
			pattern="$pattern$sig"
			patternLen=$(($patternLen + $len - 1))
		else
			# len=$(((RANDOM % 100) + 30))
			# sig=`cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w $len | head -n 1`
			len=30
			sig="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
			pattern="$pattern$sig"
			patternLen=$(($patternLen + $len))
		fi
	fi
	if [ $patternLen -gt $(($a*1000)) ] 
	then
		echo "$pattern" > tmp.txt
		echo "$patternLen"
		a=$((a+1))
	fi
done

echo "LENGTH:  $patternLen" >> "$input"
echo "SEQUENCE:" >> "$input"
echo "$pattern" >> "$input"
echo "//" >> "$input"