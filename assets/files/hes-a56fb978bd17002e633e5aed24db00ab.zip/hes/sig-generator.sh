#!/bin/bash

sigFile="patterns"
singleQtyProbability=80
echo -n "" > "$sigFile"
for i in `seq 1 10000`;
do
	size=$(((RANDOM % 40) + 10))
	sequences=$(((RANDOM % 8) + 1))
	for j in `seq 1 $sequences`;
	do
		echo "TYPE:  Text" >> "$sigFile"
		echo "IDENT:  " >> "$sigFile"
		echo "TITLE:  ${i}_${j}" >> "$sigFile"
		echo "ALPHABET:  ASCII" >> "$sigFile"
		
		qtypr=$((RANDOM % 100))
		if [ $qtypr -lt $singleQtyProbability ]
        then
        	qty=1
        else
			qty=$(((RANDOM % 9)+2))
		fi
		echo "QTY:  $qty" >> "$sigFile"
		for k in `seq 1 $qty`;
		do
			echo "SIG:  $i" >> "$sigFile"
			echo "SEQ:  $j" >> "$sigFile"
			not=$((RANDOM % 2))
			if [ $not -eq 0 ]
	        then
				echo "NOT:  FALSE" >> "$sigFile"
	        else
				echo "NOT:  TRUE" >> "$sigFile"
			fi
			echo "NEXT OPERATOR:  \d+" >> "$sigFile"
			preOp=$((RANDOM % 3))
			if [ $preOp -eq 0 ]
	        then
				echo "PREV OPERATOR:  F" >> "$sigFile"
	        elif [ $preOp -eq 1 ]
        	then
				echo "PREV OPERATOR:  +" >> "$sigFile"
			else
				echo "PREV OPERATOR:  *" >> "$sigFile"
			fi
			nextSub=$(((RANDOM % sequences) + j))
			echo "NEXT SUBSTRING:  $nextSub" >> "$sigFile"
			if [ $j -eq 1 ]
			then
				prevSub="-1"
			else
				prevSub=$(((RANDOM % j) + 1))
			fi
			echo "PREV SUBSTRING:  $prevSub" >> "$sigFile"
		done
		
		echo "LENGTH:  $size" >> "$sigFile"
		echo "SEQUENCE:" >> "$sigFile"
		pattern=`< /dev/urandom tr -dc A-Za-z0-9 | head -c${1:-$size}`
		echo "$pattern" >> "$sigFile"
		echo "//" >> "$sigFile"
	done
done