#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "strmat.h"
#include "strmat_alpha.h"
#include "strmat_fileio.h"



#define TOTAL_ALPHABETS 5
char *alpha_names[] = {"UNKNOWN", "DNA", "RNA", "PROTEIN", "ASCII"};
#define TOTAL_DB_NUMBER 3
char *db_names[] = {"Text", "GenBank", "UNKNOWN"};
extern char repetitives[100][3];

#define ASCII_MAX_NUM_CHARS 79
#define NONASCII_NUM_CHARS 60


int find_next_sequence(FILE *fp)
{
  int len, fpos;
  char *s, *line;

  while ((line = my_getline(fp, &len)) != NULL) {
    if (strncmp(line, "TYPE:", 5) == 0) {
      fpos = ftell(fp);
      fseek(fp, fpos - len - 1, 0);
      return OK;
    }
    else {
      for (s=line; *s; s++)
        if (!isspace((int)(*s)))
          return FORMAT_ERROR;
    }
  }
  if (feof(fp))
    return ERROR;
  else
    return FORMAT_ERROR;
}

char** str_split(char* a_str, const char a_delim)
{
    char** result    = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }

    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = malloc(sizeof(char*) * count);

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, delim);

        while (token)
        {
            assert(idx < count);
            *(result + idx++) = strdup(token);
            token = strtok(0, delim);
        }
        assert(idx == count - 1);
        *(result + idx) = 0;
    }

    return result;
}

int read_sequence(FILE *fp, STRING *sptr)
{
  int i, len, other_chars, seqlen;
  char ch, newline_ch, *s, *line, buffer[32], not_value[5];

  /*
   * Skip blank lines.
   */
  while ((line = my_getline(fp, &len)) != NULL && line[0] == '\0') ;
  if (line == NULL)
    return ERROR;

  /*
   * Parse the TYPE line.
   */
  if (sscanf(line, "TYPE: %s", buffer) == 0)
    return FORMAT_ERROR;

  for (i=0; i < TOTAL_DB_NUMBER; i++)
    if (strcmp(buffer, db_names[i]) == 0)
      break;
  if (i == TOTAL_DB_NUMBER)
    return FORMAT_ERROR;
  else
    sptr->db_type = i; 

  /*
   * Parse the IDENT line.
   */
  if ((line = my_getline(fp, &len)) == NULL)
    return PREMATURE_EOF;
  else if (strncmp(line, "IDENT:", 6) != 0) {
    if (strncmp(line, "INDENT:", 7) == 0) {
      fprintf(stderr, "\nWarning:  Please rewrite this input file."
              "  It's file format is outdated.\n");
      sscanf(line, "INDENT: %s", sptr->ident);
    }
    else 
      return FORMAT_ERROR;
  }
  else
    sscanf(line, "IDENT: %s", sptr->ident);

  /*
   * Parse the TITLE line.
   */
  if ((line = my_getline(fp, &len)) == NULL)
    return PREMATURE_EOF;
  else if (strncmp(line, "TITLE:", 6) != 0)
    return FORMAT_ERROR;

  for (s=line+6; *s && isspace((int)(*s)); s++) ;
  strncpy(sptr->title, s, TITLE_LENGTH);
  sptr->title[TITLE_LENGTH] = '\0';

  /*
   * Parse the ALPHABET line.
   */
  if ((line = my_getline(fp, &len)) == NULL)
    return PREMATURE_EOF;
  else if (sscanf(line, "ALPHABET: %s", buffer) == 0)
    return FORMAT_ERROR;

  for (i=0; i < TOTAL_ALPHABETS; i++)
    if (strcmp(buffer, alpha_names[i]) == 0)
      break;
  if (i == TOTAL_ALPHABETS)
    return FORMAT_ERROR;
  else
    sptr->raw_alpha = i;

  newline_ch = rawmapchar(sptr->raw_alpha, '\n');
  if (newline_ch == -1)
    return ERROR;

  /*
   * Parse the QTY line.
   */
  if ((line = my_getline(fp, &len)) == NULL)
    return PREMATURE_EOF;
  else if (sscanf(line, "QTY: %d", &sptr->qty) == 0)
    return FORMAT_ERROR;


  for (i = 0; i < sptr->qty; i++)
  {
    /*
     * Parse the SIG line.
     */
    if ((line = my_getline(fp, &len)) == NULL)
      return PREMATURE_EOF;
    else if (sscanf(line, "SIG: %d", &sptr->sig[i]) == 0)
      return FORMAT_ERROR;

    /*
     * Parse the SEQ line.
     */
    if ((line = my_getline(fp, &len)) == NULL)
      return PREMATURE_EOF;
    else if (sscanf(line, "SEQ: %d", &sptr->seq[i]) == 0)
      return FORMAT_ERROR;

    /*
     * Parse the NOT line.
     */
    if ((line = my_getline(fp, &len)) == NULL)
      return PREMATURE_EOF;
    else if (sscanf(line, "NOT:  %s", not_value) == 0)
      return FORMAT_ERROR;

    if (strcmp(not_value, "FALSE") == 0){
      sptr->not_search[i] = 'f';
    }
    else if (strcmp(not_value, "TRUE") == 0)
      sptr->not_search[i] = 't';
    else
      return FORMAT_ERROR;   

    /*
     * Parse the NEXT OPERATOR line.
     */
    if ((line = my_getline(fp, &len)) == NULL)
      return PREMATURE_EOF;
    else if (strncmp(line, "NEXT OPERATOR:", 14) != 0)
      return FORMAT_ERROR;
    for (s=line+14; *s && isspace((int)(*s)); s++) ;
    strncpy(sptr->next_op[i], s, OP_LENGTH);
    sptr->next_op[i][OP_LENGTH] = '\0';
    int t;
    for (int m = 0; m < OP_LENGTH; m++)
    {
      if(strcmp(sptr->next_op[i],"BOT") == 0)
        break;
      if(sptr->next_op[i][m] == '\\'){
        m++;
        if(sptr->next_op[i][m] == '{'){
          while (sptr->next_op[i][m+1] != '}')
          {
            m++;
            for (t = 0; repetitives[t][0]; t++)
            {
              if(sptr->next_op[i][m] == repetitives[t][1])
                break;
            }
            repetitives[t][0] = '\\';
            repetitives[t][1] = sptr->next_op[i][m];
            repetitives[t][2] = '\0';
          }
        }else{
          for (t = 0; repetitives[t][0]; t++)
          {
            if(sptr->next_op[i][m] == repetitives[t][1])
              break;
          }
          repetitives[t][0] = '\\';
          repetitives[t][1] = sptr->next_op[i][m];
          repetitives[t][2] = '\0';
        }
      }
      else if(sptr->next_op[i][m] != '\0' && sptr->next_op[i][m] != '+' && sptr->next_op[i][m] != '*' && sptr->next_op[i][m] != '}' && sptr->next_op[i][m] != '.' && sptr->next_op[i][m] != '?' && sptr->next_op[i][m] != '[' && sptr->next_op[i][m] != ']'){
        for (t = 0; repetitives[t][0]; t++)
        {
          if(sptr->next_op[i][m] == repetitives[t][0])
            break;
        }
        repetitives[t][0] = sptr->next_op[i][m];
        repetitives[t][1] = '\0';
      }
    }

    /*
     * Parse the PREV OPERATOR line.
     */
    if ((line = my_getline(fp, &len)) == NULL)
      return PREMATURE_EOF;
    else if (strncmp(line, "PREV OPERATOR:", 14) != 0)
      return FORMAT_ERROR;
    for (s=line+14; *s && isspace((int)(*s)); s++) ;
    strncpy(sptr->prev_op[i], s, OP_LENGTH);
    sptr->prev_op[i][OP_LENGTH] = '\0';
    

    /*
     * Parse the NEXT SUBSTRING line.
     */
    if ((line = my_getline(fp, &len)) == NULL)
      return PREMATURE_EOF;
    else if (strncmp(line, "NEXT SUBSTRING:", 15) != 0)
      return FORMAT_ERROR;
    char next_substring[TITLE_LENGTH];
    char **next_sub;
    for (s=line+15; *s && isspace((int)(*s)); s++);
    strncpy(next_substring, s, TITLE_LENGTH);
    next_substring[TITLE_LENGTH] = '\0';
    next_sub = str_split(next_substring, ',');
    for (int j = 0; next_sub[j]; j++)
    {
      sptr->next_substring[i][j] = atoi(next_sub[j]);
    }

    /*
     * Parse the PREV SUBSTRING line.
     */
    if ((line = my_getline(fp, &len)) == NULL)
      return PREMATURE_EOF;
    else if (strncmp(line, "PREV SUBSTRING:", 15) != 0)
      return FORMAT_ERROR;
    char prev_substring[TITLE_LENGTH];
    char **prev_sub;
    for (s=line+15; *s && isspace((int)(*s)); s++);
    strncpy(prev_substring, s, TITLE_LENGTH);
    prev_substring[TITLE_LENGTH] = '\0';
    prev_sub = str_split(prev_substring, ',');
    for (int j = 0; prev_sub[j]; j++)
    {
      sptr->prev_substring[i][j] = atoi(prev_sub[j]);
    }
  }

  /*
   * Parse the LENGTH line.
   */
  if ((line = my_getline(fp, &len)) == NULL)
    return PREMATURE_EOF;
  else if (sscanf(line, "LENGTH: %d", &sptr->length) == 0)
    return FORMAT_ERROR;

  /*
   * Parse the SEQUENCE line.
   */
  if ((line = my_getline(fp, &len)) == NULL)
    return PREMATURE_EOF;
  else if (strcmp(line, "SEQUENCE:") != 0)
    return FORMAT_ERROR;

  /*
   * Allocate the sequence buffers.
   */
  if ((sptr->raw_seq = malloc(sptr->length + 1)) == NULL) {
    fprintf(stderr, "\nRan out of memory.  Unable to store new sequence.\n");
    return ERROR;
  }
  if ((sptr->sequence = malloc(sptr->length + 1)) == NULL) {
    fprintf(stderr, "\nRan out of memory.  Unable to store new sequence.\n");
    return ERROR;
  }

  /*
   * Read the sequence.
   */
  other_chars = 0;
  seqlen = 0;
  while ((line = my_getline(fp, &len)) != NULL && strcmp(line, "//") != 0) {
    for (s=line; *s; s++) {
      ch = rawmapchar(sptr->raw_alpha, *s);
      if (ch == -1)
        return ERROR;
      else if (ch != '\0') {
        if (seqlen == sptr->length) {
          fprintf(stderr, 
                  "\nError: Sequence %s contains too many characters.\n",
                  sptr->title);
          return ERROR;
        }
        sptr->raw_seq[seqlen++] = ch;
      }
      else if (!isspace((int)(*s)))
        other_chars = 1;
    }

    if (newline_ch != '\0' && len < ASCII_MAX_NUM_CHARS &&
        seqlen < sptr->length)
      sptr->raw_seq[seqlen++] = newline_ch;
  }
  
  if (line == NULL)
    return PREMATURE_EOF;

  if (seqlen < sptr->length) {
    fprintf(stderr, "\nError:  Sequence %s contains too few characters.\n",
            sptr->title);
    return ERROR;
  }

  if (other_chars)
    return MISMATCH;
  else{
    return OK;
  }
}


int write_sequence(FILE *fp, STRING *sptr)
{
  int i, j, pos;
  char ch, newline_ch;

  if (sptr->db_type < 0 || sptr->db_type >= TOTAL_DB_NUMBER ||
      sptr->raw_alpha < 0 || sptr->raw_alpha >= TOTAL_ALPHABETS ||
      (newline_ch = rawmapchar(sptr->raw_alpha, '\n')) == -1)
    return FORMAT_ERROR;

  /*
   * Print the header.
   */
  fprintf(fp, "TYPE:  %s\n", db_names[sptr->db_type]);
  fprintf(fp, "IDENT:  %s\n", sptr->ident);
  fprintf(fp, "TITLE:  %s\n", sptr->title);
  fprintf(fp, "ALPHABET:  %s\n", alpha_names[sptr->raw_alpha]);
  for (i = 0; i < sptr->qty; i++)
  {
    fprintf(fp, "SIG:  %d\n", sptr->sig[i]);
    fprintf(fp, "SEQ:  %d\n", sptr->seq[i]);
    fprintf(fp, "NOT:  %c\n", sptr->not_search[i]);
    fprintf(fp, "NEXT OPERATOR:  %s\n", sptr->next_op[i]);
    fprintf(fp, "PREV OPERATOR:  %s\n", sptr->prev_op[i]);
    for (j = 0; sptr->next_substring[i][j]; j++)
    {
      fprintf(fp, "NEXT SUBSTRING[%d]:  %d\n", j, sptr->next_substring[i][j]);
    }
    for (j = 0; sptr->prev_substring[i][j]; j++)
    {
      fprintf(fp, "PREV SUBSTRING[%d]:  %d\n", j, sptr->prev_substring[i][j]);
    }
  }
  fprintf(fp, "LENGTH:  %d\n", sptr->length);
  fprintf(fp, "SEQUENCE:\n");

  /*
   * Print the sequence.
   */
    
  if (newline_ch == '\0') {
    for (i=0; i + NONASCII_NUM_CHARS <= sptr->length; ) {
      for (j=0; j < NONASCII_NUM_CHARS; j++)
        fputc(sptr->raw_seq[i++], fp);
      fputc('\n', fp);
    }
    if (i < sptr->length) {
      while (i < sptr->length)
        fputc(sptr->raw_seq[i++], fp);
      fputc('\n', fp);
    }
  }
  else {
    pos = 0;
    for (i=0; i < sptr->length; i++) {
      ch = sptr->raw_seq[i];
      fputc(ch, fp);
      if (ch == '\n')
        pos = 0;
      else if (++pos == ASCII_MAX_NUM_CHARS) {
        fputc('\n', fp);
        pos = 0;
      }
    }
    fputc('\n', fp);
  }

  fprintf(fp, "//\n");

  return OK;
}

int write_patterns(STRING **sptr, int num_patterns){
  int i, j;
  FILE *fp;

  if ((fp = fopen("patterns.tmp", "w")) == NULL)
  {
      printf("Error opening file!\n");
      exit(1);
  }
  
  for(j = 0; j < num_patterns; j++){
    for (i=0; i < sptr[j]->length; i++) {
      fputc(sptr[j]->raw_seq[i], fp);
    }
    fputc('\n', fp);
  }

  fclose(fp);

  return OK; 
}

int write_pattern(STRING *sptr){
  int i;
  FILE *fp;

  if ((fp = fopen("text.tmp", "w")) == NULL)
  {
      printf("Error opening file!\n");
      exit(1);
  }
  
  for (i=0; i < sptr->length; i++) {
    fputc(sptr->raw_seq[i], fp);
  }

  fclose(fp);

  return OK; 
}