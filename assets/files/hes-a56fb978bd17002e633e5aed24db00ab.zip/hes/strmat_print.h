
#ifndef _STRMAT_PRINT_H_
#define _STRMAT_PRINT_H_

#include "stree_strmat.h"

int large_print_tree(SUFFIX_TREE, STREE_NODE, int);
int small_print_tree(SUFFIX_TREE, STREE_NODE, int, int);

#endif
