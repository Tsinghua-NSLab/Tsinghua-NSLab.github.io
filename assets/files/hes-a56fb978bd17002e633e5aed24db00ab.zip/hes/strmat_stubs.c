#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "strmat.h"
#include "strmat_match.h"
#include "strmat_seqary.h"
#include "ac.h"
#include "bm.h"
#include "bmset_naive.h"
#include "bmset.h"
#include "kmp.h"
#include "naive.h"
#include "z.h"
#include "strmat_fileio.h"
#include "acism.h"

/*
 * strmat_naive_match
 *
 * Performs the exact matching algorithm for a pattern and text using
 * the naive search algorithm.
 *
 * Parameters:   pattern  -  the pattern sequence
 *               text     -  the text sequence
 *               stats    -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */

extern int *matched_patterns_fix;
int text_id;
int seq_start;
int seq_end;

int rhc_text_position[rhcNo][rhcSize];
int next_rhc_name[rhcNo][rhcSize];
int next_rhc_index[rhcNo][rhcSize];

int recentRhcIndeces[rhcNo];
int getRhc[255] = {4};
int currentRhc, oldRhc = 0;

// extern int candidate_state[MAX_CANDIDATES+1][MAX_QTY+1];
// extern OPERATIONS *operations;
// extern CANDIDATE *fix_candidates[2];
// extern int active_candidates_set;
int check_chars(CS_CHECK op, char value);
int get_insertion_index(CANDIDATES *candidates, DELETED_CANDIDATES *deleted_candidates, int candidate_index);
// int satisfied_history(int candidate_index, char* pattern, int pattern_len, CANDIDATE *candidate);
// int op_needs_history(char *operator);
// int check_next_op(char *operator);

int strmat_naive_match(STRING *pattern, STRING *text, int stats)
{
  int M, N, len, pos, flag, matchcount;
  char *s, *P, *T;
  MATCHES matchlist, matchtail, newmatch;
  NAIVE_STRUCT *nstruct;

  if (pattern == NULL || pattern->sequence == NULL || pattern->length == 0 ||
      text == NULL || text->sequence == NULL || text->length == 0)
    return 0;

  P = pattern->sequence;
  M = pattern->length;
  T = text->sequence;
  N = text->length;

  /*
   * "Preprocess" the pattern.
   */
  if ((nstruct = naive_prep(P, M, 0)) == NULL)
    return 0;

  /*
   * Perform the matching.
   */
  matchlist = matchtail = NULL;
  matchcount = 0;

  flag = 0;
  s = T;
  len = N;
  while ((s = naive_search(nstruct, s, len, flag)) != NULL) {
    pos = s - T + 1;

    newmatch = alloc_match();
    if (newmatch == NULL) {
      free_matches(matchlist);
      naive_free(nstruct);
      mprintf("Memory Error:  Ran out of memory.\n");
      return 0;
    }
    newmatch->type = ONESEQ_EXACT;
    newmatch->lend = pos;
    newmatch->rend = pos + M - 1;

    if (matchlist == NULL)
      matchlist = matchtail = newmatch;
    else {
      matchtail->next = newmatch;
      matchtail = newmatch;
    }
    matchcount++;

    len = N - pos;
    flag = 1;
  }

  /*
   * Print the statistics and the matches.
   */
  print_matches(text, NULL, 0, matchlist, matchcount);

  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Text Length:                %d\n", N);
    mprintf("   Number of Comparisons:      %d\n", nstruct->num_compares);
    mprintf("   Avg. Compares per Position: %.2f\n",
            (float) nstruct->num_compares / (float) N);
#else
    mputs("   No statistics available.\n");
#endif
    mputc('\n');
  }

  /*
   * Free everything allocated.
   */
  free_matches(matchlist);
  naive_free(nstruct);

  return 1;
}


/*
 * strmat_bm*_match
 *
 * Performs the exact matching algorithm for a pattern and text using
 * one of the four variations of the Boyer-Moore algorithm.
 *
 * Since the four functions are essentially the same, they've been
 * packaged into one internal procedure that is called by each of 
 * the four functions called by the rest of strmat (i.e., the stubs
 * within the stubs).
 *
 * Parameters:   pattern  -  the pattern sequence
 *               text     -  the text sequence
 *               stats    -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */
static int internal_bm_match(STRING *pattern, STRING *text, int stats,
                             BMALG_TYPE flag);

int strmat_bmbad_match(STRING *pattern, STRING *text, int stats)
{  return internal_bm_match(pattern, text, stats, BM_BAD);  }
int strmat_bmext_match(STRING *pattern, STRING *text, int stats)
{  return internal_bm_match(pattern, text, stats, BM_EXT);  }
int strmat_bmgood_match(STRING *pattern, STRING *text, int stats)
{  return internal_bm_match(pattern, text, stats, BM_GOOD);  }
int strmat_bmextgood_match(STRING *pattern, STRING *text, int stats)
{  return internal_bm_match(pattern, text, stats, BM_EXTGOOD);  }

static int internal_bm_match(STRING *pattern, STRING *text, int stats,
                             BMALG_TYPE flag)
{
  int M, N, len, pos, matchcount;
  char *s, *P, *T;
  MATCHES matchlist, matchtail, newmatch;
  BM_STRUCT *bmstruct;

  if (pattern == NULL || pattern->sequence == NULL || pattern->length == 0 ||
      text == NULL || text->sequence == NULL || text->length == 0)
    return 0;

  P = pattern->sequence;
  M = pattern->length;
  T = text->sequence;
  N = text->length;

  matchlist = matchtail = NULL;
  matchcount = 0;

  /*
   * Do the preprocessing.
   */
  bmstruct = NULL;
  switch (flag) {
  case BM_BAD:     bmstruct = bmbad_prep(P, M, 0);  break;
  case BM_EXT:     bmstruct = bmext_prep(P, M, 0);  break;
  case BM_GOOD:    bmstruct = bmgood_prep(P, M, 0);  break;
  case BM_EXTGOOD: bmstruct = bmextgood_prep(P, M, 0);  break;
  }
  if (bmstruct == NULL) {
    fprintf(stderr, "Error in Boyer-Moore preprocessing.  Stopping search.\n");
    return 0;
  }

  /*
   * Perform the matching.
   */
  s = T;
  len = N;

  switch (flag) {
  case BM_BAD:     s = bmbad_search(bmstruct, s, len, 0);  break;
  case BM_EXT:     s = bmext_search(bmstruct, s, len, 0);  break;
  case BM_GOOD:    s = bmgood_search(bmstruct, s, len, 0);  break;
  case BM_EXTGOOD: s = bmextgood_search(bmstruct, s, len, 0);  break;
  }
  while (s != NULL) {
    pos = s - T + 1;

    newmatch = alloc_match();
    if (newmatch == NULL) {
      free_matches(matchlist);
      bm_free(bmstruct);
      mprintf("Memory Error:  Ran out of memory.\n");
      return 0;
    }
    newmatch->type = ONESEQ_EXACT;
    newmatch->lend = pos;
    newmatch->rend = pos + M - 1;

    if (matchlist == NULL)
      matchlist = matchtail = newmatch;
    else {
      matchtail->next = newmatch;
      matchtail = newmatch;
    }
    matchcount++;

    len = N - pos;
    switch (flag) {
    case BM_BAD:     s = bmbad_search(bmstruct, s, len, 1);  break;
    case BM_EXT:     s = bmext_search(bmstruct, s, len, 1);  break;
    case BM_GOOD:    s = bmgood_search(bmstruct, s, len, 1);  break;
    case BM_EXTGOOD: s = bmextgood_search(bmstruct, s, len, 1);  break;
    }
  }

  /*
   * Print the matches and the statistics.
   */
  print_matches(text, NULL, 0, matchlist, matchcount);

  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Preprocessing Comparisons:  %d\n", bmstruct->prep_compares);
    mprintf("\n");
    mprintf("   Text Length:                %d\n", N);
    mprintf("   Number of Comparisons:      %d\n", bmstruct->num_compares);
    mprintf("   Avg. Compares per Position: %.2f\n",
            (float) bmstruct->num_compares / (float) N);
    mprintf("\n");
    mprintf("   Number of Init. Mismatches: %d\n",
            bmstruct->num_init_mismatch);
    if (bmstruct->num_shifts > bmstruct->num_init_mismatch)
      mprintf("   Average Length of Matches:  %.2f\n",
              (float) (bmstruct->num_compares - 
                       bmstruct->num_shifts + matchcount) / 
              (float) (bmstruct->num_shifts - bmstruct->num_init_mismatch));
    mprintf("   Number of Shifts:           %d\n", bmstruct->num_shifts);
    if (bmstruct->num_shifts != bmstruct->shift_cost)
      mprintf("   Cost of Computing Shifts:   %d\n", bmstruct->shift_cost);
    if (bmstruct->num_shifts > 0)
      mprintf("   Average Shift Length:       %.2f\n", 
              (float) N / (float) bmstruct->num_shifts);
#else
    mprintf("   No statistics available.\n");
#endif
    mputc('\n');
  }

  /*
   * Free everything allocated.
   */
  free_matches(matchlist);
  bm_free(bmstruct);

  return 1;
}


/*
 * strmat_kmp*_match
 *
 * Performs the exact matching algorithm for a pattern and text using
 * one of the four variations of the Knuth-Morris-Pratt algorithm.
 *
 * Since the four functions are essentially the same, they've been
 * packaged into one internal procedure that is called by each of 
 * the four functions called by the rest of strmat (i.e., the stubs
 * within the stubs).
 *
 * Parameters:   pattern  -  the pattern sequence
 *               text     -  the text sequence
 *               stats    -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */
typedef enum { SP_Z, SPPRIME_Z, SP_ORIG, SPPRIME_ORIG } kmp_types;
static int internal_kmp_match(STRING *pattern, STRING *text,
                              int stats, kmp_types flag, OPERATIONS *operations, STRING_REP *str_rep);

int strmat_kmp_sp_z_match(STRING *pattern, STRING *text, int stats, OPERATIONS *operations, STRING_REP *str_rep)
{  return internal_kmp_match(pattern, text, stats, SP_Z, operations, str_rep);  }
int strmat_kmp_spprime_z_match(STRING *pattern, STRING *text, int stats, OPERATIONS *operations, STRING_REP *str_rep)
{  return internal_kmp_match(pattern, text, stats, SPPRIME_Z, operations, str_rep);  }
int strmat_kmp_sp_orig_match(STRING *pattern, STRING *text, int stats, OPERATIONS *operations, STRING_REP *str_rep)
{  return internal_kmp_match(pattern, text, stats, SP_ORIG, operations, str_rep);  }
int strmat_kmp_spprime_orig_match(STRING *pattern, STRING *text, int stats, OPERATIONS *operations, STRING_REP *str_rep)
{  return internal_kmp_match(pattern, text, stats, SPPRIME_ORIG, operations, str_rep);  }

static int internal_kmp_match(STRING *pattern, STRING *text,
                              int stats, kmp_types flag, OPERATIONS *operations, STRING_REP *str_rep)
{
  int candidate_state[MAX_CANDIDATES+1][MAX_QTY+1] = {-1};
  STRING *res;
  int M, N, len, pos, matchcount, matchflag, matchid, i, candidate_index;
  char *s, *P, *T;
  MATCHES matchlist, matchtail, newmatch;
  KMP_STRUCT *kmpstruct;

  if (pattern == NULL || pattern->sequence == NULL || pattern->length == 0 ||
      text == NULL || text->sequence == NULL || text->length == 0)
    return 0;

  P = pattern->sequence;
  M = pattern->length;
  T = text->sequence;
  N = text->length;

  matchlist = matchtail = NULL;
  matchcount = 0;

  /*
   * Do the preprocessing.
   */
  kmpstruct = NULL;
  switch (flag) {
  case SP_Z:          kmpstruct = kmp_sp_z_prep(P, M, 0);  break;
  case SPPRIME_Z:     kmpstruct = kmp_spprime_z_prep(P, M, 0);  break;
  case SP_ORIG:       kmpstruct = kmp_sp_orig_prep(P, M, 0);  break;
  case SPPRIME_ORIG:  kmpstruct = kmp_spprime_orig_prep(P, M, 0);  break;
  }
  if (kmpstruct == NULL) {
    fprintf(stderr, "Error in Knuth-Morris-Pratt preprocessing."
                    "  Stopping search.\n");
    return 0;
  }

  /*
   * Perform the matching.
   */
  s = T;
  len = N;
  matchflag = 0;

  struct timeval stop, start;
  gettimeofday(&start, NULL);

  while ((s = kmp_search(kmpstruct, s, len, matchflag, operations, str_rep)) != NULL) {
    printf("%d\n", matchflag);
    continue;
    pos = s - T + 1;
    res = get_element(matchid);
    for (i = 0; i < res->qty; i++)
      {
        candidate_index = check_sig(res, i, matchid, pos, candidate_state);
        printf("%d\n", candidate_index);
        if(!candidate_index || res->not_search[i] == 't'){
          continue;
        }

        if(candidate_index == 2)
          candidate_state[res->sig[i]][0] = pos;
        if((res->next_substring[i][0] == -1) && (strcmp(res->next_op[i],"BOT") == 0)){
          newmatch = alloc_match();
          if (newmatch == NULL) {
            free_matches(matchlist);
            kmp_free(kmpstruct);
            mprintf("Memory Error:  Ran out of memory.\n");
            return 0;
          }
          newmatch->type = ONESEQ_EXACT;
          newmatch->lend = candidate_state[res->sig[i]][0];
          newmatch->rend = pos + M - 1;
          // newmatch->id = matchid;

          if (matchlist == NULL)
            matchlist = matchtail = newmatch;
          else {
            matchtail->next = newmatch;
            matchtail = newmatch;
          }
          matchcount++;
          len = N - pos;
          matchflag = 1;
        }else{
          candidate_state[res->sig[i]][res->seq[i]] = pos + M;

          if (strchr(res->next_op[i], '+') != NULL){
            // plus_candidates.top[2]++;
            // plus_candidates.tmp_candidates[plus_candidates.top[2]] = insertion_index;
            // candidates.handled[insertion_index] = 1;
          }
        }
      }
    }

  //   newmatch = alloc_match();
  //   if (newmatch == NULL) {
  //     free_matches(matchlist);
  //     kmp_free(kmpstruct);
  //     mprintf("Memory Error:  Ran out of memory.\n");
  //     return 0;
  //   }
  //   newmatch->type = ONESEQ_EXACT;
  //   newmatch->lend = pos;
  //   newmatch->rend = pos + M - 1;

  //   if (matchlist == NULL)
  //     matchlist = matchtail = newmatch;
  //   else {
  //     matchtail->next = newmatch;
  //     matchtail = newmatch;
  //   }
  //   matchcount++;

  //   len = N - pos;
  //   matchflag = 1;
  // }

  gettimeofday(&stop, NULL);
  printf("Took %f milliseconds!\n", (float)((stop.tv_sec * 1000000 + stop.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec))/1000);
  return 0;

  /*
   * Print the statistics and the matches.
   */
  print_matches(text, NULL, 0, matchlist, matchcount);

  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Preprocessing Comparisons:  %d\n", kmpstruct->prep_compares);
    mprintf("\n");
    mprintf("   Text Length:                %d\n", N);
    mprintf("   Number of Comparisons:      %d\n", kmpstruct->num_compares);
    mprintf("   Avg. Compares per Position: %.2f\n",
            (float) kmpstruct->num_compares / (float) N);
    mprintf("\n");
    mprintf("   Number of Init. Mismatches: %d\n",
            kmpstruct->num_init_mismatch);
    mprintf("   Number of Failures:         %d\n", kmpstruct->num_shifts);
    if (kmpstruct->num_shifts > 0)
      mprintf("   Avg. Failure Distance:      %.2f\n",
              (float) kmpstruct->total_shifts / (float) kmpstruct->num_shifts);
#else
    mprintf("   No statistics available.\n");
#endif
    mputc('\n');
  }

  /*
   * Free everything allocated.
   */
  free_matches(matchlist);
  kmp_free(kmpstruct);

  return 1;
}
  

/*
 * strmat_ac_match
 *
 * Performs the Aho-Corasick set matching algorithm for a set of patterns
 * and a text.
 *
 * Parameters:   pattern_ary   -  the pattern sequences
 *               num_patterns  -  the number of patterns
 *               text          -  the text sequence
 *               stats         -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */
int hash(unsigned long base, unsigned char *str, int length, int *ac_lenght, int *text_position, int min_sig_size)
{

  int index = 0;
  int step;
  for (int i = 0; i < length; i++){
    base = ((base << 5) + base) + str[i + *text_position]; /* base * 33 + c */
    if(i + 1 >= min_sig_size){
      // step = Bloom[base % BloomSize];
      if(step > index)
        index = step;
    }
  }
  return index;
}

int strmat_ac_fast_match(STRING **pattern_ary, int num_patterns, STRING *text, int stats, STRING_REP *str_rep, OPERATIONS *operations){
  write_patterns(pattern_ary, num_patterns);
  int ret = acism_x();
  if (ret){
    printf("ERROR in processing patterns!\n");
    return 0;
  }
  write_pattern(text);
  // printf("%d\n", text->);
  ret = acism_mmap_x();
  if (ret){
    printf("ERROR in matching patterns!\n");
    return 0;
  }
}

int strmat_ac_match(STRING **pattern_ary, int num_patterns, STRING *text, int stats, STRING_REP *str_rep, OPERATIONS *operations)
{
  CANDIDATES candidates;
  PLUS_CANDIDATES plus_candidates;
  DELETED_CANDIDATES deleted_candidates;
  int candidate_state[MAX_CANDIDATES+1][MAX_QTY+1] = {-1};
  STRING *res;
  int i, M, N, pos, matchcount, matchlen, matchid, total_length, candidate_index, ac_lenght;
  char *s, *P, *T;
  MATCHES matchlist, matchtail, newmatch;
  AC_STRUCT *acstruct;
  int text_position = 0;
  // CANDIDATES *pivot_candidate;

  if (pattern_ary == NULL || num_patterns == 0 || text == NULL ||
      text->sequence == NULL || text->length == 0)
    return 0;

  T = text->sequence;
  N = text->length;

  matchlist = matchtail = NULL;
  matchcount = 0;

  /*
   * Perform the Aho-Corasick preprocessing.
   */
  if ((acstruct = ac_alloc()) == NULL)
    return 0;

  total_length = 0;
  for (i=0; i < num_patterns; i++) {
    P = pattern_ary[i]->sequence;
    M = pattern_ary[i]->length;
    total_length += M;

    if (ac_add_string(acstruct, P, M, i+1) == 0) {
      ac_free(acstruct);
      return 0;
    }
  }
  ac_prep(acstruct);
  
  getRhc[9] = getRhc[11] = getRhc[12] = getRhc[32] = 0;
  getRhc[10] = getRhc[13] = 1;
  for (int i = 48; i < 58; i++)
    getRhc[i] = 2;
  for (int i = 65; i < 91; i++)
    getRhc[i] = 3;
  for (int i = 97; i < 123; i++)
    getRhc[i] = 3;
  
  for (int i = 0; i < rhcNo; i++)
  {
    for (int j = 0; j < rhcSize; j++)
    {
      rhc_text_position[i][j] = -1;
      next_rhc_name[i][j] = -1;
      next_rhc_index[i][j] = -1;
    }
    recentRhcIndeces[i] = -1;
  }

  /*
   * Perform the matching.
   */
  struct timeval stop, start;
  gettimeofday(&start, NULL);
  // unsigned long ac_start; 
  // int kkkk;
  // while (text_position < N)
  // {
  //   ac_start = hash(5381, T, 10, &ac_lenght, &text_position);
  //   printf("ac_start = %lu\n", ac_start);
  //   // if(ac_start[0] != ac_start[1]){
  //   //   printf("ac_start[0] = %lu, ac_start[1] = %lu\n", ac_start[0], ac_start[1]);
  //   //   return 0;
  //   // }
  //   return 0;
  // }
  // printf("kkkk = %u\n", kkkk);
  // gettimeofday(&stop, NULL);
  // printf("Took %f milliseconds!\n", (float)((stop.tv_sec * 1000000 + stop.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec))/1000);
  // return 0;
  
    // ac_search_init(acstruct, T+ac_start, ac_lenght, str_rep, operations, &candidates, &plus_candidates, &deleted_candidates);
  ac_search_init(acstruct, T, N, str_rep, operations, &candidates, &plus_candidates, &deleted_candidates);
    
    // time_t mytime;
    // mytime = time(NULL);
    // printf ( "Start time: %s",ctime(&mytime));
    // int kkkkk = 0;
    while ((s = ac_search(acstruct, &matchlen, &matchid, str_rep, operations)) != NULL) {
      // kkkkk++;
      // continue;
      // for (int ii = 0; ii < str_rep->top; ii++)
      // {
      //   printf("char = %d, qty = %d\n", str_rep->rep[ii][0], str_rep->rep[ii][1]);
      // }
      // str_rep->top = -1;
      pos = s - T + 1;
      // printf("pos = %d\n", pos);
      res = get_element(matchid);
      // printf("matchid = %d\n", matchid);
      // printf("res->qty = %d\n", res->qty);
      for (i = 0; i < res->qty; i++)
      {
        // printf("sig = %d\n", res->sig[i]);
        // printf("seq = %d\n", res->seq[i]);
        // printf("res->next_op[%d] = %s\n", i, res->next_op[i]);

        // pivot_candidate = candidates[candidate_state[res->sig[i]][res->seq[i]]];

        // int plus_check = 0;
        // if (res->prev_op[i] == '*'){
        //   printf("Star:    %c\n", res->prev_op[i]);
        //   pivot_candidate = star_variable_candidates;
        // }
        // else if (res->prev_op[i] == '+'){
        //   plus_check = 1;
        //   printf("Plus:    %c\n", res->prev_op[i]);
        //   pivot_candidate = &plus_variable_candidates->candidate[(plus_variable_candidates->active_candidate + 1) % 2];
        // }
        // else{
        //   printf("Fix:    %c\n", res->prev_op[i]);
        //   pivot_candidate = &fix_candidates->candidate[(fix_candidates->active_candidate + 1) % 2];
        // }

        // printf("topppp = %d\n", pivot_candidate->top);
        // printf("matchlen = %d\n", matchlen);
        candidate_index = check_sig(res, i, matchid, pos, candidate_state);
        // printf("chandidate index = %d\n", candidate_index);
        if(!candidate_index || res->not_search[i] == 't'){
          continue;
        }

        // int insertion_index = get_insertion_index(&candidates, &deleted_candidates, candidate_index);
        // if(insertion_index == -1)
        //   return 0;
        // printf("insertion_index = %d\n", insertion_index);

        // if((!operations->check_operation) || (candidate_index == MAX_CANDIDATES) || (satisfied_history(candidate_index, res->sequence, matchlen, pivot_candidate))){
        // printf("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\n");
        if(candidate_index == 2)
          candidate_state[res->sig[i]][0] = pos;
        if((res->next_substring[i][0] == -1) && (strcmp(res->next_op[i],"BOT") == 0)){
          newmatch = alloc_match();
          if (newmatch == NULL) {
            free_matches(matchlist);
            ac_free(acstruct);
            mprintf("Memory Error:  Ran out of memory.\n");
            return 0;
          }
          newmatch->type = SET_EXACT;
          newmatch->lend = candidate_state[res->sig[i]][0];
          newmatch->rend = pos + matchlen - 1;
          newmatch->id = matchid;

          if (matchlist == NULL)
            matchlist = matchtail = newmatch;
          else {
            matchtail->next = newmatch;
            matchtail = newmatch;
          }
          matchcount++;
          // if(candidate_index != MAX_CANDIDATES){
          //   deleted_candidates.top++;
          //   deleted_candidates.candidate_index[deleted_candidates.top] = candidate_index;
          //   candidates.deleted[insertion_index] = 1;
          // }
        }else{
          // printf("Insertion index = %d\n", insertion_index);
          candidate_state[res->sig[i]][res->seq[i]] = pos + matchlen;
          // candidates.start_pos[insertion_index] = pos;
          // candidates.pattern_id[insertion_index] = matchid;
          // candidates.sig_id[insertion_index] = i;
          // candidates.deleted[insertion_index] = 0;

          if (strchr(res->next_op[i], '+') != NULL){
            // plus_candidates.top[2]++;
            // plus_candidates.tmp_candidates[plus_candidates.top[2]] = insertion_index;
            // candidates.handled[insertion_index] = 1;
          }
        }
          // if (strchr(res->next_op[i], '*') != NULL){
          //   printf("Star:    %s\n", res->next_op[i]);
          //   int top = star_variable_candidates->top;
          //   star_variable_candidates->pattern_id[top] = matchid;
          //   star_variable_candidates->sig_id[top] = i;
          //   star_variable_candidates->deleted[top] = 0;
          //   if(candidate_index == MAX_CANDIDATES)
          //     star_variable_candidates->start_pos[top] = pos;
          //   star_variable_candidates->top++;
          //   printf("Star tttttoooooopppppp = %d\n", star_variable_candidates->top);
          // }
          // else if (strchr(res->next_op[i], '+') != NULL){
          //   printf("Plus:    %s\n", res->next_op[i]);
          //   int active_candidate = plus_variable_candidates->active_candidate;
          //   int top = plus_variable_candidates->candidate[active_candidate].top;
          //   plus_variable_candidates->candidate[active_candidate].pattern_id[top] = matchid;
          //   plus_variable_candidates->candidate[active_candidate].sig_id[top] = i;
          //   plus_variable_candidates->candidate[active_candidate].deleted[top] = 0;
          //   if(candidate_index == MAX_CANDIDATES)
          //     plus_variable_candidates->candidate[active_candidate].start_pos[top] = pos;
          //   else
          //     plus_variable_candidates->candidate[active_candidate].start_pos[top] = plus_variable_candidates->candidate[(active_candidate + 1) % 2].start_pos[top];
          //   plus_variable_candidates->candidate[active_candidate].top++;
          //   printf("Plus tttttoooooopppppp = %d\n", plus_variable_candidates->candidate[active_candidate].top);
          // }else{
          //   printf("Fix    %s\n", res->next_op[i]);
          //   int active_candidate = fix_candidates->active_candidate;
          //   int top = fix_candidates->candidate[active_candidate].top;
          //   fix_candidates->candidate[active_candidate].pattern_id[top] = matchid;
          //   fix_candidates->candidate[active_candidate].sig_id[top] = i;
          //   fix_candidates->candidate[active_candidate].deleted[top] = 0;
          //   if(candidate_index == MAX_CANDIDATES)
          //     fix_candidates->candidate[active_candidate].start_pos[top] = pos;
          //   else
          //     fix_candidates->candidate[active_candidate].start_pos[top] = fix_candidates->candidate[(active_candidate + 1) % 2].start_pos[top];
          //   fix_candidates->candidate[active_candidate].top++;
          // }
          // printf("active = %d\n", plus_candidates.active_index);
          // printf("Fix tttttoooooopppppp = %d\n", fix_candidates->candidate[active_candidate].top);
        // }
        // }
      }
      // if(op_needs_history(res->next_op[i]))
      //   operations->check_operation = 1;
      //todo
      // plus_variable_candidates->active_candidate = (plus_variable_candidates->active_candidate + 1) % 2;
      // fix_candidates->active_candidate = (fix_candidates->active_candidate + 1) % 2;
      // fix_candidates->candidate[fix_candidates->active_candidate].top = 0;
      // plus_variable_candidates->candidate[plus_variable_candidates->active_candidate].top = 0;
    }
  // }
    // printf("kkkkk = %d\n", kkkkk);
  // mytime = time(NULL);
  // printf ( "End time: %s",ctime(&mytime));
  printf("%d,%d,%d\n",rhc_text_position[0][0], next_rhc_name[0][0], next_rhc_index[0][0]);
  gettimeofday(&stop, NULL);
  printf("Took %f milliseconds!\n", (float)((stop.tv_sec * 1000000 + stop.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec))/1000);
  // printf("Took %f milliseconds!\n", (float)(stop.tv_usec - start.tv_usec)/1000);

  /*
   * Print the statistics and the matches.
   */
  print_matches(text, NULL, 0, matchlist, matchcount);

  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Preprocessing:\n");
    mprintf("      Sum of Pattern Sizes:       %d\n", total_length);
    mprintf("      Number of Created Edges:    %d\n",
            acstruct->prep_new_edges);
    mprintf("      Number of Traversed Edges:  %d\n",
            acstruct->prep_old_edges);
    mprintf("      Failure Link Comparisons:   %d\n",
            acstruct->prep_fail_compares);

    mprintf("\n   Searching:\n");
    mprintf("      Text Length:                %d\n", N);
    mprintf("      Number of Compares:         %d\n", acstruct->num_compares);
    mprintf("      Avg. Compares per Position: %.2f\n",
            (float) acstruct->num_compares / (float) N);
    mprintf("\n");
    mprintf("      Tree Edges Traversed:       %d\n",
            acstruct->edges_traversed);
    mprintf("      Fail Links Traversed:       %d\n", acstruct->num_failures);
    mprintf("      Output Link Traversed:      %d\n",
            acstruct->outlinks_traversed);
#else
    mputs("   No statistics available.\n");
#endif
    mputc('\n');
  }

  /*
   * Free everything allocated.
   */
  free_matches(matchlist);
  ac_free(acstruct);

  return 1;
}


/*
 * strmat_bmset_naive_match
 *
 * Performs the exact matching of a set of patterns and a text by using
 * separate Boyer-Moore matchers for each pattern in the set.  The
 * Boyer-Moore matchers are run in parallel, so that the output matches
 * are produced in order.
 *
 * Parameters:   pattern_ary   -  the pattern sequences
 *               num_patterns  -  the number of patterns
 *               text          -  the text sequence
 *               stats         -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */
int strmat_bmset_naive_match(STRING **pattern_ary, int num_patterns,
                             STRING *text, int stats)
{
  int i, M, N, pos, matchcount, matchlen, matchid, total_length;
  char *s, *P, *T;
#ifdef STATS
  float avg;
#endif
  MATCHES matchlist, matchtail, newmatch;
  BMSET_NAIVE_STRUCT *bmstruct;

  if (pattern_ary == NULL || num_patterns == 0 || text == NULL ||
      text->sequence == NULL || text->length == 0)
    return 0;

  T = text->sequence;
  N = text->length;

  /*
   * Perform the naive Boyer-Moore Set preprocessing.
   */
  if ((bmstruct = bmset_naive_alloc()) == NULL)
    return 0;

  total_length = 0;
  for (i=0; i < num_patterns; i++) {
    P = pattern_ary[i]->sequence;
    M = pattern_ary[i]->length;
    total_length += M;

    if (bmset_naive_add_string(bmstruct, P, M, i+1, 0) == 0) {
      bmset_naive_free(bmstruct);
      return 0;
    }
  }

  /*
   * Perform the matching.
   */
  matchlist = matchtail = NULL;
  matchcount = 0;

  bmset_naive_search_init(bmstruct, T, N);
  while ((s = bmset_naive_search(bmstruct, &matchlen, &matchid)) != NULL) {
    pos = s - T + 1;

    newmatch = alloc_match();
    if (newmatch == NULL) {
      free_matches(matchlist);
      bmset_naive_free(bmstruct);
      mprintf("Memory Error:  Ran out of memory.\n");
      return 0;
    }
    newmatch->type = SET_EXACT;
    newmatch->lend = pos;
    newmatch->rend = pos + matchlen - 1;
    newmatch->id = matchid;

    if (matchlist == NULL)
      matchlist = matchtail = newmatch;
    else {
      matchtail->next = newmatch;
      matchtail = newmatch;
    }
    matchcount++;
  }

  /*
   * Print the matches and the statistics.
   */
  print_matches(text, NULL, 0, matchlist, matchcount);

  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Preprocessing:\n");
    mprintf("      Sum of Pattern Sizes:           %d\n", total_length);
    mprintf("      Preprocessing Comparisons:      %d\n",
            bmstruct->prep_compares);

    mprintf("\n   Searching:\n");
    mprintf("      Text Length:                    %d\n", N);
    mprintf("      Number of Compares:             %d\n",
            bmstruct->num_compares);
    mprintf("      Avg. Compares per Position:     %.2f\n",
            (float) bmstruct->num_compares / (float) N);
    mprintf("\n");
    mprintf("      Number of Shifts:               %d\n",
            bmstruct->num_shifts);
    if (bmstruct->num_shifts > 0) {
      avg = 0.0;
      for (i=0; i < num_patterns; i++)
        avg += (float) N / (float) bmstruct->patterns[i]->num_shifts;

      mprintf("      Avg. Shift Length per Pattern:  %.2f\n",
              avg / (float) num_patterns);
    }
#else
    mputs("   No statistics available.\n");
#endif
    mputc('\n');
  }

  /*
   * Free everything allocated.
   */
  free_matches(matchlist);
  bmset_naive_free(bmstruct);

  return 1;
}


/*
 * strmat_bmset_match
 *
 * Performs the Boyer-Moore Set matching algorithm for a set of patterns
 * and a text.
 *
 * Parameters:   pattern_ary   -  the pattern sequences
 *               num_patterns  -  the number of patterns
 *               text          -  the text sequence
 *               stats         -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */

static int int_strmat_bmset_match(STRING **patterns, int num_patterns,
                                  STRING *text, int stats, BMSETALG_TYPE type);

int strmat_bmset_badonly_match(STRING **patterns, int num_patterns,
                               STRING *text, int stats)
{  return int_strmat_bmset_match(patterns, num_patterns,
                                 text, stats, BMSET_BADONLY);  }
int strmat_bmset_2trees_match(STRING **patterns, int num_patterns,
                              STRING *text, int stats)
{  return int_strmat_bmset_match(patterns, num_patterns,
                                 text, stats, BMSET_2TREES);  }
int strmat_bmset_1tree_match(STRING **patterns, int num_patterns,
                             STRING *text, int stats)
{  return int_strmat_bmset_match(patterns, num_patterns,
                                 text, stats, BMSET_1TREE);  }

static int int_strmat_bmset_match(STRING **patterns, int num_patterns,
                                  STRING *text, int stats, BMSETALG_TYPE type)
{
  int i, M, N, pos, status, matchcount, matchlen, matchid, total_length, candidate_index;
  int candidate_state[MAX_CANDIDATES+1][MAX_QTY+1] = {-1};
  char *s, *P, *T;
  STRING *res;
  MATCHES matchlist, matchtail, newmatch;
  BMSET_STRUCT *bmstruct;

  if (patterns == NULL || num_patterns == 0 || text == NULL ||
      text->sequence == NULL || text->length == 0)
    return 0;

  T = text->sequence;
  N = text->length;

  matchlist = matchtail = NULL;
  matchcount = 0;

  /*
   * Perform the Boyer-Moore set matching preprocessing.
   */
  bmstruct = NULL;
  switch (type) {
  case BMSET_BADONLY:  bmstruct = bmset_badonly_alloc();  break;
  case BMSET_2TREES:   bmstruct = bmset_2trees_alloc();  break;
  case BMSET_1TREE:    bmstruct = bmset_1tree_alloc();  break;
  }
  if (bmstruct == NULL)
    return 0;

  total_length = 0;
  for (i=0; i < num_patterns; i++) {
    P = patterns[i]->sequence;
    M = patterns[i]->length;
    total_length += M;

    status = 0;
    switch (type) {
    case BMSET_BADONLY:  status = bmset_badonly_add_string(bmstruct,
                                                           P, M, i+1);  break;
    case BMSET_2TREES:   status = bmset_2trees_add_string(bmstruct,
                                                          P, M, i+1);  break;
    case BMSET_1TREE:    status = bmset_1tree_add_string(bmstruct,
                                                         P, M, i+1);  break;
    }
    if (status == 0) {
      switch (type) {
      case BMSET_BADONLY:  bmset_badonly_free(bmstruct);  break;
      case BMSET_2TREES:   bmset_2trees_free(bmstruct);  break;
      case BMSET_1TREE:    bmset_1tree_free(bmstruct);  break;
      }
      return 0;
    }
  }

  switch (type) {
  case BMSET_BADONLY:  bmset_badonly_prep(bmstruct);  break;
  case BMSET_2TREES:   bmset_2trees_prep(bmstruct);  break;
  case BMSET_1TREE:    bmset_1tree_prep(bmstruct);  break;
  }

  /*
   * Perform the matching.
   */
  switch (type) {
  case BMSET_BADONLY:  bmset_badonly_search_init(bmstruct, T, N);  break;
  case BMSET_2TREES:   bmset_2trees_search_init(bmstruct, T, N);  break;
  case BMSET_1TREE:    bmset_1tree_search_init(bmstruct, T, N);  break;
  }

  struct timeval stop, start;
  gettimeofday(&start, NULL);
  s = NULL;
  switch (type) {
  case BMSET_BADONLY:  s = bmset_badonly_search(bmstruct,
                                                &matchlen, &matchid);  break;
  case BMSET_2TREES:   s = bmset_2trees_search(bmstruct,
                                               &matchlen, &matchid);  break;
  case BMSET_1TREE:    s = bmset_1tree_search(bmstruct,
                                              &matchlen, &matchid);  break;
  }

  
  while (s != NULL) {
    pos = s - T + 1;
    res = get_element(matchid);
    for (i = 0; i < res->qty; i++)
    {
      candidate_index = check_sig(res, i, matchid, pos, candidate_state);
      if(!candidate_index || res->not_search[i] == 't'){
        continue;
      }

      if(candidate_index == 2)
        candidate_state[res->sig[i]][0] = pos;
      if((res->next_substring[i][0] == -1) && (strcmp(res->next_op[i],"BOT") == 0)){
        newmatch = alloc_match();
        if (newmatch == NULL) {
          free_matches(matchlist);
          switch (type) {
            case BMSET_BADONLY:  bmset_badonly_free(bmstruct);  break;
            case BMSET_2TREES:   bmset_2trees_free(bmstruct);  break;
            case BMSET_1TREE:    bmset_1tree_free(bmstruct);  break;
          }
          mprintf("Memory Error:  Ran out of memory.\n");
          return 0;
        }
        newmatch->type = SET_EXACT;
        newmatch->lend = candidate_state[res->sig[i]][0];
        newmatch->rend = pos + matchlen - 1;
        newmatch->id = matchid;

        if (matchlist == NULL)
          matchlist = matchtail = newmatch;
        else {
          matchtail->next = newmatch;
          matchtail = newmatch;
        }
        matchcount++;
      }else{
        candidate_state[res->sig[i]][res->seq[i]] = pos + matchlen;
        if (strchr(res->next_op[i], '+') != NULL){
        }
      }
    }
    switch (type) {
      case BMSET_BADONLY:  s = bmset_badonly_search(bmstruct,
                                                    &matchlen, &matchid);  break;
      case BMSET_2TREES:   s = bmset_2trees_search(bmstruct,
                                                   &matchlen, &matchid);  break;
      case BMSET_1TREE:    s = bmset_1tree_search(bmstruct,
                                                &matchlen, &matchid);  break;
    }
  }
  gettimeofday(&stop, NULL);
  printf("Took %f milliseconds!\n", (float)((stop.tv_sec * 1000000 + stop.tv_usec) - (start.tv_sec * 1000000 + start.tv_usec))/1000);


  /*
   * Print the matches and the statistics.
   */
  print_matches(text, NULL, 0, matchlist, matchcount);

  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Preprocessing:\n");
    mprintf("       Sum of Pattern Sizes:  %d\n", bmstruct->totallen);
    mprintf("       Tree Construction:     %d\n", bmstruct->prep_tree_ops);
    mprintf("       Value Computation:     %d\n", bmstruct->prep_value_ops);
    mprintf("\n");
    mprintf("   Search:\n"); 
    mprintf("       Text Length:                %d\n", N);
    mprintf("       Number of Comparisons:      %d\n", bmstruct->num_compares);
    mprintf("       Avg. Compares per Position: %.2f\n",
            (float) bmstruct->num_compares / (float) N);
    mprintf("\n");
    mprintf("       Num. Tree Edges Traversed:  %d\n", bmstruct->num_edges);
    mprintf("       Cost of Tree Traversal:     %d\n", bmstruct->edge_cost);
    mprintf("\n");
    mprintf("       Number of Init. Mismatches: %d\n",
            bmstruct->num_init_mismatch);
    if (bmstruct->num_shifts > bmstruct->num_init_mismatch)
      mprintf("       Average Length of Matches:  %.2f\n",
              (float) bmstruct->total_matches / 
              (float) (bmstruct->num_shifts - bmstruct->num_init_mismatch));
    mprintf("\n");
    mprintf("       Number of Shifts:           %d\n", bmstruct->num_shifts);
    mprintf("       Cost of Computing Shifts:   %d\n", bmstruct->shift_cost);
    if (bmstruct->num_shifts > 0)
      mprintf("       Average Shift Length:       %.2f\n", 
              (float) N / (float) bmstruct->num_shifts);
#else
    mputs("   No statistics available.\n");
#endif
    mputc('\n');
  }

  /*
   * Free everything allocated.
   */
  free_matches(matchlist);
  switch (type) {
  case BMSET_BADONLY:  bmset_badonly_free(bmstruct);  break;
  case BMSET_2TREES:   bmset_2trees_free(bmstruct);  break;
  case BMSET_1TREE:    bmset_1tree_free(bmstruct);  break;
  }

  return 1;
}


/*
 * strmat_z_build
 *
 * Build the Z values for a string and output those values (and stats).
 *
 * Parameters:   string  -  a sequence
 *               stats   -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */
int strmat_z_build(STRING *string, int stats)
{
  int i, len, *Z;
  char format[64], buffer[64];
  Z_STRUCT *zvalues;

  if (string == NULL || string->sequence == NULL || string->length == 0)
    return 0;

  /*
   * Compute the Z values for the sequence.
   */
  zvalues = z_build(string->sequence, string->length, 0);
  if (zvalues == NULL) {
    fprintf(stderr, "Error during Z values construction.\n");
    return 0;
  }

  /*
   * Print the non-zero Z values.
   */
  Z = zvalues->Z;

  sprintf(format, "%d", string->length);
  len = strlen(format);
  sprintf(format, "   Position %%%dd: %%%dd - %%s\n", len, len);

  buffer[30] = '.';
  buffer[31] = '.';
  buffer[32] = '.';
  buffer[33] = '\0';

  mprintf("Z Values (non-zero values only):\n");
  for (i=2; i <= string->length; i++) {
    if (Z[i] == 0)
      continue;

    if (Z[i] < 30) {
      strncpy(buffer, string->raw_seq + i - 1, Z[i]);
      buffer[Z[i]] = '\0';
    }
    else
      strncpy(buffer, string->raw_seq + i - 1, 30);
      
    if (mprintf(format, i, Z[i], buffer) == 0) {
      z_free(zvalues);
      return 1;
    }
  }
  mputc('\n');

  /*
   * Print the statistics for the sequence.
   */
  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Text Length:           %d\n", string->length);
    mprintf("   Number of Comparisons: %d\n\n", zvalues->prep_compares);
#else
    mprintf("   No statistics available.\n\n");
#endif
  }

  z_free(zvalues);

  return 1;
}



/*
 * strmat_z_match
 *
 * Performs the exact matching algorithm for a pattern and text using
 * the Z values matching algorithm.
 *
 * Parameters:   pattern  -  the pattern sequence
 *               text     -  the text sequence
 *               stats    -  should stats be printed
 *
 * Returns:  non-zero on success, zero on an error.
 */
int strmat_z_match(STRING *pattern, STRING *text, int stats)
{
  int M, N, len, pos, flag, matchcount;
  char *s, *P, *T;
  MATCHES matchlist, matchtail, newmatch;
  Z_STRUCT *zvalues;

  if (pattern == NULL || pattern->sequence == NULL || pattern->length == 0 ||
      text == NULL || text->sequence == NULL || text->length == 0)
    return 0;

  P = pattern->sequence;
  M = pattern->length;
  T = text->sequence;
  N = text->length;

  /*
   * Compute the Z values of the pattern.
   */
  if ((zvalues = z_build(P, M, 0)) == NULL)
    return 0;

  /*
   * Perform the matching.
   */
  matchlist = matchtail = NULL;
  matchcount = 0;
  flag = 0;
  s = T;
  len = N;
  while ((s = z_search(zvalues, s, len, flag)) != NULL) {
    pos = s - T + 1;

    newmatch = alloc_match();
    if (newmatch == NULL) {
      free_matches(matchlist);
      z_free(zvalues);
      mprintf("Memory Error:  Ran out of memory.\n");
      return 0;
    }
    newmatch->type = ONESEQ_EXACT;
    newmatch->lend = pos;
    newmatch->rend = pos + M - 1;

    if (matchlist == NULL)
      matchlist = matchtail = newmatch;
    else {
      matchtail->next = newmatch;
      matchtail = newmatch;
    }
    matchcount++;

    len = N - pos;
    flag = 1;
  }

  /*
   * Print the statistics and the matches.
   */
  print_matches(text, NULL, 0, matchlist, matchcount);

  if (stats) {
    mprintf("Statistics:\n");
#ifdef STATS
    mprintf("   Pattern Length:             %d\n", M);
    mprintf("   Preprocessing Comparisons:  %d\n", zvalues->prep_compares);
    mprintf("   Text Length:                %d\n", N);
    mprintf("   Number of Comparisons:      %d\n", zvalues->num_compares);
    mprintf("   Avg. Compares per Position: %.2f\n",
            (float) zvalues->num_compares / (float) N);
#else
    mputs("   No statistics available.\n");
#endif
    mputc('\n');
  }

  /*
   * Free everything allocated.
   */
  free_matches(matchlist);
  z_free(zvalues);

  return 1;
}

int check_sig(STRING *str, int res_idx, int pattern_id, int pos, int candidate_state[MAX_CANDIDATES+1][MAX_QTY+1]){
  STRING *text = get_element(text_id);
  for (int k = 0; str->prev_substring[res_idx][k]; k++){
    int prev_posLength = candidate_state[str->sig[res_idx]][str->prev_substring[res_idx][k]];
  // for (int i = 0; i < MAX_CANDIDATES; i++){
  //   for (int j = 0; j < MAX_QTY; j++)
  //     printf("%d", candidate_state[i][j]);
  //   printf("\n");
  // }
    if (prev_posLength == -1)
      continue;
    if(str->seq[res_idx] == 1)
      return 2;
    // printf("candidate pattern id = %d\n", candidates->pattern_id[index]);
    // printf("pattern id = %d\n", pattern_id);
    // if(candidate->deleted[i] == 1)
    //   continue;
    // printf("pattern i = %d\n", pattern_id);
    // STRING *res = get_element(candidates->pattern_id[index]);

    // for (int j = 0; res->next_substring[candidates->sig_id[index]][j]; j++)
    // {
    // printf("index = %d\n", index);
    // printf("res->sig[candidates->sig_id[index]] = %d\n", res->sig[candidates->sig_id[index]]);
    // printf("str->sig[res_idx] = %d\n", str->sig[res_idx]);
    // printf("res->next_substring[candidates->sig_id[index]][j] = %d\n", res->next_substring[candidates->sig_id[index]][j]);
    // printf("str->seq[res_idx] = %d\n", str->seq[res_idx]);
    // printf("candidates->deleted[index] = %d\n", candidates->deleted[index]);
    // if((res->sig[candidates->sig_id[index]] == str->sig[res_idx]) && (res->next_substring[candidates->sig_id[index]][j] == str->seq[res_idx]) && (!candidates->deleted[index])){
      // printf("RRR RRRRRRRRRRRR RRRRRRRRRRRRRRR\n");
      // printf("pos %d\n", pos);
      // printf("candidates->start_pos[index] = %d\n", candidates->start_pos[index]);
      // printf("res->length = %d\n", res->length);
    // printf("prev_pos = %d $$$$$$$$$$$$$ pos = %d\n", prev_posLength + str->length, pos);
    if(prev_posLength + str->length <= pos){
      if(strcmp(str->prev_op[res_idx], "BOT") == 0){
        if(prev_posLength + str->length == pos){
      // if(sizeof(res->next_substring[candidates->sig_id[index]]) == 1){
      //   candidate_state[str->sig[res_idx]][str->prev_substring[res_idx][k]] = -1
      // //   deleted_candidates->top++;
      // //   deleted_candidates->candidate_index[deleted_candidates->top] = index;
      // //   candidates->deleted[index] = 1;
      // }
          return 1;
        }
      // }else{
      //   continue;
      }else if(strcmp(str->prev_op[res_idx], ".*") == 0){
        return 1;
      }else{
        int op_id = 0, i, j;
        CS_CHECK cs_check[10];
        j = 0;
        for(i = 0; i < strlen(str->prev_op[res_idx]); i++){
          cs_check[j].cs = 0;
          if(str->prev_op[res_idx][i] == '\\'){
            cs_check[j].cs = 1;
            i++;
          }
          cs_check[j].chr = str->prev_op[res_idx][i];
          if(str->prev_op[res_idx][i+1] == '*' || str->prev_op[res_idx][i+1] == '+'){
            i++;
            cs_check[j].po = str->prev_op[res_idx][i];
          }else{
            cs_check[j].po = 'F';
          }
          cs_check[j].match = 0;
          if(cs_check[j].po == '*')
            cs_check[j].match = 1;
          j++;
        }
        for(i = prev_posLength - 1; i < pos - 1; i++){
          if(op_id == j){
            return 0;
          }
          if(!check_chars(cs_check[op_id], text->sequence[i])){
            if((cs_check[op_id].match == 0) || (op_id == (j - 1))){
              return 0;
            }else{
              op_id++;
              if(!check_chars(cs_check[op_id], text->sequence[i])){
                return 0;
              }else{
                cs_check[op_id].match = 1;
              }
            }
          }else{
            cs_check[op_id].match = 1;
          }
          if(cs_check[op_id].match == 1 && cs_check[op_id].po == 'F')
            op_id++;
        }
        return 1;
    //   // if(sizeof(res->next_substring[candidates->sig_id[index]]) == 1){
    //   //   deleted_candidates->top++;
    //   //   deleted_candidates->candidate_index[deleted_candidates->top] = index;
    //   //   candidates->deleted[index] = 1;
    //   // }
    //   return 1;
    // }else if(str->prev_op[res_idx] == '+'){
    //   //todo
    //   // if(sizeof(res->next_substring[candidates->sig_id[index]]) == 1){
    //   //   deleted_candidates->top++;
    //   //   deleted_candidates->candidate_index[deleted_candidates->top] = index;
    //   //   candidates->deleted[index] = 1;
    //   // }
    // }
      // }
      }
    }
  }
  return 0;
}

// int get_insertion_index(CANDIDATES *candidates, DELETED_CANDIDATES *deleted_candidates, int candidate_index){
//   if(((candidate_index == MAX_CANDIDATES) && (deleted_candidates->top > -1)) || ((candidate_index != MAX_CANDIDATES) && (candidates->deleted[candidate_index]))){
//     deleted_candidates->top--;
//     return deleted_candidates->candidate_index[deleted_candidates->top+1];
//   }else{
//     candidates->top++;
//     if(candidates->top > MAX_CANDIDATES){
//       printf("Out of candidate index!\n");
//       return -1;
//     }
//     return candidates->top;
//   }
// }
int check_chars(CS_CHECK op, char value){
  if(op.cs = 1)
    if ((op.chr == 'd') && ((int)value >= 48 && (int)value <= 57))
      return 1;
    if ((op.chr == 's') && ((int)value == 32))
      return 1;
    if ((op.chr == 'l') && ((int)value >= 97 && (int)value <= 122))
      return 1;
    if ((op.chr == 'L') && ((int)value >= 65 && (int)value <= 90))
      return 1;
    else
      if (op.chr == value)
      return 1;
  return 0;
}

// int satisfied_history(int candidate_index, char* pattern, int pattern_len, CANDIDATE *candidate){
//   int i, sw = 0;
//   int checkable_chars[256];
  
//   // for (i = 0; i < 256; i++)
//   //   checkable_chars[i] = matched_chars[i];
//   if(candidate_index > -1 && candidate_index < MAX_CANDIDATES){
//     // candidate[active_candidates_set].handled[candidate_index] = 1;
//     for (i = 0; i < pattern_len; i++)
//       checkable_chars[(int) pattern[i]]--;
//   }
  
//   for (i = 0; i < 256; i++){
//     if(checkable_chars[i] > 0)
      
//       if(!matchable_chars1('d', i))
//         return 0;
//       else
//         sw++;
//   }
//   if(sw) // || todo
//     return 1;
//   return 0;
// }

// int op_needs_history(char *operator){
//   //todo
//   return 1;
// }

// int check_next_op(char *operator){
//   if (strchr(operator, '*') != NULL)
//     return 1;
//   else if (strchr(operator, '+') != NULL)
//     return 2;
//   return 0;
// }