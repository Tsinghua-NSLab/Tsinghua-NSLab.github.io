
int strmat_sary_qsort(STRING *string, int print_stats);
int strmat_sary_zerkle(STRING *string, int print_stats);
int strmat_sary_stree(STRING *string, int print_stats);
int strmat_sary_match_naive(STRING *pattern, STRING *text, int stats);
int strmat_sary_match_mlr(STRING *pattern, STRING *text, int stats);
int strmat_sary_match_lcp(STRING *pattern, STRING *text, int stats);
