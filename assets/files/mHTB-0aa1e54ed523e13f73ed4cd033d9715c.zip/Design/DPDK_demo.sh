sudo -E ./build/DPDK_demo -c 0xf -n 4 

