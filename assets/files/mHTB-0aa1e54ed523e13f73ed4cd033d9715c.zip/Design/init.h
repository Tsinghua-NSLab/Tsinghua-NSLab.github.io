/*
 * init.h
 *
 *  Created on: Dec 19, 2017
 *      Author: jake
 *  Usage: Initialize the program with parameters, and Set the global variables
 */

#ifndef INIT_H_
#define INIT_H_

/* Define functions for others*/
int init_parse_args(int argc, char **argv);


#endif /* INIT_H_ */
