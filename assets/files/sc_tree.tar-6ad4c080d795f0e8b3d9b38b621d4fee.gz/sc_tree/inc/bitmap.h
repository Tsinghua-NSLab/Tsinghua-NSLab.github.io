#ifndef __BITMAP_H__
#define __BITMAP_H__

int init_bitmap(void);
int term_bitmap(void);

int insert_bitmap(void *bmp);
int remove_bitmap(void *bmp);
int search_bitmap(void *bmp, int *idx);

void *get_bitmap_base(void);

#endif /* __BITMAP_H__ */
