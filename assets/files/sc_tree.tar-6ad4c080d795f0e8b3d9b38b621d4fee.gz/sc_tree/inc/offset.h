#ifndef __OFFSET_H__
#define __OFFSET_H__

int init_offset(void);
int term_offset(void);

int insert_offset(void *off);
int remove_offset(void *off);
int search_offset(void *off, int *idx);

void *get_offset_base(void);

#endif /* __OFFSET_H__ */
