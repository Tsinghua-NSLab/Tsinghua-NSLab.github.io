#ifndef __RULE_H__
#define __RULE_H__

#include <stdio.h>
#include <stdint.h>

#define RULE_MAX (1 << 14) /* 16K rules */
#define RULE_FMT "@%u.%u.%u.%u/%u %u.%u.%u.%u/%u %u : %u %u : %u %x/%x\n"

enum {
    DIM_INVALID = -1,
    DIM_SIP = 0,
    DIM_DIP = 1,
    DIM_SPORT = 2,
    DIM_DPORT = 3,
    DIM_PROTO = 4,
    DIM_MAX = 5
};

struct range {
    uint32_t begin;
    uint32_t end;
};

struct space {
    struct range dimension[DIM_MAX];
};

struct rule {
    struct space match;
    int action;
    int priority;
};

struct rule_set {
    struct rule *rules;
    int rule_number;
};

int load_rules(struct rule_set *rs, FILE *fp);
void unload_rules(struct rule_set *rs);

#endif /* __RULE_H__ */
