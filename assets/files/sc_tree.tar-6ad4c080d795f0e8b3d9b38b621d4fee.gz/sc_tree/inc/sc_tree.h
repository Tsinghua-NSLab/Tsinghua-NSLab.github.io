#ifndef __SC_TREE_H__
#define __SC_TREE_H__

#include "queue.h"
#include "rule.h"

/* using 256 fixed-stride cutting strategy */
#define CUTS_BITS_BITS 8
#define CUTS_BITS (1 << CUTS_BITS_BITS)

/* 64-bit bitmap or 256-bit bitmap compress space mappings */
#define BMP_BITS_BITS 8 /* 6 or 8 */
#define BMP_BITS (1 << BMP_BITS_BITS)
#define BMP_BYTES (1 << (BMP_BITS_BITS - 3))
#define STEP_BITS (1 << (CUTS_BITS_BITS - BMP_BITS_BITS))

/* bit numbers of elements in tree node */
#define B2C_BITS 4
#define BMP_ID_BITS 13
#define OFF_ID_BITS 10
#define NODE_ID_BITS 37
#define ACT_BITS 4
#define PRI_BITS 56

/* decision */
union tree_node {
    uint64_t u64;
    struct {
        uint64_t byte2cut :B2C_BITS;
        uint64_t bitmap_id :BMP_ID_BITS;
        uint64_t offset_id :OFF_ID_BITS;
        uint64_t node_id :NODE_ID_BITS;
    } internal;
    struct {
        uint64_t byte2cut :B2C_BITS;
        uint64_t action :ACT_BITS;
        uint64_t priority :PRI_BITS;
    } leaf;
};

struct decision {
    union tree_node *root;
    int internal_number;
    int leaf_number;

    uint8_t (*bitmap)[BMP_BYTES];
    int bitmap_number;

    uint8_t (*offset)[BMP_BITS];
    int offset_number;
    unsigned int offset_length;
};

/* cutting */
struct state {
    /* remaining rule set */
    int *rule_ids;
    int rule_number;

    /* remaining search space */
    struct space space;
    char bytes[DIM_MAX];

    /* related node */
    union tree_node *node;

    STAILQ_ENTRY(state) next;
};

struct cut {
    int *rule_ids[CUTS_BITS];
    int rule_number[CUTS_BITS];

    char is_full_cover[CUTS_BITS];

    int16_t uspace2sspace[CUTS_BITS];
    int16_t sspace2uspace[CUTS_BITS];

    int interval;
    unsigned int measure;
};

#endif /* __SC_TREE_H__ */
