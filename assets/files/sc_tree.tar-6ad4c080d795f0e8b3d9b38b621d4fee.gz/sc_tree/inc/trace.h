#ifndef __TRACE_H__
#define __TRACE_H__

#include "rule.h"

#define PKT_MAX (1 << 17) /* 128K packets */
#define PKT_FMT "%u %u %u %u %u %d\n"

struct packet {
    uint32_t value[DIM_MAX];
    int match;
};

struct trace {
    struct packet *packets;
    int packet_number;
};

int load_trace(struct trace *t, FILE *fp);
void unload_trace(struct trace *t);

#endif /* __TRACE_H__ */
