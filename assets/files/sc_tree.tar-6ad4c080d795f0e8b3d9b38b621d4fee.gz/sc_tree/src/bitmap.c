#include <string.h>
#include "hashtable.h"
#include "jhash.h"
#include "objpool.h"
#include "sc_tree.h"
#include "bitmap.h"

static inline void *entry_alloc(void);
static inline void entry_free(void *p);
static inline void *bmp_alloc(void);
static inline void bmp_free(void *p);
static inline unsigned long bmp_hashfn(void *k);
static inline int bmp_eqfn(void *k1, void *k2);

static objpool_t entry_pool;
static objpool_t bmp_pool;
static struct hash_table bmp_ht = {
    -1, 1 << BMP_ID_BITS, 0, 0,
    entry_alloc, entry_free,
    BMP_BYTES, bmp_alloc, bmp_free,
    0, NULL, NULL,
    NULL, bmp_hashfn, bmp_eqfn,
    NULL
};

int init_bitmap(void)
{
    if (objpool_init(&entry_pool, sizeof(struct hash_entry),
        1 << BMP_ID_BITS) != 0) {
        return -1;
    }
    if (objpool_init(&bmp_pool, BMP_BYTES, 1 << BMP_ID_BITS) != 0) {
        return -1;
    }

    if (hashtable_create(&bmp_ht) != 0) {
        return -1;
    }

    return 0;
}

int term_bitmap(void)
{
    int ret;

    ret = hashtable_destroy(&bmp_ht);
    objpool_term(&bmp_pool);
    objpool_term(&entry_pool);

    return ret;
}

int insert_bitmap(void *bmp)
{
    return hashtable_insert(&bmp_ht, bmp, NULL);
}

int remove_bitmap(void *bmp)
{
    return hashtable_remove(&bmp_ht, bmp);
}

int search_bitmap(void *bmp, int *idx)
{
    int ret;
    struct hash_entry *e;

    ret = hashtable_search(&bmp_ht, bmp, &e);
    if (ret == 0) {
        *idx = (e->key - objpool_base(&bmp_pool)) >> (BMP_BITS_BITS - 3);
    }

    return ret;
}

void *get_bitmap_base(void)
{
    return objpool_base(&bmp_pool);
}

static inline void *entry_alloc(void)
{
    return objpool_malloc(&entry_pool);
}

static inline void entry_free(void *p)
{
    return objpool_free(&entry_pool, p);
}

static inline void *bmp_alloc(void)
{
    return objpool_malloc(&bmp_pool);
}

static inline void bmp_free(void *p)
{
    return objpool_free(&bmp_pool, p);
}

static inline unsigned long bmp_hashfn(void *k)
{
    return jhash2(k, BMP_BYTES >> 2, 0);
}

static inline int bmp_eqfn(void *k1, void *k2)
{
    return memcmp(k1, k2, BMP_BYTES) == 0;
}
