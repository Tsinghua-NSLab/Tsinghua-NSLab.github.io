#include <string.h>
#include "hashtable.h"
#include "jhash.h"
#include "objpool.h"
#include "sc_tree.h"
#include "offset.h"

static inline void *entry_alloc(void);
static inline void entry_free(void *p);
static inline void *off_alloc(void);
static inline void off_free(void *p);
static inline unsigned long off_hashfn(void *k);
static inline int off_eqfn(void *k1, void *k2);

static objpool_t entry_pool;
static objpool_t off_pool;
static struct hash_table off_ht = {
    -1, 1 << OFF_ID_BITS, 0, 0,
    entry_alloc, entry_free,
    BMP_BITS, off_alloc, off_free,
    0, NULL, NULL,
    NULL, off_hashfn, off_eqfn,
    NULL
};

int init_offset(void)
{
    if (objpool_init(&entry_pool, sizeof(struct hash_entry),
        1 << OFF_ID_BITS) != 0) {
        return -1;
    }
    if (objpool_init(&off_pool, BMP_BITS, 1 << OFF_ID_BITS) != 0) {
        return -1;
    }

    if (hashtable_create(&off_ht) != 0) {
        return -1;
    }

    return 0;
}

int term_offset(void)
{
    int ret;

    ret = hashtable_destroy(&off_ht);
    objpool_term(&off_pool);
    objpool_term(&entry_pool);

    return ret;
}

int insert_offset(void *off)
{
    return hashtable_insert(&off_ht, off, NULL);
}

int remove_offset(void *off)
{
    return hashtable_remove(&off_ht, off);
}

int search_offset(void *off, int *idx)
{
    int ret;
    struct hash_entry *e;

    ret = hashtable_search(&off_ht, off, &e);
    if (ret == 0) {
        *idx = (e->key - objpool_base(&off_pool)) >> BMP_BITS_BITS;
    }

    return ret;
}

void *get_offset_base(void)
{
    return objpool_base(&off_pool);
}

static inline void *entry_alloc(void)
{
    return objpool_malloc(&entry_pool);
}

static inline void entry_free(void *p)
{
    return objpool_free(&entry_pool, p);
}

static inline void *off_alloc(void)
{
    return objpool_calloc(&off_pool);
}

static inline void off_free(void *p)
{
    return objpool_free(&off_pool, p);
}

static inline unsigned long off_hashfn(void *k)
{
    return jhash2(k, BMP_BITS >> 2, 0);
}

static inline int off_eqfn(void *k1, void *k2)
{
    return memcmp(k1, k2, BMP_BITS) == 0;
}
