#include <stdlib.h>
#include "rule.h"

#define swap(a, b) \
    do { typeof(a) __tmp = (a); (a) = (b); (b) = __tmp; } while (0)

int load_rules(struct rule_set *rs, FILE *fp)
{
    uint32_t src_ip, src_ip_0, src_ip_1, src_ip_2, src_ip_3, src_ip_mask;
    uint32_t dst_ip, dst_ip_0, dst_ip_1, dst_ip_2, dst_ip_3, dst_ip_mask;
    uint32_t src_port_begin, src_port_end, dst_port_begin, dst_port_end;
    uint32_t proto, proto_mask;
    unsigned int i = 0;

    rs->rules = malloc(sizeof(struct rule) * RULE_MAX);
    if (rs->rules == NULL) {
        perror("Cannot allocate memory for rules");
        return -1;
    }
    rs->rule_number = 0;

    while (!feof(fp)) {
        if (i >= RULE_MAX) {
            printf("Too many rules\n");
            return -1;
        }

        if (fscanf(fp, RULE_FMT,
            &src_ip_0, &src_ip_1, &src_ip_2, &src_ip_3, &src_ip_mask,
            &dst_ip_0, &dst_ip_1, &dst_ip_2, &dst_ip_3, &dst_ip_mask,
            &src_port_begin, &src_port_end, &dst_port_begin, &dst_port_end,
            &proto, &proto_mask) != 16) {
            perror("Illegal rule format");
            return -1;
        }

        /* src ip */
        src_ip = ((src_ip_0 & 0xff) << 24) | ((src_ip_1 & 0xff) << 16) |
            ((src_ip_2 & 0xff) << 8) | (src_ip_3 & 0xff);
        src_ip_mask = src_ip_mask > 32 ? 32 : src_ip_mask;
        src_ip_mask = (uint32_t)(~((1ULL << (32 - src_ip_mask)) - 1));
        rs->rules[i].match.dimension[DIM_SIP].begin = src_ip & src_ip_mask;
        rs->rules[i].match.dimension[DIM_SIP].end = src_ip | (~src_ip_mask);

        /* dst ip */
        dst_ip = ((dst_ip_0 & 0xff) << 24) | ((dst_ip_1 & 0xff) << 16) |
            ((dst_ip_2 & 0xff) << 8) | (dst_ip_3 & 0xff);
        dst_ip_mask = dst_ip_mask > 32 ? 32 : dst_ip_mask;
        dst_ip_mask = (uint32_t)(~((1ULL << (32 - dst_ip_mask)) - 1));
        rs->rules[i].match.dimension[DIM_DIP].begin = dst_ip & dst_ip_mask;
        rs->rules[i].match.dimension[DIM_DIP].end = dst_ip | (~dst_ip_mask);

        /* src port */
        rs->rules[i].match.dimension[DIM_SPORT].begin = src_port_begin & 0xffff;
        rs->rules[i].match.dimension[DIM_SPORT].end = src_port_end & 0xffff;
        if (rs->rules[i].match.dimension[DIM_SPORT].begin >
            rs->rules[i].match.dimension[DIM_SPORT].end) {
            swap(rs->rules[i].match.dimension[DIM_SPORT].begin,
                rs->rules[i].match.dimension[DIM_SPORT].end);
        }

        /* dst port */
        rs->rules[i].match.dimension[DIM_DPORT].begin = dst_port_begin & 0xffff;
        rs->rules[i].match.dimension[DIM_DPORT].end = dst_port_end & 0xffff;
        if (rs->rules[i].match.dimension[DIM_DPORT].begin >
            rs->rules[i].match.dimension[DIM_DPORT].end) {
            swap(rs->rules[i].match.dimension[DIM_DPORT].begin,
                rs->rules[i].match.dimension[DIM_DPORT].end);
        }

        /* proto */
        if (proto_mask == 0xff) {
            rs->rules[i].match.dimension[DIM_PROTO].begin = proto;
            rs->rules[i].match.dimension[DIM_PROTO].end = proto;
        } else if (proto_mask == 0) {
            rs->rules[i].match.dimension[DIM_PROTO].begin = 0;
            rs->rules[i].match.dimension[DIM_PROTO].end = 0xff;
        } else {
            printf("Protocol mask error: %02x\n", proto_mask);
            return -1;
        }

        rs->rules[i].action = 0;

        rs->rules[i].priority = i;

        rs->rule_number++;
        i++;
    }

    return 0;
}

void unload_rules(struct rule_set *rs)
{
    free(rs->rules);
    return;
}
