#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>

#include "objpool.h"
#include "utils.h"
#include "bitmap.h"
#include "offset.h"
#include "trace.h"
#include "sc_tree.h"

#define SSPACE_INVALID (-1)

/* functions in main */
static void print_help(void);
static int parse_args(int argc, char *argv[]);
static void compile_rules(char *argv[]);
static void revert_tree(char *argv[]);
static void dump_tree(char *argv[]);
static void classify_traces(char *argv[]);
static void cleanup(void);

/* core functions in compile_rules and classify_traces */
static int building(void);
static int searching(void);

/* functions in building */
static int init_trigger(struct state *state);
static inline int is_state_cutable(struct state *state);
static inline void cut_in_state(struct state *state);
static inline void build_leaf_node(struct state *state);

/* functions auxiliary */
static inline int is_range_full_cover(struct range *upper,
        struct range *lower);
static inline int is_range_not_cover(struct range *upper,
        struct range *lower);
static inline int is_rule_ids_same(int *rule_ids_a, int rule_number_a,
        int *rule_ids_b, int rule_number_b);
static inline void structural_compression(int *bmp_id, int *off_id,
        int *off_len, int16_t *us2ss);
static inline char dim2byte(int cut_dim, int cut_byte);
static inline void byte2dim(int *cut_dim, int *cut_bits, int byte);
static inline long popcount(register uint64_t *bitmap, register long prefix);


/* global variables */
static struct {
    char *rule_file;
    char *trace_file;
    char *input_file;
    char *output_file;
} sc_tree_cfg;

static struct rule_set sc_rule_set;
static struct trace sc_trace;
static struct decision sc_decision;
static long child_id;

static objpool_t node_pool;
static objpool_t state_pool;

static STAILQ_HEAD(, state) sc_state_queue =
    STAILQ_HEAD_INITIALIZER(sc_state_queue);
static struct cut sc_cuts[DIM_MAX];


int main(int argc, char *argv[])
{
    if (argc < 2) {
        print_help();
        exit(-1);
    }

    if (parse_args(argc, argv) < 0) {
        exit(-1);
    }

    if (sc_tree_cfg.rule_file != NULL) {
        compile_rules(argv);
    } else if (sc_tree_cfg.input_file != NULL) {
        revert_tree(argv);
    } else {
        printf("No rules and no data for processing\n");
        exit(-1);
    }

    if (sc_tree_cfg.output_file != NULL) {
        dump_tree(argv);
    }

    if (sc_tree_cfg.trace_file != NULL) {
        classify_traces(argv);
    }

    cleanup();

    return 0;
}

static void print_help(void)
{
    static const char *help =
        "Usage: sc_tree [OPTION]\n"
        "Structural compressed tree for packet classification\n"
        "\n"
        "Valid options:\n"
        "  -h, --help         display this help and exit\n"
        "  -r, --rule FILE    specify a rule file for building\n"
        "  -t, --trace FILE   specify a trace file for searching\n"
        "  -i, --input FILE   specify a input file for reverting\n"
        "  -o, --output FILE   specify a ouput file for dumping\n"
        "\n";

    printf("%s", help);
    return;
}

static int parse_args(int argc, char *argv[])
{
    int option;
    static const char *optstr = "hr:t:i:o:";
    static struct option longopts[] = {
        {"help", no_argument, NULL, 'h'},
        {"rule", required_argument, NULL, 'r'},
        {"trace", required_argument, NULL, 't'},
        {"input", required_argument, NULL, 'i'},
        {"output", required_argument, NULL, 'o'},
        {NULL, 0, NULL, 0}
    };

    while ((option = getopt_long(argc, argv, optstr, longopts, NULL)) != -1) {
        switch (option) {
        case 'h':
            print_help();
            exit(0);

        case 'r':
        case 't':
        case 'i':
            if (access(optarg, F_OK) == -1) {
                perror(optarg);
                exit(-1);
            } else {
                if (option == 'r') {
                    sc_tree_cfg.rule_file = optarg;
                } else if (option == 't') {
                    sc_tree_cfg.trace_file = optarg;
                } else if (option == 'i') {
                    sc_tree_cfg.input_file = optarg;
                }
                break;
            }

        case 'o':
            sc_tree_cfg.output_file = optarg;
            break;

        default:
            print_help();
            exit(-1);
        }
    }

    if (sc_tree_cfg.rule_file != NULL &&
        sc_tree_cfg.input_file != NULL) {
        printf("-r conflicts with -i\n");
        exit(-1);
    }

    return 0;
}

static void compile_rules(char *argv[])
{
    FILE *rule_fp;

    if (objpool_init(&node_pool, sizeof(union tree_node),
        1 << 24) != 0) {
        goto err;
    }
    if (objpool_init(&state_pool, sizeof(struct state),
        1 << 23) != 0) {
        goto err;
    }
    if (init_bitmap() != 0 || init_offset() != 0) {
        goto err;
    }
    sc_decision.bitmap = get_bitmap_base();
    sc_decision.offset = get_offset_base();

    printf("Loading rules from %s\n", sc_tree_cfg.rule_file);
    if ((rule_fp = fopen(sc_tree_cfg.rule_file, "r")) == NULL) {
        goto err;
    }
    if (load_rules(&sc_rule_set, rule_fp) != 0) {
        printf("Cannot load rules from %s\n", sc_tree_cfg.rule_file);
        exit(-1);
    }
    fclose(rule_fp);
    printf("%d rules loaded\n", sc_rule_set.rule_number);

    printf("Building decision tree\n");
    if (building() != 0) {
        printf("Building decision tree fails\n");
        exit(-1);
    } else {
        printf("Decision tree built\n");
        printf("Tree node size = %ld\n", sizeof(*sc_decision.root));
        printf("Bitamp size = %ld\n", sizeof(*sc_decision.bitmap));
        printf("Offset size = %ld\n\n", sizeof(*sc_decision.offset));
        printf("Internal number = %d\n", sc_decision.internal_number);
        printf("Leaf number = %d\n", sc_decision.leaf_number);
        printf("Bitmap number = %d\n", sc_decision.bitmap_number);
        printf("Offset number = %d\n", sc_decision.offset_number);
        printf("Offset length = %d\n\n", sc_decision.offset_length);
    }

    unload_rules(&sc_rule_set);
    return;

err:
    perror(argv[0]);
    exit(-1);
}

static void revert_tree(char *argv[])
{
    /* TODO: not implemented yet */
    printf("Reverting has not been implemented yet\n");
    return;
}

static void dump_tree(char *argv[])
{
    /* TODO: not implemented yet */
    printf("Dumping has not been implemented yet\n");
    return;
}

static void classify_traces(char *argv[])
{
    FILE *trace_fp;

    printf("Reading trace from %s\n", sc_tree_cfg.trace_file);
    if ((trace_fp = fopen(sc_tree_cfg.trace_file, "r")) == NULL) {
        goto err;
    }
    if (load_trace(&sc_trace, trace_fp) != 0) {
        printf("Cannot load packets from %s\n", sc_tree_cfg.trace_file);
        exit(-1);
    }
    fclose(trace_fp);
    printf("%d packets loaded\n", sc_trace.packet_number);

    printf("Searching decision tree\n");
    if (searching() != 0) {
        printf("Searching decision tree fails\n");
        exit(-1);
    } else {
        printf("Searching decision tree passes\n");
    }

    unload_trace(&sc_trace);
    return;

err:
    perror(argv[0]);
    exit(-1);
}

static void cleanup(void)
{
    objpool_term(&state_pool);
    objpool_term(&node_pool);
    term_bitmap();
    term_offset();

    return;
}

static int building(void)
{
    struct state *cur_state = NULL;

    /* initialize trigger state */
    cur_state = objpool_malloc(&state_pool);
    if (cur_state == NULL) {
        exit(-1);
    }

    sc_decision.root = objpool_malloc(&node_pool);
    if (sc_decision.root == NULL) {
        exit(-1);
    }

    if (init_trigger(cur_state) != 0) {
        exit(-1);
    }

    /* build tree */
    child_id = 1;
    STAILQ_INSERT_TAIL(&sc_state_queue, cur_state, next);
    do {
        cur_state = STAILQ_FIRST(&sc_state_queue);
        STAILQ_REMOVE_HEAD(&sc_state_queue, next);

        if (is_state_cutable(cur_state)) {
            cut_in_state(cur_state);
        } else {
            build_leaf_node(cur_state);
        }

        free(cur_state->rule_ids);
        objpool_free(&state_pool, cur_state);
    } while (!STAILQ_IS_EMPTY(&sc_state_queue));

    return 0;
}

static int searching(void)
{
    int i, cut_dim, cut_bits, pcnt, off;
    union tree_node *cur;

    for (i = 0; i < sc_trace.packet_number; i++) {
        cur = sc_decision.root;
        while (cur->internal.byte2cut != MASK_OF_SHIFT(B2C_BITS)) {
            byte2dim(&cut_dim, &cut_bits, cur->internal.byte2cut);

            pcnt = popcount(
                (uint64_t *)sc_decision.bitmap[cur->internal.bitmap_id],
                (sc_trace.packets[i].value[cut_dim] >> cut_bits) & 0xff);

            off = sc_decision.offset[cur->internal.offset_id][pcnt - 1];

            cur = sc_decision.root + cur->internal.node_id + off;
        }

        if (cur->leaf.priority != sc_trace.packets[i].match) {
            return -1;
        }
    }

    return 0;
}

static int init_trigger(struct state *state)
{
    int i;

    /* remaining rule set */
    state->rule_number = sc_rule_set.rule_number;
    state->rule_ids = malloc(sizeof(*state->rule_ids) * state->rule_number);
    if (state->rule_ids == NULL) {
        perror("Cannot allocate memory for trigger state rule id set");
        return -1;
    }
    for (i = 0; i < state->rule_number; i++) {
        state->rule_ids[i] = i;
    }

    /* remaining search space */
    state->space.dimension[DIM_SIP].begin = 0;
    state->space.dimension[DIM_SIP].end = 0xffffffff;
    state->space.dimension[DIM_DIP].begin = 0;
    state->space.dimension[DIM_DIP].end = 0xffffffff;
    state->space.dimension[DIM_SPORT].begin = 0;
    state->space.dimension[DIM_SPORT].end = 0xffff;
    state->space.dimension[DIM_DPORT].begin = 0;
    state->space.dimension[DIM_DPORT].end = 0xffff;
    state->space.dimension[DIM_PROTO].begin = 0;
    state->space.dimension[DIM_PROTO].end = 0xff;

    state->bytes[DIM_SIP] = 4;
    state->bytes[DIM_DIP] = 4;
    state->bytes[DIM_SPORT] = 2;
    state->bytes[DIM_DPORT] = 2;
    state->bytes[DIM_PROTO] = 1;

    state->next.stqe_next = NULL;

    /* related node */
    state->node = sc_decision.root;

    return 0;
}

static inline int is_state_cutable(struct state *state)
{
    int i, j;

    for (i = 0; i < DIM_MAX; i++) {
        if (state->bytes[i] == 0 || state->rule_number <= 1) {
            continue;
        }

        for (j = 0; j < state->rule_number; j++) {
            if (!is_range_full_cover(
                &sc_rule_set.rules[state->rule_ids[j]].match.dimension[i],
                &state->space.dimension[i])) {
                return 1;
            }
        }
    }

    return 0;
}

static inline void cut_in_state(struct state *state)
{
    int d, b, r, sr, ba, cut_dim, sspace_num;
    int bmp_id = 0, off_id = 0, off_len;
    struct range cur_range;
    union tree_node *new_node;
    struct state *new_state;

    /*
     * cut byte selection:
     * cut using this byte has the minimal sum of sub rules
     */

    /* 1. select one dimension */
    cut_dim = 0;
    for (d = 0; d < DIM_MAX; d++) {
        sc_cuts[d].measure = -1;

        if (state->bytes[d] == 0) {
            continue;
        }

        /* 2. select one byte on this dimension, from highest to lowest */
        sc_cuts[d].interval = 1 << ((state->bytes[d] << 3) - BMP_BITS_BITS);
        cur_range.begin = state->space.dimension[d].begin;
        cur_range.end = cur_range.begin + sc_cuts[d].interval - 1;
        for (b = 0; b < BMP_BITS; b++) {
            sc_cuts[d].is_full_cover[b] = 1;
            sc_cuts[d].uspace2sspace[b] = SSPACE_INVALID;

            sc_cuts[d].rule_ids[b] = malloc(sizeof(unsigned int)
                    * state->rule_number);
            if (sc_cuts[d].rule_ids[b] == NULL) {
                perror("Cannot allocate memory for rule id set");
                exit(-1);
            }

            /* 3. use this byte to 256-cut rule set */
            sr = 0;
            for (r = 0; r < state->rule_number; r++) {
                if (is_range_not_cover(
                    &sc_rule_set.rules[state->rule_ids[r]].
                    match.dimension[d], &cur_range)) {
                    continue;
                }

                sc_cuts[d].rule_ids[b][sr] = state->rule_ids[r];
                sr++;
                sc_cuts[d].measure++;

                if (!is_range_full_cover(
                    &sc_rule_set.rules[state->rule_ids[r]].
                    match.dimension[d], &cur_range)) {
                    sc_cuts[d].is_full_cover[b] = 0;
                }
            }

            sc_cuts[d].rule_number[b] = sr;
            cur_range.begin += sc_cuts[d].interval;
            cur_range.end += sc_cuts[d].interval;
        }

        cut_dim = sc_cuts[d].measure < sc_cuts[cut_dim].measure ? d : cut_dim;
    }

    for (d = 0; d < DIM_MAX; d++) {
        if (d == cut_dim) {
            continue;
        }
        for (b = 0; b < BMP_BITS; b++) {
            free(sc_cuts[d].rule_ids[b]);
            sc_cuts[d].rule_ids[b] = NULL;
        }
    }

    state->node->internal.byte2cut = dim2byte(cut_dim, state->bytes[cut_dim]);
    state->node->internal.node_id = child_id;

    /*
     * unit space aggregation:
     * all sub rules full cover unit space and unit spaces share the same sub rules
     */

    /* 1. calculate aggregation */
    sspace_num = 0;
    for (b = 0; b < BMP_BITS; b++) {
        if (sc_cuts[cut_dim].uspace2sspace[b] != SSPACE_INVALID) {
            continue;
        }

        /* find new aggregated space */
        sc_cuts[cut_dim].uspace2sspace[b] = sspace_num;
        sc_cuts[cut_dim].sspace2uspace[sspace_num] = b;
        sspace_num++;

        if (!sc_cuts[cut_dim].is_full_cover[b]) {
            continue;
        }

        for (ba = b + 1; ba < BMP_BITS; ba++) {
            if (!sc_cuts[cut_dim].is_full_cover[ba] ||
                sc_cuts[cut_dim].uspace2sspace[ba] != SSPACE_INVALID) {
                continue;
            }

            if (!is_rule_ids_same(
                sc_cuts[cut_dim].rule_ids[b],
                sc_cuts[cut_dim].rule_number[b],
                sc_cuts[cut_dim].rule_ids[ba],
                sc_cuts[cut_dim].rule_number[ba])) {
                continue;
            }

            sc_cuts[cut_dim].uspace2sspace[ba] =
                sc_cuts[cut_dim].uspace2sspace[b];
        }
    }

    child_id += sspace_num;

    /* 2. setup bitmap and offset */
    structural_compression(&bmp_id, &off_id, &off_len,
        sc_cuts[cut_dim].uspace2sspace);
    state->node->internal.bitmap_id = bmp_id;
    state->node->internal.offset_id = off_id;
    sc_decision.offset_length = off_len > sc_decision.offset_length ?
        off_len : sc_decision.offset_length;

    /*
     * create children, create new states and enqueue
     */

    for (r = 0, d = 0; d < sspace_num; d++) {
        new_state = objpool_malloc(&state_pool);
        if (new_state == NULL) {
            perror("Cannot allocate memory for new state");
            exit(-1);
        }
        new_node = objpool_malloc(&node_pool);
        if (new_node == NULL) {
            perror("Cannot allocate memory for new tree node");
            exit(-1);
        }

        /* remaining rule set */
        new_state->rule_number = sc_cuts[cut_dim].rule_number[
            sc_cuts[cut_dim].sspace2uspace[d]];
        new_state->rule_ids = sc_cuts[cut_dim].rule_ids[
            sc_cuts[cut_dim].sspace2uspace[d]];
        sc_cuts[cut_dim].rule_ids[sc_cuts[cut_dim].sspace2uspace[d]] = NULL;

        /* remaining search space */
        memcpy(&new_state->space, &state->space, sizeof(state->space));
        memcpy(new_state->bytes, state->bytes, sizeof(state->bytes));

        if (sc_cuts[cut_dim].is_full_cover[
                sc_cuts[cut_dim].sspace2uspace[d]]) {
            new_state->space.dimension[cut_dim].begin = 0;
            new_state->space.dimension[cut_dim].end = 0;
            new_state->bytes[cut_dim] = 0;
        } else {
            new_state->space.dimension[cut_dim].begin +=
                sc_cuts[cut_dim].sspace2uspace[d] *
                sc_cuts[cut_dim].interval;
            new_state->space.dimension[cut_dim].end =
                new_state->space.dimension[cut_dim].begin +
                sc_cuts[cut_dim].interval - 1;
            new_state->bytes[cut_dim] = state->bytes[cut_dim] - 1;
        }

        /* related node */
        new_state->node = new_node;

        new_state->next.stqe_next = NULL;
        STAILQ_INSERT_TAIL(&sc_state_queue, new_state, next);
    }

    for (b = 0; b < BMP_BITS; b++) {
        free(sc_cuts[cut_dim].rule_ids[b]);
        sc_cuts[cut_dim].rule_ids[b] = NULL;
    }

    sc_decision.internal_number++;

    return;
}

static inline void build_leaf_node(struct state *state)
{
    state->node->leaf.byte2cut = DIM_INVALID;
    state->node->leaf.action =
        sc_rule_set.rules[state->rule_ids[0]].action;
    state->node->leaf.priority =
        sc_rule_set.rules[state->rule_ids[0]].priority;

    sc_decision.leaf_number++;

    return;
}

static inline int is_range_full_cover(struct range *upper,
        struct range *lower)
{
    return (upper->begin <= lower->begin) && (upper->end >= lower->end);
}

static inline int is_range_not_cover(struct range *upper,
        struct range *lower)
{
    return (upper->end < lower->begin) || (upper->begin > lower->end);
}

static inline int is_rule_ids_same(int *rule_ids_a, int rule_number_a,
        int *rule_ids_b, int rule_number_b)
{
    int i;

    if (rule_number_a != rule_number_b) {
        return 0;
    }

    for (i = 0; i < rule_number_a; i++) {
        if (rule_ids_a[i] != rule_ids_b[i]) {
            return 0;
        }
    }

    return 1;
}

static inline void structural_compression(int *bmp_id, int *off_id,
        int *off_len, int16_t *us2ss)
{
    int i, j, prev;
    uint8_t bitmap[BMP_BYTES];
    uint8_t offset[CUTS_BITS];

    memset(bitmap, 0, sizeof(bitmap));
    memset(offset, 0, sizeof(offset));

    for (i = 0, j = 0, prev = SSPACE_INVALID; i < BMP_BITS; i++) {
        if (us2ss[i] == prev) {
            continue;
        }

        offset[j] = us2ss[i] & 0xff;
        bitmap[i >> 3] |= 1 << (i & 0x7);
        prev = us2ss[i];
        j++;
    }

    if (search_bitmap(bitmap, bmp_id) != 0) {
        insert_bitmap(bitmap);
        *bmp_id = sc_decision.bitmap_number;
        sc_decision.bitmap_number++;
    }

    if (search_offset(offset, off_id) != 0) {
        insert_offset(offset);
        *off_id = sc_decision.offset_number;
        sc_decision.offset_number++;
    }

    *off_len = j;

    return;
}

static inline char dim2byte(int cut_dim, int cut_byte)
{
    static const char d2b[DIM_MAX][4] = {
        { 3,  2,  1,  0}, /* src ip */
        { 7,  6,  5,  4}, /* dst ip */
        { 9,  8,  8,  8}, /* src port */
        {11, 10, 10, 10}, /* dst port */
        {12, 12, 12, 12}  /* proto */
    };

    return d2b[cut_dim][cut_byte - 1];
}

static inline void byte2dim(int *cut_dim, int *cut_bits, int byte)
{
    static const char b2d[][2] = {
        {0, 3 << 3}, {0, 2 << 3}, {0, 1 << 3}, {0, 0 << 3}, /* src ip */
        {1, 3 << 3}, {1, 2 << 3}, {1, 1 << 3}, {1, 0 << 3}, /* dst ip */
        {2, 1 << 3}, {2, 0 << 3},                           /* src port */
        {3, 1 << 3}, {3, 0 << 3},                           /* dst port */
        {4, 0 << 3}                                         /* proto */
    };

    *cut_dim = b2d[byte][0];
    *cut_bits = b2d[byte][1];

    return;
}

static inline long popcount(register uint64_t *bitmap, register long prefix)
{
    register long result = 0;

    switch (prefix >> 6) {
    case 0:
        result += __builtin_popcountl(bitmap[0] << (64-((prefix+1)&0x3f)));
        break;
    case 1:
        result += __builtin_popcountl(bitmap[0]);
        result += __builtin_popcountl(bitmap[1] << (64-((prefix+1)&0x3f)));
        break;
    case 2:
        result += __builtin_popcountl(bitmap[0]);
        result += __builtin_popcountl(bitmap[1]);
        result += __builtin_popcountl(bitmap[2] << (64-((prefix+1)&0x3f)));
        break;
    case 3:
        result += __builtin_popcountl(bitmap[0]);
        result += __builtin_popcountl(bitmap[1]);
        result += __builtin_popcountl(bitmap[2]);
        result += __builtin_popcountl(bitmap[3] << (64-((prefix+1)&0x3f)));
        break;
    case 4:
        result += __builtin_popcountl(bitmap[0]);
        result += __builtin_popcountl(bitmap[1]);
        result += __builtin_popcountl(bitmap[2]);
        result += __builtin_popcountl(bitmap[3]);
        break;
    }

    return result;
}

