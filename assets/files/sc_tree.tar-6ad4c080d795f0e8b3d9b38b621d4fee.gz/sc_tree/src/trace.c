#include <stdlib.h>
#include "trace.h"

int load_trace(struct trace *t, FILE *fp)
{
    unsigned int i = 0;

    t->packets = malloc(sizeof(struct packet) * PKT_MAX);
    if (t->packets == NULL) {
        perror("Cannot allocate memory for packets");
        return -1;
    }
    t->packet_number = 0;

    while (!feof(fp)) {
        if (i >= PKT_MAX) {
            printf("Too many packets\n");
            return -1;
        }

        if (fscanf(fp, PKT_FMT,
            &t->packets[i].value[DIM_SIP], &t->packets[i].value[DIM_DIP],
            &t->packets[i].value[DIM_SPORT], &t->packets[i].value[DIM_DPORT],
            &t->packets[i].value[DIM_PROTO], &t->packets[i].match) != 6) {
            perror("Illegal packet format");
            return -1;
        }
        t->packets[i].match--;

        t->packet_number++;
        i++;
    }

    return 0;
}

void unload_trace(struct trace *t)
{
    free(t->packets);
    return;
}
