#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "hashtable.h"

static const int primes[] = {
    53, 97, 193, 389,
    769, 1543, 3079, 6151,
    12289, 24593, 49157, 98317,
    196613, 393241, 786433, 1572869,
    3145739, 6291469, 12582917, 25165843,
    50331653, 100663319, 201326611, 402653189,
    805306457, 1610612741
};
static const int prime_table_length = sizeof(primes) / sizeof(primes[0]);
static const float load_factor = 0.75f;

static inline int index_of_power2(int bucket_num, unsigned long hash_v)
{
    return hash_v & (bucket_num - 1);
}

static inline int index_of_prime(int bucket_num, unsigned long hash_v)
{
    return hash_v % bucket_num;
}

#if 1
static inline unsigned long rehash(struct hash_table *ht, void *k)
{
    unsigned long hv = ht->hashfn(k);

    hv += ~(hv << 9);
    hv ^=  ((hv >> 14) | (hv << 18));
    hv +=  (hv << 4);
    hv ^=  ((hv >> 10) | (hv << 22));

    return hv;
}
#endif

static int hashtable_expand(struct hash_table *ht)
{
    int i, index, new_size;
    struct hash_entry *e;
    LIST_HEAD(, hash_entry) *new_buckets;

    if (ht == NULL) {
        return -1;
    }

    if (ht->prime_index < 0) {
        if ((ht->bucket_number << 1) < ht->bucket_number) {
            return -1;
        } else {
            new_size = ht->bucket_number << 1;
        }
    } else {
        if (ht->prime_index == prime_table_length) {
            return -1;
        } else {
            new_size = primes[ht->prime_index + 1];
        }
    }

    if ((new_buckets = calloc(1, sizeof(*new_buckets) * new_size)) != NULL) {
        for (i = 0; i < new_size; i++) {
            LIST_INIT(&new_buckets[i]);
        }

        for (i = 0; i < ht->bucket_number; i++) {
            while ((e = LIST_FIRST(&ht->buckets[i])) != NULL) {
                LIST_REMOVE(e, list_entry);
                index = ht->index(new_size, e->hash_value);
                LIST_INSERT_HEAD(&new_buckets[index], e, list_entry);
            }
        }

        free(ht->buckets);
    } else if ((new_buckets = realloc(ht->buckets,
        sizeof(*new_buckets) * new_size)) != NULL) {
        for (i = ht->bucket_number; i < new_size; i++) {
            LIST_INIT(&new_buckets[i]);
        }

        for (i = 0; i < ht->bucket_number; i++) {
            LIST_FOREACH(e, &ht->buckets[i], list_entry) {
                index = ht->index(new_size, e->hash_value);
                if (index == i) {
                    continue;
                }
                LIST_REMOVE(e, list_entry);
                LIST_INSERT_HEAD(&new_buckets[index], e, list_entry);
            }
        }
    } else {
        return -1;
    }

    ht->buckets = (void *)new_buckets;
    ht->prime_index = ht->prime_index < 0 ?
        ht->prime_index: ht->prime_index + 1;
    ht->bucket_number = new_size;
    ht->load_limit = (int)(new_size * load_factor);

    return 0;
}

int hashtable_create(struct hash_table *ht)
{
    int i;

    if (ht == NULL) {
        return -1;
    }

    if (ht->entry_alloc == NULL || ht->entry_free == NULL ||
        ht->key_alloc == NULL || ht->key_free == NULL ||
        ht->hashfn == NULL || ht->eqfn == NULL ||
        ht->key_size == 0) {
        return -1;
    }

    if (ht->value_size == 0) {
        if (ht->value_alloc != NULL || ht->value_free != NULL) {
            return -1;
        }
    } else {
        if (ht->value_alloc == NULL || ht->value_free == NULL) {
            return -1;
        }
    }

    if (ht->prime_index < 0) {
        if (ht->bucket_number <= 0) {
            ht->bucket_number = 64;
        } else {
            ht->bucket_number = p2roundup(ht->bucket_number);
        }
    } else {
        if (ht->prime_index >= prime_table_length) {
            ht->prime_index = prime_table_length - 1;
        }
        ht->bucket_number = primes[ht->prime_index];
    }

    ht->entry_number = 0;
    ht->load_limit = (int)(ht->bucket_number * load_factor);

    if (ht->index == NULL) {
        ht->index = ht->prime_index < 0 ? index_of_power2 : index_of_prime;
    }

    ht->buckets = calloc(1, sizeof(*ht->buckets) * ht->bucket_number);
    if (ht->buckets == NULL) {
        return -1;
    }

    for (i = 0; i < ht->bucket_number; i++) {
        LIST_INIT(&ht->buckets[i]);
    }

    return 0;
}

int hashtable_destroy(struct hash_table *ht)
{
    int i;
    struct hash_entry *e;

    if (ht == NULL) {
        return -1;
    }

    for (i = 0; i < ht->bucket_number; i++) {
        while ((e = LIST_FIRST(&ht->buckets[i])) != NULL) {
            LIST_REMOVE(e, list_entry);
            ht->key_free(e->key);
            if (ht->value_free != NULL) {
                ht->value_free(e->value);
            }
            ht->entry_free(e);
        }
    }

    free(ht->buckets);
    memset(ht, 0, sizeof(*ht));

    return 0;
}

int hashtable_insert(struct hash_table *ht, void *k, void *v)
{
    int i;
    struct hash_entry *e;

    if (ht == NULL || k == NULL) {
        return -1;
    }

    if (ht->entry_number + 1 > ht->load_limit) {
        hashtable_expand(ht);
    }

    e = ht->entry_alloc();
    if (e == NULL) {
        return -1;
    }

    e->key = ht->key_alloc();
    if (e->key == NULL) {
        ht->entry_free(e);
        return -1;
    }

    if (ht->value_alloc != NULL) {
        e->value = ht->value_alloc();
        if (e->value == NULL) {
            ht->key_free(e->key);
            ht->entry_free(e);
            return -1;
        }
    } else {
        e->value = NULL;
    }

    memcpy(e->key, k, ht->key_size);
    if (ht->value_alloc != NULL && v != NULL) {
        memcpy(e->value, v, ht->value_size);
    }
    /* e->hash_value = ht->hashfn(k); */
    e->hash_value = rehash(ht, k);
    i = ht->index(ht->bucket_number, e->hash_value);

    LIST_INSERT_HEAD(&ht->buckets[i], e, list_entry);
    ht->entry_number++;

    return 0;
}

int hashtable_remove(struct hash_table *ht, void *k)
{
    int i;
    unsigned long hv;
    struct hash_entry *e;

    if (ht == NULL || k == NULL) {
        return -1;
    }

    /* hv = ht->hashfn(k); */
    hv = rehash(ht, k);
    i = ht->index(ht->bucket_number, hv);
    LIST_FOREACH(e, &ht->buckets[i], list_entry) {
        if (hv == e->hash_value && ht->eqfn(k, e->key)) {
            LIST_REMOVE(e, list_entry);
            ht->key_free(e->key);
            if (ht->value_free != NULL) {
                ht->value_free(e->value);
            }
            ht->entry_free(e);
            ht->entry_number--;
            return 0;
        }
    }

    return -1;
}

int hashtable_update(struct hash_table *ht, void *k, void *v)
{
    int i;
    unsigned long hv;
    struct hash_entry *e;

    if (ht == NULL || k == NULL || v == NULL) {
        return -1;
    }

    if (ht->value_size == 0) {
        return -1;
    }

    /* hv = ht->hashfn(k); */
    hv = rehash(ht, k);
    i = ht->index(ht->bucket_number, hv);
    LIST_FOREACH(e, &ht->buckets[i], list_entry) {
        if (hv == e->hash_value && ht->eqfn(k, e->key)) {
            memcpy(e->value, v, ht->value_size);
            return 0;
        }
    }

    return -1;
}

int hashtable_search(struct hash_table *ht, void *k,
        struct hash_entry **pe)
{
    int i;
    unsigned long hv;
    struct hash_entry *e;

    if (ht == NULL || k == NULL) {
        return -1;
    }

    /* hv = ht->hashfn(k); */
    hv = rehash(ht, k);
    i = ht->index(ht->bucket_number, hv);
    LIST_FOREACH(e, &ht->buckets[i], list_entry) {
        if (hv == e->hash_value && ht->eqfn(k, e->key)) {
            if (pe != NULL) {
                *pe = e;
            }
            return 0;
        }
    }

    return -1;
}

int hashtable_iterator_create(struct hash_table *ht,
        struct hash_table_itr *hti)
{
    int i;

    if (ht == NULL || hti == NULL) {
        return -1;
    }

    hti->table = ht;
    hti->entry = NULL;
    hti->parent = NULL;
    hti->index = ht->bucket_number;

    if (ht->entry_number == 0) {
        return 0;
    }

    for (i = 0; i < ht->bucket_number; i++) {
        if (!LIST_IS_EMPTY(&ht->buckets[i])) {
            hti->entry = LIST_FIRST(&ht->buckets[i]);
            hti->index = i;
            break;
        }
    }

    return 0;
}

int hashtable_iterator_destroy(struct hash_table_itr *hti)
{
    if (hti == NULL) {
        return -1;
    }

    memset(hti, 0, sizeof(*hti));

    return 0;
}

int hashtable_iterator_key(struct hash_table_itr *hti, void **pk)
{
    if (hti == NULL || pk == NULL) {
        return -1;
    } else {
        *pk = hti->entry->key;
        return 0;
    }
}

int hashtable_iterator_value(struct hash_table_itr *hti, void **pv)
{
    if (hti == NULL || pv == NULL) {
        return -1;
    } else {
        *pv = hti->entry->value;
        return 0;
    }
}

int hashtable_iterator_advance(struct hash_table_itr *hti)
{
    int j;

    if (hti == NULL || hti->entry == NULL) {
        return -1;
    }

    /* in the same bucket */
    if (LIST_NEXT(hti->entry, list_entry) != NULL) {
        hti->parent = hti->entry;
        hti->entry = LIST_NEXT(hti->entry, list_entry);
        return 0;
    }

    /* different buckets: next index overflows */
    hti->parent = NULL;
    if (++hti->index >= hti->table->bucket_number) {
        hti->entry = NULL;
        return -1;
    }

    for (j = hti->index; j < hti->table->bucket_number; j++) {
        /* different buckets: header of the different bucket */
        if (!LIST_IS_EMPTY(&hti->table->buckets[j])) {
            hti->index = j;
            hti->entry = LIST_FIRST(&hti->table->buckets[j]);
            return 0;
        }
    }

    /* different buckets: cannot found */
    hti->index = hti->table->bucket_number;
    hti->entry = NULL;

    return -1;
}

int hashtable_iterator_remove(struct hash_table_itr *hti)
{
    int ret;
    struct hash_entry *p, *e;

    if (hti == NULL) {
        return -1;
    }

    if (hti->parent == NULL) {
        LIST_FIRST(&hti->table->buckets[hti->index]) =
            LIST_NEXT(hti->entry, list_entry);
    } else {
        LIST_NEXT(hti->parent, list_entry) =
            LIST_NEXT(hti->entry, list_entry);
    }

    hti->table->entry_number--;
    e = hti->entry;
    p = hti->parent;

    ret = hashtable_iterator_advance(hti);
    if (hti->parent == e) {
        hti->parent = p;
    }

    hti->table->key_free(e->key);
    if (hti->table->value_free != NULL) {
        hti->table->value_free(e->value);
    }
    hti->table->entry_free(e);

    return ret;
}

int hashtable_iterator_search(struct hash_table_itr *hti, void *k)
{
    int i;
    unsigned long hv;
    struct hash_entry *p, *e;

    if (hti == NULL || hti->table == NULL) {
        return -1;
    }

    /* hv = hti->table->hashfn(k); */
    hv = rehash(hti->table, k);
    i = hti->table->index(hti->table->bucket_number, hv);

    e = LIST_FIRST(&hti->table->buckets[i]);
    p = NULL;

    while (e != NULL) {
        if (hv == e->hash_value && hti->table->eqfn(k, e->key)) {
            hti->entry = e;
            hti->parent = p;
            hti->index = i;
            return 0;
        }

        p = e;
        e = LIST_NEXT(e, list_entry);
    }

    return -1;
}
