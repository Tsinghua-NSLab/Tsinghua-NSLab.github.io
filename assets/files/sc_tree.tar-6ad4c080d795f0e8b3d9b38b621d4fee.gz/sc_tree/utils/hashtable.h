#ifndef __HASHTABLE_H__
#define __HASHTABLE_H__

#include "queue.h"

struct hash_entry {
    void *key;
    void *value;
    unsigned long hash_value;
    LIST_ENTRY(hash_entry) list_entry;
};

struct hash_table {
    int prime_index;
    int bucket_number;
    int entry_number;
    int load_limit;

    void *(*entry_alloc)(void);
    void (*entry_free)(void *p);

    unsigned long key_size;
    void *(*key_alloc)(void);
    void (*key_free)(void *p);

    unsigned long value_size;
    void *(*value_alloc)(void);
    void (*value_free)(void *p);

    int (*index)(int bucket_num, unsigned long hash_v);
    unsigned long (*hashfn)(void *k);
    int (*eqfn)(void *k1, void *k2);

    LIST_HEAD(, hash_entry) *buckets;
};

struct hash_table_itr {
    struct hash_table *table;
    struct hash_entry *entry;
    struct hash_entry *parent;
    int index;
};

/*
 * primes:
 * 53, 97, 193, 389,
 * 769, 1543, 3079, 6151,
 * 12289, 24593, 49157, 98317,
 * 196613, 393241, 786433, 1572869,
 * 3145739, 6291469, 12582917, 25165843,
 * 50331653, 100663319, 201326611, 402653189,
 * 805306457, 1610612741
 */

int hashtable_create(struct hash_table *ht);
int hashtable_destroy(struct hash_table *ht);

int hashtable_insert(struct hash_table *ht, void *k, void *v);
int hashtable_remove(struct hash_table *ht, void *k);
int hashtable_update(struct hash_table *ht, void *k, void *v);
int hashtable_search(struct hash_table *ht, void *k,
        struct hash_entry **pe);

int hashtable_iterator_create(struct hash_table *ht,
        struct hash_table_itr *hti);
int hashtable_iterator_destroy(struct hash_table_itr *hti);

int hashtable_iterator_key(struct hash_table_itr *hti, void **pk);
int hashtable_iterator_value(struct hash_table_itr *hti, void **pv);

int hashtable_iterator_advance(struct hash_table_itr *hti);
int hashtable_iterator_remove(struct hash_table_itr *hti);
int hashtable_iterator_search(struct hash_table_itr *hti, void *k);

#endif /* __HASHTABLE_H__ */
