#ifndef __JHASH_H__
#define __JHASH_H__

#include <stdint.h>

/* This is one copy from linux kernel source with less modification. */

#define __jhash_mix(a, b, c) \
    do { \
        a -= c; a ^= (c <<  4 | c >> (32 -  4)); c += b; \
        b -= a; b ^= (a <<  6 | a >> (32 -  6)); a += c; \
        c -= b; c ^= (b <<  8 | b >> (32 -  8)); b += a; \
        a -= c; a ^= (c << 16 | c >> (32 - 16)); c += b; \
        b -= a; b ^= (a << 19 | a >> (32 - 19)); a += c; \
        c -= b; c ^= (b <<  4 | b >> (32 -  4)); b += a; \
    } while (0)

#define __jhash_final(a, b, c) \
    do { \
        c ^= b; c -= (b << 14 | b >> (32 - 14)); \
        a ^= c; a -= (c << 11 | c >> (32 - 11)); \
        b ^= a; b -= (a << 25 | a >> (32 - 25)); \
        c ^= b; c -= (b << 16 | b >> (32 - 16)); \
        a ^= c; a -= (c <<  4 | c >> (32 -  4)); \
        b ^= a; b -= (a << 14 | a >> (32 - 14)); \
        c ^= b; c -= (a << 24 | a >> (32 - 24)); \
    } while (0)

#define JHASH_INITVAL 0xdeadbeef

static inline uint32_t jhash(const void *key, uint32_t length,
        uint32_t initval)
{
    uint32_t a, b, c;
    const uint8_t *k = (const uint8_t *)key;

    a = b = c = JHASH_INITVAL + length + initval;

    while (length > 12) {
        a += (k[0] + ((uint32_t)k[1]<<8) +
                ((uint32_t)k[2]<<16) + ((uint32_t)k[3]<<24));
        b += (k[4] + ((uint32_t)k[5]<<8) +
                ((uint32_t)k[6]<<16) + ((uint32_t)k[7]<<24));
        c +=(k[8] + ((uint32_t)k[9]<<8) +
                ((uint32_t)k[10]<<16) + ((uint32_t)k[11]<<24));

        __jhash_mix(a, b, c);
        length -= 12;
        k += 12;
    }

    switch (length) {
    case 12: c += (uint32_t)k[11]<<24;
    case 11: c += (uint32_t)k[10]<<16;
    case 10: c += (uint32_t)k[9]<<8;
    case 9:  c += k[8];
    case 8:  b += (uint32_t)k[7]<<24;
    case 7:  b += (uint32_t)k[6]<<16;
    case 6:  b += (uint32_t)k[5]<<8;
    case 5:  b += k[4];
    case 4:  a += (uint32_t)k[3]<<24;
    case 3:  a += (uint32_t)k[2]<<16;
    case 2:  a += (uint32_t)k[1]<<8;
    case 1:  a += k[0];
             __jhash_final(a, b, c);
    case 0:
             break;
    }

    return c;
}

static inline uint32_t jhash2(const uint32_t *k, uint32_t length,
        uint32_t initval)
{
    uint32_t a, b, c;

    a = b = c = JHASH_INITVAL + (length<<2) + initval;

    while (length > 3) {
        a += k[0];
        b += k[1];
        c += k[2];
        __jhash_mix(a, b, c);
        length -= 3;
        k += 3;
    }

    switch (length) {
    case 3: c += k[2];
    case 2: b += k[1];
    case 1: a += k[0];
            __jhash_final(a, b, c);
    case 0:
            break;
    }

    return c;
}

static inline uint32_t jhash_3words(uint32_t a, uint32_t b, uint32_t c,
        uint32_t initval)
{
    a += JHASH_INITVAL;
    b += JHASH_INITVAL;
    c += initval;

    __jhash_final(a, b, c);

    return c;
}

static inline uint32_t jhash_2words(uint32_t a, uint32_t b, uint32_t initval)
{
    return jhash_3words(a, b, 0, initval);
}

static inline uint32_t jhash_1word(uint32_t a, uint32_t initval)
{
    return jhash_3words(a, 0, 0, initval);
}

#endif /* __JHASH_H__ */
