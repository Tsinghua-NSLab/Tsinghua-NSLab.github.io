#include <stdlib.h>
#include <string.h>

#include "objpool.h"
#include "queue.h"
#include "utils.h"

struct object_entry {
    STAILQ_ENTRY(object_entry) list;
};

struct object_pool {
    unsigned long obj_size;
    unsigned long obj_total;
    STAILQ_HEAD(,object_entry) obj_queue;
    void *pool;
};

int objpool_init(objpool_t *op, unsigned long obj_size, unsigned long obj_num)
{
    int i;
    struct object_pool *pool;
    void *p;

    if (op == NULL) {
        return -1;
    }

    pool = malloc(sizeof(*pool));
    if (pool == NULL) {
        return -1;
    }

    pool->obj_size = obj_size < sizeof(struct object_entry) ?
        sizeof(struct object_entry) :
        align(obj_size, sizeof(unsigned long));
    pool->obj_total = obj_num;
    STAILQ_INIT(&pool->obj_queue);

    pool->pool = calloc(1, pool->obj_size * pool->obj_total);
    if (pool->pool == NULL) {
        free(pool);
        return -1;
    }

    for (p = pool->pool, i = 0; i < pool->obj_total;
            p = (void *)((unsigned long)p + pool->obj_size), i++) {
        STAILQ_INSERT_TAIL(&pool->obj_queue, (struct object_entry*)p, list);
    }

    *op = (objpool_t)pool;

    return 0;
}

void objpool_term(objpool_t *op)
{
    struct object_pool *pool;

    if (op == NULL) {
        return;
    }

    pool = (struct object_pool *)(*op);
    *op = 0;
    free(pool->pool);
    free(pool);

    return;
}

void *objpool_malloc(objpool_t *op)
{
    struct object_entry *oe;
    struct object_pool *pool;

    if (op == NULL) {
        return NULL;
    }

    pool = (struct object_pool *)(*op);
    if (*op == 0) {
        return NULL;
    }

    if (STAILQ_IS_EMPTY(&pool->obj_queue)) {
        return NULL;
    } else {
        oe = STAILQ_FIRST(&pool->obj_queue);
        STAILQ_REMOVE_HEAD(&pool->obj_queue, list);
        return oe;
    }
}

void *objpool_calloc(objpool_t *op)
{
    struct object_entry *oe;

    oe = objpool_malloc(op);

    if (oe != NULL) {
        memset(oe, 0, ((struct object_pool *)(*op))->obj_size);
    }

    return oe;
}

void objpool_free(objpool_t *op, void *p)
{
    struct object_pool *pool;

    if (op == NULL || p == NULL) {
        return;
    }

    pool = (struct object_pool *)(*op);
    if (*op == 0) {
        return;
    }

    STAILQ_INSERT_TAIL(&pool->obj_queue, (struct object_entry*)p, list);

    return;
}

void *objpool_base(objpool_t *op)
{
    return ((struct object_pool *)(*op))->pool;
}

