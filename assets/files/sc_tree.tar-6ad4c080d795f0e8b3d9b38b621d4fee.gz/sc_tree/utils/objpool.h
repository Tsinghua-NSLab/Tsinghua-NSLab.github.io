#ifndef __OBJPOOL_H__
#define __OBJPOOL_H__

typedef unsigned long objpool_t;

int objpool_init(objpool_t *op, unsigned long obj_size, unsigned long obj_num);
void objpool_term(objpool_t *op);
void *objpool_malloc(objpool_t *op);
void *objpool_calloc(objpool_t *op);
void objpool_free(objpool_t *op, void *p);
void *objpool_base(objpool_t *op);

#endif /* __OBJPOOL_H__ */
