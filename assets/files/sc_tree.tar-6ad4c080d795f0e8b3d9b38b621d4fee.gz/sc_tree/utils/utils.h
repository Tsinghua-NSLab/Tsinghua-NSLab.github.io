#ifndef __UTILS_H__
#define __UTILS_H__

#include <stddef.h> /* offsetof */
#include <stdint.h>

#define swap(a, b) \
    do { typeof(a) __tmp = (a); (a) = (b); (b) = __tmp; } while (0)

#define align(size, align) ({ \
        const typeof(align) __align = align; \
        ((size) + (__align) - 1) & ~((__align) - 1);})

#define roundup(x, y) ({ \
        const typeof(y) __y = y; \
        (((x) + (__y - 1)) / __y) * __y;})

#define roundup2(x, y) ({ \
        const typeof(y) __y = y; \
        (((x) + (__y - 1)) & (~(__y - 1)));})


#define rounddown(x, y) ({ \
        typeof(x) __x = (x); \
        __x - (__x % (y));})

#define powerof2(x) ({ \
        const typeof(x) __x = x; \
        (((__x) - 1) & (__x)) == 0;})

static inline uint32_t p2roundup(uint32_t n)
{
    if (!powerof2(n)) {
        n--;
        n |= n >> 1;
        n |= n >> 2;
        n |= n >> 4;
        n |= n >> 8;
        n |= n >> 16;
        /* n |= n >> 32; [> only for 64bit <] */
        n++;
    }
    return n;
}

#define container_of(ptr, type, member) ({ \
        const typeof(((type *)0)->member) *__mptr = (ptr); \
        (type *)((char *)__mptr - offsetof(type,member));})

#define SIZE_OF_SHIFT(n) (1ULL << (n))
#define MASK_OF_SHIFT(n) (SIZE_OF_SHIFT(n) - 1)

#endif /* __UTILS_H__ */
