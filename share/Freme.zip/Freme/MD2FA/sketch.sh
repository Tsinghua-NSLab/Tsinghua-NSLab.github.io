#!/bin/bash

	./regex -p $1 -g $1.dot
	dot -Tjpg $1.dot -o $1.jpg
	rm $1.dot
