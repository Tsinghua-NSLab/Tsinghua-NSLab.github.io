#! /bin/bash

	echo	">> Compiling regex ..."
	#make > /dev/null 2>&1
	#make clean > /dev/null 2>&1
	echo	">> Building D1FA ..."
	./regex -i rawDFA/$1.dfa > $1.result
	#./regex -p ruleset/$1.re > $1.result

	sort raw256 > $1
	cat $1 | wc -l >> $1.tmp
	cat $1 >> $1.tmp
	mv $1.tmp $1

	#echo	">> Compiling d3fa ..."
	#cd d3fa
	#make > /dev/null 2>&1
	#make clean > /dev/null 2>&1
	#cd ..
	#echo	">> Building D3FA ..."
	#./d3fa/d3fa 8 0.2 $1 >> $1.result
	
	./trie_fa/trie_fa $1 newTest >> $1.result

	echo	">> Test Report "
	echo	""
	cat $1.result
	rm -rf $1.tmp raw256 newTrie rawTrie newTest
	mv $1 ./tables/$1.table
	mv $1.result ./results/$1.result
