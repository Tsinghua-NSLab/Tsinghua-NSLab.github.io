#!/usr/bin/python
import xlwt,sys

NUM=64

def read_file(filename):
    configfile=file(filename,'r')
    content=[]
    while True:
        line=configfile.readline()
        if len(line)==0:
            break
        content.append(int(line))
    configfile.close()
    return content

if len(sys.argv)!=3:
    print 'Usage: generate_my_size.py input_filename output_filename'
    quit()

numlist1=[]
for i in range(2, NUM+1):
    filename1=sys.argv[1]+"-"+str(i)+"-"+"esti.txt"
    tmp=sum(read_file(filename1))
    numlist1.append(tmp)

numlist2=[]
for i in range(2, NUM+1):
    filename2=sys.argv[1]+"-"+str(i)+"-"+"real.txt"
    tmp=sum(read_file(filename2))
    numlist2.append(tmp)

numlist3=[]
for i in range(2, NUM+1):
    filename3=sys.argv[1]+"-"+str(i)+"-"+"my.txt"
    tmp=sum(read_file(filename3))
    numlist3.append(tmp)

numlist4=[]
for i in range(2, NUM+1):
    filename4=sys.argv[1]+"-"+str(i)+"-"+"ga-my.txt"
    tmp=sum(read_file(filename4))
    numlist4.append(tmp)

numlist5=[]
for i in range(2, NUM+1):
    filename5=sys.argv[1]+"-"+str(i)+"-"+"ga-real.txt"
    tmp=sum(read_file(filename5))
    numlist5.append(tmp)

book = xlwt.Workbook()
sheet1 = book.add_sheet('sheet1')

for i,e in enumerate(range(2, NUM+1)):
    sheet1.write(0,i,e)

for i,e in enumerate(numlist1):
    sheet1.write(1,i,e)

for i,e in enumerate(numlist2):
    sheet1.write(2,i,e)

for i,e in enumerate(numlist3):
    sheet1.write(3,i,e)

for i,e in enumerate(numlist4):
    sheet1.write(4,i,e)

for i,e in enumerate(numlist5):
    sheet1.write(5,i,e)

name = sys.argv[2]+".xls"
book.save(name)
