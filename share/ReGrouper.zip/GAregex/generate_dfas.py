#!/usr/bin/python
import os,struct,sys,glob,time,numpy

def read_file(filename):
    configfile=file(filename,'r')
    content=[]
    while True:
        line=configfile.readline()
        if len(line)==0:
            break
        content.append(line)
    configfile.close()
    return content

def write_file(filename,stringlist,lines):
    textfile=file(filename,'w')
    for line in lines:
        textfile.write(stringlist[line])
    textfile.close()

def write_grouping_result(filename,groupnum,regexlist,group):
    textfile=file(filename,'w')
    textfile.write("%s\n" % str(groupnum))
    for m in range(0,groupnum):
        for i in range(0,len(regexlist)):
            if group[i]==m:
                textfile.write("%s " % i)
        textfile.write("\n")
    textfile.close()

def write_list(filename, mylist):
    textfile=file(filename,'w')
    textfile.write("\n".join(str(x) for x in mylist) + "\n")
    textfile.close()

def execute_command(command):
    #print command
    tmp = os.popen(command)
    while True:
        line=tmp.readline()
        if len(line)==0:
            print 'No output while executing ', command
            size=65535
            break
        if line.startswith('dfa size:'):
            size=int(line[9:-1])
            break
    return size

regex_exe='/home/zhefu/xinming/regex/regex '

if len(sys.argv)<5:
    print 'Usage: generate_dfas.py input_filename output_filebase init_groupnum threshold [import_matrix]'
    quit()

print time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
regexlist=read_file(sys.argv[1])
input_filename=sys.argv[2]+'.tmp'  #/home/zhefu/xinming/regex/spyware-put.re
output_filebase=sys.argv[2] #/home/zhefu/xinming/regex/spyware-put.re.dfas
groupnum=int(sys.argv[3]) #4
threshold=sys.argv[4] #1000000

if len(sys.argv)==5:
    single_dfasize=range(0,len(regexlist))
    for i in range(0,len(regexlist)):
        write_file(input_filename,regexlist,[i])
        command=regex_exe+' -p '+input_filename+' --param1 '+threshold+' 2>&1'
        single_dfasize[i]=execute_command(command)
    print single_dfasize
    numpy.savetxt(output_filebase+"_single.txt",single_dfasize,fmt='%i')

    inc_dfasize=numpy.array(range(len(regexlist)*len(regexlist)))
    inc_dfasize.shape=len(regexlist),-1
    for i in range(0,len(regexlist)):
        print i
        inc_dfasize[i][i]=0
        for j in range(i+1,len(regexlist)):
            write_file(input_filename,regexlist,[i,j])
            command=regex_exe+' -p '+input_filename+' --param1 '+threshold+' 2>&1'
            ret=max(0,execute_command(command)-single_dfasize[i]-single_dfasize[j])
            inc_dfasize[i][j]=ret
            inc_dfasize[j][i]=ret
    numpy.savetxt(output_filebase+"_matrix.txt",inc_dfasize,fmt='%i')
    os.remove(input_filename)
else:
    inc_dfasize=numpy.loadtxt(sys.argv[5],int)

group=range(0,len(regexlist))
for i in range(0,len(regexlist)):
    group[i]=i*groupnum/len(regexlist)
F=range(0,groupnum)

print "Try generating "+str(groupnum)+" groups. "+time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
tStart = time.time()
while True:
    nochange=True
    for i in range(0,len(regexlist)):
        for m in range(0,groupnum):
            F[m]=0
            for j in range(0,len(regexlist)):
                if group[j]==m:
                    F[m]+=inc_dfasize[i][j]
        t=F.index(min(F))
        if group[i]!=t:
            group[i]=t
            nochange=False
    if nochange:
        break
all_success=True
print group
write_list(output_filebase+"-"+str(groupnum)+"-esti.txt", F)
write_grouping_result(output_filebase+"-"+str(groupnum)+".txt",groupnum,regexlist,group)
if all_success:
    print 'Successfully generated groups ',groupnum
else:
    print 'Failed generating groups ',groupnum
tEnd = time.time()
print (tEnd-tStart)
