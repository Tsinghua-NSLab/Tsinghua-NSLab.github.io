#!/usr/bin/python
import os,struct,sys,glob,time,numpy

def read_file(filename):
    configfile=file(filename,'r')
    content=[]
    while True:
        line=configfile.readline()
        if len(line)==0:
            break
        content.append(line)
    configfile.close()
    return content

def write_file(filename,stringlist,lines):
    textfile=file(filename,'w')
    for line in lines:
        textfile.write(stringlist[line])
    textfile.close()

def write_list(filename, mylist):
    textfile=file(filename,'w')
    textfile.write("\n".join(str(x) for x in mylist) + "\n")
    textfile.close()

if len(sys.argv)!=6:
    print 'Usage: generate_esti_size.py input_filename output_filebase group_result_filename import_single import_matrix'
    quit()

print time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
regexlist=read_file(sys.argv[1])
output_filebase=sys.argv[2]
groupresult_filename=sys.argv[3]
single_dfasize=numpy.loadtxt(sys.argv[4],int)
inc_dfasize=numpy.loadtxt(sys.argv[5],int)

groupresult=file(groupresult_filename,'r')
groupnum=int(groupresult.readline())
# print groupnum

my_size=[]
for m in range(0,groupnum):
    line=groupresult.readline().split()
    lines=[int(i) for i in line]
    print lines
    ret=0
    for i in range(0,len(lines)):
        ret=ret+single_dfasize[lines[i]]
    for i in range(0,len(lines)):
        for j in range(i+1,len(lines)):
            ret=ret+inc_dfasize[i][j]

    print 'Generated group '+str(m)+' from '+str(len(lines))+' regexes:'+str(int(ret))
    my_size.append(int(ret))

print my_size
groupresult.close()
write_list(output_filebase+"-"+str(groupnum)+"-esti.txt", my_size)
