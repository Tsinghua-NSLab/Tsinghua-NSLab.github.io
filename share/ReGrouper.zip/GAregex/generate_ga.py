#!/usr/bin/python
import os,struct,sys,glob,time,numpy,random,sys

def read_file(filename):
    configfile=file(filename,'r')
    content=[]
    while True:
        line=configfile.readline()
        if len(line)==0:
            break
        content.append(line)
    configfile.close()
    return content

def write_file(filename,stringlist,lines):
    textfile=file(filename,'w')
    for line in lines:
        textfile.write(stringlist[line])
    textfile.close()

def write_grouping_result(filename,groupnum,group):
    textfile=file(filename,'w')
    textfile.write("%s\n" % str(groupnum))
    for m in range(0,groupnum):
        for i in range(0,len(group)):
            if group[i]==m:
                textfile.write("%s " % i)
        textfile.write("\n")
    textfile.close()

def write_list(filename, mylist):
    textfile=file(filename,'w')
    textfile.write("\n".join(str(x) for x in mylist) + "\n")
    textfile.close()
    
def convent_result(sequence,group_num):
    result=[]
    for m in range(0,group_num):
        tmp_group_id=[]
        for j in range(0,len(sequence)):
            if sequence[j] == m:
                tmp_group_id.append(j)
        result.append(tmp_group_id)
    return result
    
    
class chromosome:
    def __init__(self,group_num,regex_num):
        self.sequence = [random.randint(0,group_num-1) for _ in range(regex_num)]
        self.length = len(self.sequence)
        self.fitness = sys.maxsize
        self.fitsum = 0
        self.DFAnum = 0
    
    def display(self):
        print self.sequence
        print 'DFAnum:', self.DFAnum
        print 'fitness:', self.fitness
        print 'fitsum:', self.fitsum
        print
            
    def mutate(self):
        position = random.randint(0,self.length-1)
        group_num = max(self.sequence)+1
        self.sequence[position] = random.randint(0,group_num-1)
        # print 'at',position
        # print self.sequence
        # print

    def get_DFA_num(self):
        lines=self.sequence
        # print lines
        group_num = max(lines)+1
        # print group_num
        DFA_num=0
        tmp=[]
        for m in range(0,group_num):
            tmp_group_id=[]
            for j in range(0,len(lines)):
                if lines[j] == m:
                    tmp_group_id.append(j)
            
            for i in range(0,len(tmp_group_id)):
                DFA_num=DFA_num+single_dfasize[tmp_group_id[i]]
            for i in range(0,len(tmp_group_id)):
                for j in range(i+1,len(tmp_group_id)):
                    coefficient=0
                    for k in range(0,len(tmp_group_id)):
                        coefficient=coefficient+Rho[i][k]
                        coefficient=coefficient+Rho[j][k]
                    coefficient=coefficient-Rho[i][i]-Rho[j][j]-Rho[i][j]-Rho[j][i]
                    DFA_num=DFA_num+coefficient*inc_dfasize[i][j]
            
            tmp.append(int(DFA_num))
                    
        self.DFAnum=int(DFA_num)
        
        output=tmp[:]
        for m in range(1,group_num):
            output[m]=tmp[m]-tmp[m-1]
        return output
    
class population:
    def __init__(self):
        self.chrom_sets = []
        self.chrom_num = 0
        self.crossover_rate = 0.8
        self.mutate_rate = 0.2  
        
    def initialization(self,chrom_num,group_num,regex_num):
        self.chrom_num = chrom_num
        self.length = regex_num
        for i in range(chrom_num):
            # chrom = [random.randint(0,group_num) for _ in range(regex_num)]
            chrom = chromosome(group_num,regex_num)
            self.chrom_sets.append(chrom)
            
    def display(self):
        print
        for i in range(self.chrom_num):
            print 'chromosome:',i
            self.chrom_sets[i].display()
            
    def get_all_fitness(self):
        tmp_min=sys.maxsize
        tmp_max=0
        min_DFAnum_id=0
        max_DFAnum_id=0
        for i in range(self.chrom_num):
            self.chrom_sets[i].get_DFA_num()
            if self.chrom_sets[i].DFAnum > tmp_max:
                tmp_max=self.chrom_sets[i].DFAnum
                max_DFAnum_id=i
            if self.chrom_sets[i].DFAnum < tmp_min:
                tmp_min=self.chrom_sets[i].DFAnum
                min_DFAnum_id=i
        for i in range(self.chrom_num):
            self.chrom_sets[i].fitness=tmp_max+tmp_min-self.chrom_sets[i].DFAnum
        tmp_fitsum=0
        for i in range(self.chrom_num):
            tmp_fitsum=tmp_fitsum+self.chrom_sets[i].fitness
            self.chrom_sets[i].fitsum=tmp_fitsum
        return (min_DFAnum_id,tmp_min,max_DFAnum_id,tmp_max)
    
    def crossover(self,i,j):
        if random.random()<self.crossover_rate:
            position = random.randint(0,self.length-1)
            new_chrom1=self.chrom_sets[i].sequence[:position]+self.chrom_sets[j].sequence[position:]
            new_chrom2=self.chrom_sets[j].sequence[:position]+self.chrom_sets[i].sequence[position:]
            # print 'crossover at ',position
            # print new_chrom1
            # print new_chrom2
        else:
            new_chrom1=self.chrom_sets[i].sequence[:]
            new_chrom2=self.chrom_sets[j].sequence[:]
        
        return (new_chrom1,new_chrom2)
        
    def mutate(self):
        for i in range(self.chrom_num): 
            if random.random()<self.mutate_rate:
                # print 'mutate',i
                self.chrom_sets[i].mutate()
         
    def random_select(self):
        rand = random.random() * self.chrom_sets[-1].fitsum
        for i in range(self.chrom_num):
            if rand >=self.chrom_sets[i].fitsum and rand < self.chrom_sets[i+1].fitsum:
                break
        return i
        
    def evolution(self):
        tmp_list = []
        for m in range(int(self.chrom_num/2)):

            i=self.random_select()
            while True:
                j=self.random_select()
                if j!=i:
                    break
            # print 'select',i,j
            (new_chrom1,new_chrom2)=self.crossover(i,j)
            tmp_list.append(new_chrom1)
            tmp_list.append(new_chrom2)
        # print 'tmp_list'
        # print tmp_list
        for i in range(len(tmp_list)):
            for j in range(self.length):
                self.chrom_sets[i].sequence[j] = int(tmp_list[i][j])
        self.mutate()
        
    def elitist_strategy(self,worst_id,best_list):
        # print '...worst id:',worst_id
        # print '...to replace:'
        # print self.chrom_sets[worst_id].sequence
        # print '...to:'
        # print best_list
        for j in range(self.length):
            self.chrom_sets[worst_id].sequence[j] = int(best_list[j])
    
if len(sys.argv)!=6:
    print 'Usage: generate_ga.py input_filename output_filebase groupnum import_single import_matrix'
    quit()

print time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
regexlist=read_file(sys.argv[1])
regexnum=len(regexlist)
output_filebase=sys.argv[2] #/home/zhefu/xinming/regex/spyware-put.re.dfas
groupnum=int(sys.argv[3]) #4
single_dfasize=numpy.loadtxt(sys.argv[4],int)
inc_dfasize=numpy.loadtxt(sys.argv[5],int)

Rho=numpy.array(range(len(regexlist)*len(regexlist)),dtype=float)
Rho.shape=len(regexlist),-1
print 'caculating Rho...'
for i in range(0,len(regexlist)):
    Rho[i][i]=0
    for j in range(i+1,len(regexlist)):    
        ret=max(0,float(inc_dfasize[i][j])/(float(single_dfasize[i])+float(single_dfasize[j])))
        # print inc_dfasize[i][j], '/', single_dfasize[i], '+', single_dfasize[j],'=',ret
        Rho[i][j]=ret
        Rho[j][i]=ret

gene=population()
gene.initialization(40,groupnum,regexnum)   # chrom_num,group_num,regex_num
(best_id,_,_,_)=gene.get_all_fitness()
# gene.display()

count = 0
last_best = 0
for i in range(100):
    
    print '=== round',i,time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    best_list=gene.chrom_sets[best_id].sequence[:]
    # print 'best_list:'
    # print best_list
    
    gene.evolution()
    (_,_,worst_id,_)=gene.get_all_fitness()    
    # print 'after evolution:'
    # gene.display()
    
    gene.elitist_strategy(worst_id,best_list)
    # print 'after elitist strategy:'
    # gene.display()    
    
    (best_id,best_DFAnum,_,_)=gene.get_all_fitness()
    # print 'recal fitness'
    # gene.display()
    print "best:",best_DFAnum
    if best_DFAnum==last_best:
        count = count+1
    else:
        count = 0
        
    last_best=best_DFAnum
    
    if count==25:
        break
    
print gene.chrom_sets[best_id].sequence
print "best:",best_DFAnum
print "count:",count

write_list(output_filebase+"-"+str(groupnum)+"-ga-my.txt", gene.chrom_sets[best_id].get_DFA_num())
write_grouping_result(output_filebase+"-"+str(groupnum)+"-ga.txt",groupnum,gene.chrom_sets[best_id].sequence)