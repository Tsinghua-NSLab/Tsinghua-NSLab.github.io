#!/usr/bin/python
import os,struct,sys,glob,time,numpy

def read_file(filename):
    configfile=file(filename,'r')
    content=[]
    while True:
        line=configfile.readline()
        if len(line)==0:
            break
        content.append(line)
    configfile.close()
    return content

def write_file(filename,stringlist,lines):
    textfile=file(filename,'w')
    for line in lines:
        textfile.write(stringlist[line])
    textfile.close()

def write_list(filename, mylist):
    textfile=file(filename,'w')
    textfile.write("\n".join(str(x) for x in mylist) + "\n")
    textfile.close()

def execute_command(command):
    #print command
    tmp = os.popen(command)
    while True:
        line=tmp.readline()
        if len(line)==0:
            print 'No output while executing ', command
            size=65535
            break
        if line.startswith('dfa size:'):
            size=int(line[9:-1])
            break
    return size

regex_exe='/home/zhefu/xinming/regex/regex '

if len(sys.argv)!=4:
    print 'Usage: generate_real_size.py regex_filename output_filebase group_result_filename'
    quit()

print time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
regexlist=read_file(sys.argv[1])
input_filename=sys.argv[2]+'.tmp'  #/home/zhefu/xinming/regex/spyware-put.re
output_filebase=sys.argv[2] #/home/zhefu/xinming/regex/spyware-put.re.dfas
groupresult_filename=sys.argv[3]

groupresult=file(groupresult_filename,'r')
groupnum=int(groupresult.readline())
# print groupnum
real_size=[]
all_success=True
for m in range(0,groupnum):
    line=groupresult.readline().split()
    lines=[int(i) for i in line]
    print lines
    write_file(input_filename,regexlist,lines)
    output_filename=output_filebase+'-group'+str(groupnum)+'.dfas'+str(m)
    command=regex_exe+' -p '+input_filename+' --param1 1000000 2>&1'
    # print command
    ret=execute_command(command)
    if ret<0:
        all_success=False
        print 'regex explodes: group',m
        real_size.append(-1)
        break
    else:
        print 'Generated group '+str(m)+' from '+str(len(lines))+' regexes'
        real_size.append(ret)

print real_size

# output_filename=output_filebase+'-group'+str(groupnum)+'.dfas'+str(m)
write_list(output_filebase+"-"+str(groupnum)+"-ga-real.txt", real_size)

os.remove(input_filename)
groupresult.close()
if all_success:
    print 'Successfully generated real DFA groups ',groupnum
else:
    print 'Failed generating real DFA groups ',groupnum
