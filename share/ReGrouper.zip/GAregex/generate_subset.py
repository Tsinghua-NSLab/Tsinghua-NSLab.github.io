#!/usr/bin/python
import os,sys,random

def read_file(filename):
    configfile=file(filename,'r')
    content=[]
    while True:
        line=configfile.readline()
        if len(line)==0:
            break
        content.append(line)
    configfile.close()
    return content

def write_file(filename,stringlist):
    textfile=file(filename,'w')
    for stringlist_it in stringlist:
        textfile.write(stringlist_it)
    textfile.close()


if len(sys.argv)<3:
    print 'Usage: generate_subset.py input_filename percent'
    quit()

regexlist=read_file(sys.argv[1])
output_filename=os.path.splitext(sys.argv[1])[0]+'_'+sys.argv[2]+'.re'
percent=int(sys.argv[2])
select_list = random.sample(range(0,len(regexlist)),percent*len(regexlist)/100)
subset=[]
for select_list_it in select_list:
    subset.append(regexlist[select_list_it])
write_file(output_filename,subset)
