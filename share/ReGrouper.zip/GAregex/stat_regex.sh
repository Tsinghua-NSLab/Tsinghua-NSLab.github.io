#!/bin/bash
for filename in ${@};
do
  echo ${filename}
  awk 'BEGIN{len=10000}{if(length($0)<len && length($0)>0)len=length($0)}END{print len}' ${filename}
  awk 'BEGIN{len=0}{if(length($0)>len)len=length($0)}END{print len}' ${filename}
  awk 'BEGIN{len=0;count=0}{len+=length($0);count+=1;}END{print len/count}' ${filename}
  grep "\.\*|\[[^[]*\]\*|\{[^}]*\}" -E ${filename} |wc -l
  grep "\{[^}]*\}" -E ${filename} |wc -l
done
