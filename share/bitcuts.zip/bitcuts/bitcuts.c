#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <errno.h>
#include <limits.h>
#include <float.h>
#include <sys/queue.h>
#include <math.h>
#include <nmmintrin.h>
#include <immintrin.h>

#include "bitcuts.h"


struct bc_queue_entry {
    STAILQ_ENTRY(bc_queue_entry) e;
    int *rule_id;
    int rule_num;
    int depth;
    struct bc_node *node_addr;
    int is_bottom_level;
};

STAILQ_HEAD(bc_queue_head, bc_queue_entry);

struct bc_runtime {
    struct bc_queue_head wqh;
    const struct partition *p_pa;
    struct bc_tree *trees;
    int cur;
};

struct bss {
    int rule_pair_num;
    int bitmap_chunk_len;
    uint32_t *bitmap;
    int sep_pair_num;
};

struct bit_array {
    int bit_num;
    int bits[HDR_BIT_NUM];
};

struct bucket {
    int rule_num;
    int *rule_id;
};

static int f_bc_init(struct bc_runtime *p_bc_rt, const struct partition *p_pa);
static void f_bc_term(struct bc_runtime *p_bc_rt);
static int f_bc_trigger(struct bc_runtime *p_bc_rt);
static int f_bc_process(struct bc_runtime *p_bc_rt);
static int f_bc_gather(struct bc_runtime *p_bc_rt);

int f_bc_tree_search_tmp(const struct bc_node *p_root, const struct rule_set *p_rule_set,
        const struct packet *p_pkt);
int f_bc_tree_search(const struct bc_node *p_root, const struct rule_set *p_rule_set,
        const struct packet *p_pkt);
static int f_bc_calculate_all_bss(struct bc_runtime *p_bc_rt,
        struct bss *bs_matrix, const struct bc_queue_entry *p_wqe);
static int f_bc_calculate_bss(struct bc_runtime *p_bc_rt, struct bss *bs_matrix, 
        const struct bc_queue_entry *p_wqe, int bit_idx);
static int f_bc_get_bit_value_for_rules(const struct rule_set *p_rs, 
        int *rule_id, int rule_num, int bit_idx, int *rules_bit_value);
static int f_bc_choose_bit(struct bc_runtime *p_bc_rt, struct bss *bs_matrix, 
        const struct bc_queue_entry *p_wqe, struct bit_array *p_b_array);
static int f_bc_split_ruleset(const struct rule_set *p_rs, int *rule_id, 
        int rule_num, struct bit_array *p_b_array, struct bucket *p_bkts);
static int f_bc_split_rule(const struct rule *p_r, int rule_id, struct bit_array *p_b_array, 
        struct bucket *p_bkts);
static int f_bc_construct_bitmap(struct bc_node *p_node, struct bit_array *p_b_array);

static int f_bss_init(struct bss *p_bss, int rule_num);
static int f_bss_set(struct bss *p_bss, int *rules_bit_value, int rule_num);
static int f_bss_subtract(struct bss *p_d, struct bss *p_s);
static int f_bss_count_sep_pair(struct bss *p_bss);
static int f_bs_matrix_term(struct bss *p_bss);

static int f_bit_array_init(struct bit_array *p_ba);
static int f_bit_array_insert_sort(struct bit_array *p_ba, int bit);
static int f_bucket_array_init(struct bucket *p_bkts, int bucket_num, 
        int max_rule_num);
static int f_bucket_array_destroy(struct bucket *p_bkts, int bucket_num);

static void f_wqe_destroy(struct bc_queue_entry *p_wqe);
static void print_rule(struct rule *p_r);

int bc_build(void *built_result, const struct partition *p_pa)
{
    int ret, i;
    struct bc_runtime bc_rt;
    struct bc_result *p_bc_result;

    if (!built_result || !p_pa || !p_pa->subsets || p_pa->subset_num <= 0 ||
        p_pa->subset_num > PART_MAX || p_pa->rule_num <= 1) {
        return -EINVAL;
    }

    /* Init */
    ret = f_bc_init(&bc_rt, p_pa);
    if (ret) {
        return ret;
    }

    /** Build BitCuts tree for each subset */
    for (bc_rt.cur = 0; bc_rt.cur < p_pa->subset_num; bc_rt.cur++)
    {
        /* Trigger entry enqueue */
        ret = f_bc_trigger(&bc_rt);
        if (ret) {
            goto err;
        }

        /* BitCuts building */
        ret = f_bc_process(&bc_rt);
        if (ret) {
            goto err;
        }
        
        /* Write Stats */
        ret = f_bc_gather(&bc_rt);
        if (ret) {
            goto err;
        }
    }

    /* Write final result */
    p_bc_result = (struct bc_result *)malloc(sizeof(*p_bc_result));
    if (!p_bc_result) {
        printf("Error malloc p_bc_result\n");
        ret = -ENOMEM;
        goto err;
    }

    p_bc_result->trees = bc_rt.trees;
    p_bc_result->rulesets = p_pa->subsets;
    bc_rt.trees = NULL;
    p_bc_result->tree_num = p_pa->subset_num;
    p_bc_result->def_rule = 0;
    for (i = 0; i < p_pa->subset_num; i++) {
        if (p_bc_result->def_rule < p_pa->subsets[i].def_rule)
            p_bc_result->def_rule = p_pa->subsets[i].def_rule;
    }
    *(typeof(p_bc_result) *)built_result = p_bc_result;

    /* Free intermediate variables */
    f_bc_term(&bc_rt);

    return 0;

err:
    while (--bc_rt.cur >= 0) {
        free(bc_rt.trees[bc_rt.cur].p_root);
    }

    f_bc_term(&bc_rt);

    return ret;
}

int bc_search_tmp(const void *built_result, const struct packet *p_pkt)
{
    /* int i, j, pri, id; */
    int i, id;
    const struct bc_result *p_bc_result;
    register const struct bc_node *p_curr_n;
    register const struct rule_set *p_rule_set;
    register const struct rule *p_r;
    register uint64_t result[2], res = 0;

    p_bc_result = *(typeof(p_bc_result) *)built_result;
    p_curr_n = p_bc_result->trees[0].p_root;
    p_rule_set = &p_bc_result->rulesets[0];

    while (p_curr_n->n_type == 0) {
        result[0] = _pext_u64(p_pkt->header_u64[0], p_curr_n->bitmask[0]);
        result[1] = _pext_u64(p_pkt->header_u64[1], p_curr_n->bitmask[1]);
        res = (result[0] << p_curr_n->right_one_num) + result[1];
        p_curr_n = p_curr_n->child_nodes + res;
    }

    for (i = 0; i < p_curr_n->rule_num; i++) {
        p_r = &p_rule_set->rules[p_curr_n->rule_id[i]];
        if (p_r->dims[0][0] <= p_pkt->sip && p_r->dims[0][1] >= p_pkt->sip &&
                p_r->dims[1][0] <= p_pkt->dip && p_r->dims[1][1] >= p_pkt->dip &&
                p_r->dims[2][0] <= p_pkt->sport && p_r->dims[2][1] >= p_pkt->sport &&
                p_r->dims[3][0] <= p_pkt->dport && p_r->dims[3][1] >= p_pkt->dport &&
                p_r->dims[4][0] <= p_pkt->proto && p_r->dims[4][1] >= p_pkt->proto) {
            id = p_r->pri < id ? p_r->pri : id;
        }
    }

    return id;
}

int bc_search(const struct trace *p_t, const void *built_result)
{
    int i, j, pri, id;
    const struct bc_result *p_bc_result;

    register const struct packet *p_pkt;
    register const struct bc_node *p_root;

    if (!p_t || !p_t->pkts || !built_result) {
        return -EINVAL;
    }

    p_bc_result = *(typeof(p_bc_result) *)built_result;
    if (!p_bc_result || !p_bc_result->trees) {
        return -EINVAL;
    }

    /* For each packet */
    for (i = 0; i < p_t->pkt_num; i++) {
        /* pri = p_bc_result->def_rule; */
        pri = INT_MAX;
        p_pkt = &p_t->pkts[i];

        /* For each tree */
        for (j = 0; j < p_bc_result->tree_num; j++) {
            p_root = p_bc_result->trees[j].p_root;
            id = f_bc_tree_search(p_root, &p_bc_result->rulesets[j], p_pkt);
            if (id < pri) {
                pri = id;
            }
        }

        if (pri != p_pkt->match_rule) {
            fprintf(stderr, "Packet %d match %d, but should match %d\n",
                    i, pri, p_pkt->match_rule);
            return -EFAULT;
        }
    }

    return 0;
}

int f_bc_tree_search_tmp(const struct bc_node *p_root, const struct rule_set *p_rule_set,
        const struct packet *p_pkt) 
{
    const struct bc_node *p_curr_n = p_root;
    const struct rule *p_r;
    uint64_t result[2], res = 0;
    int i, id = INT_MAX;

    while (p_curr_n->n_type == 0) {
        result[0] = _pext_u64(p_pkt->header_u64[0], p_curr_n->bitmask[0]);
        result[1] = _pext_u64(p_pkt->header_u64[1], p_curr_n->bitmask[1]);
        res = (result[0] << p_curr_n->right_one_num) + result[1];
        p_curr_n = p_curr_n->child_nodes + res;
    }

    for (i = 0; i < p_curr_n->rule_num; i++) {
        p_r = &p_rule_set->rules[p_curr_n->rule_id[i]];
        if (p_r->dims[0][0] <= p_pkt->sip && p_r->dims[0][1] >= p_pkt->sip &&
                p_r->dims[1][0] <= p_pkt->dip && p_r->dims[1][1] >= p_pkt->dip &&
                p_r->dims[2][0] <= p_pkt->sport && p_r->dims[2][1] >= p_pkt->sport &&
                p_r->dims[3][0] <= p_pkt->dport && p_r->dims[3][1] >= p_pkt->dport &&
                p_r->dims[4][0] <= p_pkt->proto && p_r->dims[4][1] >= p_pkt->proto) {
            id = p_r->pri < id ? p_r->pri : id;
        }
    }

    return id;
}

int f_bc_tree_search(const struct bc_node *p_root, const struct rule_set *p_rule_set,
        const struct packet *p_pkt) 
{
    const struct bc_node *p_curr_n = p_root;
    const struct rule *p_r;
    uint64_t result[2], res = 0;
    int i, j, id = INT_MAX, match;

    while (p_curr_n->n_type == 0) {
        result[0] = _pext_u64(p_pkt->header_u64[0], p_curr_n->bitmask[0]);
        result[1] = _pext_u64(p_pkt->header_u64[1], p_curr_n->bitmask[1]);
        res = (result[0] << p_curr_n->right_one_num) + result[1];
        p_curr_n = p_curr_n->child_nodes + res;
    }

    for (i = 0; i < p_curr_n->rule_num; i++) {
        match = 1;
        p_r = &p_rule_set->rules[p_curr_n->rule_id[i]];
        for (j = 0; j < DIM_MAX; j++) {
            if (p_r->dims[j][0] > p_pkt->dims[j] || p_r->dims[j][1] < p_pkt->dims[j]) {
                match = 0;
                break;
            }
        }
        if (match == 1)
            id = p_r->pri < id ? p_r->pri : id;
    }

    return id;
}

void bc_destroy(void *built_result) {
    // TODO: To implement
    
    return;
}

static int f_bc_init(struct bc_runtime *p_bc_rt, const struct partition *p_pa)
{
    struct bc_tree *trees;
    trees = (struct bc_tree *)calloc(p_pa->subset_num, sizeof(*trees));
    if (!trees) {
        printf("Error calloc trees \n");
        return -ENOMEM;
    }

    /* printf("Rule number %d, Round up %ld, mpool node %ld, size %ld\n",
     *         p_pa->rule_num, p2roundup(p_pa->rule_num), p2roundup(p_pa->rule_num),
     *         p2roundup(p_pa->rule_num) * sizeof(struct bc_node)); */
    /* MPOOL_INIT(&p_bc_rt->node_pool, p2roundup(p_pa->rule_num)); */
    STAILQ_INIT(&p_bc_rt->wqh);
    p_bc_rt->p_pa = p_pa;
    p_bc_rt->trees = trees;

    return 0;
}

static void f_bc_term(struct bc_runtime *p_bc_rt) {
    free(p_bc_rt->trees);
    return;
}

static int f_bc_trigger(struct bc_runtime *p_bc_rt)
{
    struct bc_tree *p_tree;
    const struct rule_set *p_rs;

    assert(p_bc_rt && p_bc_rt->trees);
    assert(p_bc_rt->p_pa->subsets[p_bc_rt->cur].rules);
    assert(p_bc_rt->p_pa->subsets[p_bc_rt->cur].rule_num > 0);

    p_tree = &p_bc_rt->trees[p_bc_rt->cur];
    p_rs = &p_bc_rt->p_pa->subsets[p_bc_rt->cur];

    int i, *rule_id = (int *)malloc(p_rs->rule_num * sizeof(*rule_id));
    struct bc_queue_entry *p_wqe = (struct bc_queue_entry *)malloc(sizeof(*p_wqe));
    if (!rule_id || !p_wqe) {
        printf("Error malloc in f_bc_trigger\n");
        free(p_wqe);
        free(rule_id);
        return -ENOMEM;
    }
    
    for (i = 0; i < p_rs->rule_num; i++) {
        rule_id[i] = i;
    }
    p_wqe->rule_id = rule_id;
    p_wqe->rule_num = p_rs->rule_num;
    p_wqe->depth = 1;
    p_wqe->node_addr = (struct bc_node *)malloc(sizeof(struct bc_node));
    p_wqe->is_bottom_level = 0;
    p_tree->inode_num++;
    p_tree->isize_node_num++;
    p_tree->p_root = p_wqe->node_addr;
    STAILQ_INSERT_HEAD(&p_bc_rt->wqh, p_wqe, e);

    return 0;
}

static int f_bc_process(struct bc_runtime *p_bc_rt)
{
    struct bc_queue_head *p_wqh;
    struct bc_queue_entry *p_wqe;
    struct bc_node *p_node;
    struct bss *bs_matrix;
    struct bit_array b_array;
    struct bucket *p_bkts;
    struct bc_tree *p_tree = &p_bc_rt->trees[p_bc_rt->cur];
    int i, max_b_size = 0;

    /* The loop processes all nodes */
    p_wqh = &p_bc_rt->wqh;
    while (!STAILQ_EMPTY(p_wqh)) {
        p_wqe = STAILQ_FIRST(p_wqh);
        STAILQ_REMOVE_HEAD(p_wqh, e);

        /* If leaf node */
        if (p_wqe->rule_num <= BINTH) {
            p_node = p_wqe->node_addr;
            p_node->n_type = 1;
            p_node->rule_num = p_wqe->rule_num;
            p_node->rule_id = (int *)malloc(p_wqe->rule_num * sizeof(int));
            if (!p_node->rule_id) {
                return -ENOMEM;
            }
            memcpy((void *)p_node->rule_id, (void *)p_wqe->rule_id, 
                    p_wqe->rule_num * sizeof(int));
            p_tree->enode_num++;
            if (!p_wqe->is_bottom_level) {
                p_tree->isize_node_num++;
            }
            p_tree->leaf_rule_num += p_wqe->rule_num;
            p_tree->depth_avg += p_wqe->depth + p_wqe->rule_num;
            if (p_tree->depth_max < p_wqe->depth + p_wqe->rule_num ) {
                p_tree->depth_max = p_wqe->depth + p_wqe->rule_num;
            }

        /* Internal node*/
        } else {
            bs_matrix = (struct bss *)calloc(HDR_BIT_NUM, sizeof(struct bss));
            if (!bs_matrix) {
                return -ENOMEM;
            }
            /* Calculate the bsses for each candidate bits */
            f_bc_calculate_all_bss(p_bc_rt, bs_matrix, p_wqe);

            /* Choose cutting bits */
            f_bit_array_init(&b_array);
            f_bc_choose_bit(p_bc_rt, bs_matrix, p_wqe, &b_array);
            f_bs_matrix_term(bs_matrix);

            /* If no bits can futher separate any rules*/
            if (b_array.bit_num == 0) {
                p_node = p_wqe->node_addr;
                p_node->n_type = 1;
                p_node->rule_num = p_wqe->rule_num;
                /* p_node->node_id = p_wqe->node_id; */
                p_node->rule_id = (int *)malloc(p_wqe->rule_num * sizeof(int));
                if (!p_node->rule_id) {
                    return -ENOMEM;
                }
                memcpy((void *)p_node->rule_id, (void *)p_wqe->rule_id, p_wqe->rule_num * sizeof(int));
                p_tree->enode_num++;
                if (p_wqe->is_bottom_level) {
                    p_tree->isize_node_num++;
                }
                p_tree->leaf_rule_num += p_wqe->rule_num;
                p_tree->depth_avg += p_wqe->depth + p_wqe->rule_num;
                if (p_tree->depth_max < p_wqe->depth + p_wqe->rule_num ) {
                    p_tree->depth_max = p_wqe->depth + p_wqe->rule_num;
                }

            } else {
                /* Set the bitmask of current node */
                p_node = p_wqe->node_addr;
                p_node->n_type = 0;
                p_node->bitmask[0] = p_node->bitmask[1] = 0;

                /* Construct the bitmap for the p_node */
                f_bc_construct_bitmap(p_node, &b_array);

                /* Split the rules with the selected bits */
                p_bkts = (struct bucket *)calloc(1<<b_array.bit_num, sizeof(*p_bkts));
                if (f_bucket_array_init(p_bkts, 1<<b_array.bit_num, p_wqe->rule_num)) {
                    return -ENOMEM;
                }
                f_bc_split_ruleset(&p_bc_rt->p_pa->subsets[p_bc_rt->cur], p_wqe->rule_id,
                        p_wqe->rule_num, &b_array, p_bkts);

                for (i = 0; i < (1<<b_array.bit_num); i++) {
                    if (p_bkts[i].rule_num > max_b_size)
                        max_b_size = p_bkts[i].rule_num;
                }

                p_node->child_nodes = (struct bc_node *)calloc(1<<b_array.bit_num, sizeof(struct bc_node));
                if (!p_node->child_nodes) {
                    return -ENOMEM;
                }

                p_tree->inode_num++;
                p_tree->isize_node_num++;
                p_tree->child_ptr_num += 1<<b_array.bit_num;

                for (i = 0; i < 1<<b_array.bit_num; i++) {
                    struct bc_queue_entry *p_new_wqe = (struct bc_queue_entry *)malloc(sizeof(*p_new_wqe));
                    if (!p_new_wqe) {
                        return -ENOMEM;
                    }
                    p_new_wqe->node_addr = &p_node->child_nodes[i];
                    p_new_wqe->rule_num = p_bkts[i].rule_num;
                    p_new_wqe->rule_id = (int *)malloc(p_bkts[i].rule_num * sizeof(int));
                    if (!p_new_wqe->rule_id) {
                        return -ENOMEM;
                    }
                    memcpy((void *)p_new_wqe->rule_id, (void *)p_bkts[i].rule_id, p_bkts[i].rule_num * sizeof(int));
                    p_new_wqe->depth = p_wqe->depth + 1;
                    if (max_b_size <= BINTH) {
                        p_new_wqe->is_bottom_level = 1;
                    }
                    STAILQ_INSERT_HEAD(&p_bc_rt->wqh, p_new_wqe, e);
                }

                f_bucket_array_destroy(p_bkts, 1<<b_array.bit_num);
            }
        }   

        f_wqe_destroy(p_wqe);
    }

    return 0;
}

static int f_bc_gather(struct bc_runtime *p_bc_rt)
{
    struct bc_tree *p_tree;

    p_tree = &p_bc_rt->trees[p_bc_rt->cur];
    p_tree->depth_avg /= p_tree->enode_num;

    return 0;
}
static int f_bc_choose_bit(struct bc_runtime *p_bc_rt, struct bss *bs_matrix, 
        const struct bc_queue_entry *p_wqe, struct bit_array *p_b_array)
{
    int i, best_bit = 0;
    int total_sep_pair;
    int max_b_size, total_b_size;
    double spfac;
    struct rule_set *p_rs = &p_bc_rt->p_pa->subsets[p_bc_rt->cur];
    struct bucket *p_bkts;

    int round = 0;
    max_b_size = p_rs->rule_num;

    while (1) {
        best_bit = 0;
        total_sep_pair = 0;
        spfac = 1.0;

        for (i = 0; i < HDR_BIT_NUM; i++) {
            total_sep_pair += bs_matrix[i].sep_pair_num;
            if (bs_matrix[i].sep_pair_num > bs_matrix[best_bit].sep_pair_num)
                best_bit = i;
        }

        /* If each remaining individual bit cannot separate any rules, return */
        if (total_sep_pair == 0) {
            //printf("bit selection break: sep pair = 0 \n");
            break;
        }
        
        /* Select the best bit and generate the resulting buckets */
        f_bit_array_insert_sort(p_b_array, best_bit);
        p_bkts = (struct bucket *)calloc(1<<p_b_array->bit_num, sizeof(*p_bkts));
        if (f_bucket_array_init(p_bkts, 1<<p_b_array->bit_num, max_b_size)) {
            printf("Error calloc p_bkts in f_bc_choose_bit\n");
            return -ENOMEM;
        }
        f_bc_split_ruleset(p_rs, p_wqe->rule_id, p_wqe->rule_num, p_b_array, p_bkts);

        /* Check Binth and Spfac */
        total_b_size = max_b_size = 0;
        for (i = 0; i < (1<<p_b_array->bit_num); i++) {
            if (p_bkts[i].rule_num > max_b_size)
                max_b_size = p_bkts[i].rule_num;
            total_b_size += p_bkts[i].rule_num;
        }
        spfac = (double)(total_b_size + (1<<p_b_array->bit_num)) / p_wqe->rule_num;
        f_bucket_array_destroy(p_bkts, 1<<p_b_array->bit_num);
        if (spfac >= SPFAC || max_b_size <= BINTH) {
            break;
        }

        /* Update the bs_matrix */
        for (i = 0; i < HDR_BIT_NUM; i++) {
            if (i != best_bit)
                f_bss_subtract(&bs_matrix[i], &bs_matrix[best_bit]);
        }
        f_bss_subtract(&bs_matrix[best_bit], &bs_matrix[best_bit]);

        round++;
    }

    return 0;
}

static int f_bc_calculate_all_bss(struct bc_runtime *p_bc_rt,
        struct bss *bs_matrix, const struct bc_queue_entry *p_wqe)
{
    int i;
    for (i = 0; i < HDR_BIT_NUM; i++) {
        f_bc_calculate_bss(p_bc_rt, bs_matrix, p_wqe, i);
    }
    return 0;

}

static int f_bc_calculate_bss(struct bc_runtime *p_bc_rt, struct bss *bs_matrix, 
        const struct bc_queue_entry *p_wqe, int bit_idx)
{
    struct rule_set *p_rs = &p_bc_rt->p_pa->subsets[p_bc_rt->cur];

    /* Array that stores the value of bit "bit_idx" for each rule:
     * -1 (wildcard), 0 or 1 */
    int *rules_bit_value = (int *)malloc(sizeof(int) * p_wqe->rule_num);
    if (!rules_bit_value) {
        printf("Error malloc rules_bit_value\n");
        return -ENOMEM;
    }
    f_bc_get_bit_value_for_rules(p_rs, p_wqe->rule_id, p_wqe->rule_num, bit_idx, rules_bit_value);

    f_bss_init(&bs_matrix[bit_idx], p_wqe->rule_num);
    f_bss_set(&bs_matrix[bit_idx], rules_bit_value, p_wqe->rule_num);

    if (bs_matrix[bit_idx].sep_pair_num !=
            f_bss_count_sep_pair(&bs_matrix[bit_idx])) {
        printf("Bit %d seperated %d pairs, counted as %d", bit_idx, 
            bs_matrix[bit_idx].sep_pair_num, 
            f_bss_count_sep_pair(&bs_matrix[bit_idx]));
        printf("\n");
    }

    free(rules_bit_value);

    return 0;
}

static int f_bc_get_bit_value_for_rules(const struct rule_set *p_rs, 
        int *rule_id, int rule_num, int bit_idx, int *rules_bit_value)
{
    int i, field_nth_bit;
    for (i = 0; i < rule_num; i++) {

        if (bit_idx >= 0 && bit_idx < 32) {

            field_nth_bit = bit_idx;
            uint32_t mask = 1 << (32 - 1 - field_nth_bit);

            if (field_nth_bit >= p_rs->rules[rule_id[i]].sip_pref_len)
                rules_bit_value[i] = -1;
            else if ((p_rs->rules[rule_id[i]].sip_pref & mask) == 0)
                rules_bit_value[i] = 0;
            else  
                rules_bit_value[i] = 1;
        
        } else if (bit_idx >= 32 && bit_idx < 64) {

            field_nth_bit = bit_idx - 32;
            uint32_t mask = 1 << (32 - 1 - field_nth_bit);

            if (field_nth_bit >= p_rs->rules[rule_id[i]].dip_pref_len)
                rules_bit_value[i] = -1;
            else if ((p_rs->rules[rule_id[i]].dip_pref & mask) == 0)
                rules_bit_value[i] = 0;
            else  
                rules_bit_value[i] = 1;

        } else if (bit_idx >= 64 && bit_idx < 80) {
            field_nth_bit = bit_idx - 64;
            uint32_t mask = 1 << (16 - 1 - field_nth_bit);

            if ((p_rs->rules[rule_id[i]].dims[2][0] ^ p_rs->rules[rule_id[i]].dims[2][1])
                    >= mask)
                rules_bit_value[i] = -1;
            else if ((p_rs->rules[rule_id[i]].dims[2][0] & mask) == 0)
                rules_bit_value[i] = 0;
            else
                rules_bit_value[i] = 1;

        } else if (bit_idx >= 80 && bit_idx < 96) {
            field_nth_bit = bit_idx - 80;
            uint32_t mask = 1 << (16 - 1 - field_nth_bit);

            if ((p_rs->rules[rule_id[i]].dims[3][0] ^ p_rs->rules[rule_id[i]].dims[3][1])
                    >= mask)
                rules_bit_value[i] = -1;
            else if ((p_rs->rules[rule_id[i]].dims[3][0] & mask) == 0)
                rules_bit_value[i] = 0;
            else
                rules_bit_value[i] = 1;

        } else if (bit_idx >= 96 && bit_idx < 104) {
            field_nth_bit = bit_idx - 96;
            uint32_t mask = 1 << (8 - 1 - field_nth_bit);

            if ((mask & p_rs->rules[rule_id[i]].proto_mask) == 0)
                rules_bit_value[i] = -1;
            else if ((mask & p_rs->rules[rule_id[i]].proto_pref) == 0)
                rules_bit_value[i] = 0;
            else
                rules_bit_value[i] = 1;
        }
    }
    return 0;
}

static int f_bc_split_ruleset(const struct rule_set *p_rs, int *rule_id, 
        int rule_num, struct bit_array *p_b_array, struct bucket *p_bkts)
{
    int i;
    for (i = 0; i < rule_num; i++) {
        f_bc_split_rule(&p_rs->rules[rule_id[i]], rule_id[i], p_b_array, p_bkts);
    }

    return 0;
}

static int f_bc_split_rule(const struct rule *p_r, int rule_idx, struct bit_array *p_b_array, 
        struct bucket *p_bkts)
{
    int i = 0, bit_idx, field_nth_bit, index = 0, index_in = 0;
    int index_bit_mask = 0, rule_bit_mask = 0;
    int bit_num = p_b_array->bit_num;
    uint32_t port_xor;

    for (index = 0; index < (1 << p_b_array->bit_num); index++) {

        index_in = 1;
        for (i = 0; i < bit_num; i++) {
            index_bit_mask = 1 << (bit_num - 1 - i);
            bit_idx = p_b_array->bits[i];

            if (bit_idx == -1) {
                printf("Error: Splitting at bit_idx -1\n");
                continue;
            }

            else if (bit_idx >= 0 && bit_idx < 32) {
                field_nth_bit = bit_idx;
                rule_bit_mask = 1 << (31 - field_nth_bit);
                /* Bit 1 is the least bit specifed in /2 prefix */
                if (field_nth_bit < p_r->sip_pref_len) {
                    if ((index & index_bit_mask) >> (bit_num - 1 - i) != 
                            (p_r->sip_pref & rule_bit_mask) >> (31 - field_nth_bit)) {
                        index_in = 0;
                        break;
                    }
                }
            
            } else if (bit_idx >= 32 && bit_idx < 64) {
                field_nth_bit = bit_idx - 32;
                rule_bit_mask = 1 << (31 - field_nth_bit);
                if (field_nth_bit < p_r->dip_pref_len) {
                    if ((index & index_bit_mask) >> (bit_num - 1 - i) != 
                            (p_r->dip_pref & rule_bit_mask) >> (31 - field_nth_bit)) {
                        index_in = 0;
                        break;
                    }
                }
            
            } else if (bit_idx >= 64 && bit_idx < 80) {
                field_nth_bit = bit_idx - 64;
                rule_bit_mask = 1 << (15 - field_nth_bit);
                if (rule_bit_mask > p_r->dims[2][1] - p_r->dims[2][0]) {
                    port_xor = p_r->dims[2][1] ^ p_r->dims[2][0];
                    if ((port_xor & rule_bit_mask) == 0) {
                        if ((index & index_bit_mask) >> (bit_num - 1 - i) !=
                                (p_r->dims[2][0] & rule_bit_mask) >> (15 - field_nth_bit)) {
                            index_in = 0;
                            break;
                        }
                    }
                }
            
            } else if (bit_idx >= 80 && bit_idx < 96) {
                field_nth_bit = bit_idx - 80;
                rule_bit_mask = 1 << (15 - field_nth_bit);
                if (rule_bit_mask > p_r->dims[3][1] - p_r->dims[3][0]) {
                    port_xor = p_r->dims[3][1] ^ p_r->dims[3][0];
                    if ((port_xor & rule_bit_mask) == 0) {
                        if ((index & index_bit_mask) >> (bit_num - 1 - i) !=
                                (p_r->dims[3][0] & rule_bit_mask) >> (15 - field_nth_bit)) {
                            index_in = 0;
                            break;
                        }
                    }
                }           

            } else if (bit_idx >= 96 && bit_idx < 104) {
                field_nth_bit = bit_idx - 96;
                if (p_r->proto_mask != 0) {
                    rule_bit_mask = 1 << (7 - field_nth_bit);
                    if ((index & index_bit_mask) >> (bit_num - 1 - i) != 
                            (p_r->proto_pref & rule_bit_mask) >> (7 - field_nth_bit)) {
                        index_in = 0;
                        break;
                    }
                }
            }
        }

        if (index_in == 1) {
            p_bkts[index].rule_id[p_bkts[index].rule_num++] = rule_idx;
        }
    }

    return 0;
}

static int f_bc_construct_bitmap(struct bc_node *p_node, struct bit_array *p_b_array)
{
    int i, right_one_num = 0;
    for (i = 0; i < p_b_array->bit_num; i++) {
        if (p_b_array->bits[i] < 64) {
            p_node->bitmask[0] |= (uint64_t)1<<(64 - 1 - p_b_array->bits[i]);

        } else if (p_b_array->bits[i] < 104) {
            //use higher 40 bits (Bit 0 ... Bit 39) in bitmask[1]
            p_node->bitmask[1] |= (uint64_t)1<<(64 - 1 - (p_b_array->bits[i] - 64));
            right_one_num++;
        }
    }
    p_node->right_one_num = right_one_num;
    p_node->rule_id = NULL;
    p_node->rule_num = 0;

    return 0;
}

static void print_rules(struct rule_set *p_rs) 
{
    int i;
    for (i = 0; i < p_rs->rule_num; i++) {
       printf("Rule %d: ", i);
       print_rule(&p_rs->rules[i]);
    }
    return;
}

static void print_rule(struct rule *p_r) 
{
    printf("%"PRIu32"/%"PRIu8" ", p_r->sip_pref,
            p_r->sip_pref_len);
    printf("%"PRIu32"/%"PRIu8" ", p_r->dip_pref,
            p_r->dip_pref_len);
    printf("%"PRIu32"-%"PRIu32" ", p_r->dims[2][0],
            p_r->dims[2][1]);
    printf("%"PRIu32"-%"PRIu32" ", p_r->dims[3][0],
            p_r->dims[3][1]);
    printf("%"PRIu32"/%"PRIx8"\n", p_r->proto_pref,
            p_r->proto_mask);
    return;
}

static int f_bss_init(struct bss *p_bss, int rule_num)
{
    p_bss->sep_pair_num = 0;
    p_bss->rule_pair_num = rule_num * (rule_num - 1) / 2;
    p_bss->bitmap_chunk_len = (int)ceil((double)p_bss->rule_pair_num 
            / SEP_PAIR_BITMAP_CHUNK_SIZE);
    p_bss->bitmap = (uint32_t *)calloc(p_bss->bitmap_chunk_len, sizeof(uint32_t));
    if (!p_bss->bitmap) {
        printf("Error calloc bitmap\n");
        return -ENOMEM;
    }
    return 0;
}

static int f_bs_matrix_term(struct bss *bs_matrix)
{
    int i;
    for (i = 0; i < HDR_BIT_NUM; i++) {
        free(bs_matrix[i].bitmap);
    }
    free(bs_matrix);
    return 0;
}

/* Set the bitmap and sep_pair_num of the bss */
static int f_bss_set(struct bss *p_bss, int *rules_bit_value, int rule_num)
{
    int i = 0, j = 0, s_rid = 0, l_rid = 0, zero_num = 0, one_num = 0;
    int bitmap_idx = 0;
    int *b[2]; 
    b[0] = (int *)malloc(rule_num * sizeof(int));
    b[1] = (int *)malloc(rule_num * sizeof(int));
    if (!b[0] || !b[1]) {
        printf("Cannot malloc memory for bss\n");
        return -ENOMEM;
    }

    for (i = 0; i < rule_num; i++) {
        if (rules_bit_value[i] == 0)
            b[0][zero_num++] = i;
        if (rules_bit_value[i] == 1)
            b[1][one_num++] = i;
    }

    int nth_chunk, nth_bit;
    uint32_t v;
    for (i = 0; i < zero_num; i++) {
        for (j = 0; j < one_num; j++) {
            s_rid = b[0][i] < b[1][j] ? b[0][i] : b[1][j];
            l_rid = b[0][i] < b[1][j] ? b[1][j] : b[0][i];
            bitmap_idx = rule_num * s_rid - (1 + s_rid) * s_rid / 2;
            bitmap_idx += l_rid - s_rid - 1;
            /* chunk id start from 0 */
            nth_chunk = bitmap_idx / SEP_PAIR_BITMAP_CHUNK_SIZE;
            nth_bit = bitmap_idx % SEP_PAIR_BITMAP_CHUNK_SIZE;
            /* Lower bit represent smaller pair index */
            v = (uint32_t)(1 << nth_bit);
            p_bss->bitmap[nth_chunk] |= v;
            p_bss->sep_pair_num++;
        }
    }

    free(b[0]);
    free(b[1]);
    return 0;
}

static int f_bss_subtract(struct bss *p_d, struct bss *p_s)
{
    int i, cnt = 0;
    for (i = 0; i < p_d->bitmap_chunk_len; i++) {
        cnt += _mm_popcnt_u32(p_d->bitmap[i] & p_s->bitmap[i]);
        p_d->bitmap[i] &= (~p_s->bitmap[i]);
    }
    p_d->sep_pair_num -= cnt;

    return 0;
}

static int f_bss_count_sep_pair(struct bss *p_bss)
{
    int i = 0, cnt = 0;
    for (i = 0; i < p_bss->bitmap_chunk_len; i++) {
        cnt += _mm_popcnt_u32(p_bss->bitmap[i]);
    }
    return cnt;
}

static int f_bit_array_init(struct bit_array *p_ba)
{
    int i;
    p_ba->bit_num = 0;
    for (i = 0; i < HDR_BIT_NUM; i++)
        p_ba->bits[i] = -1;

    return 0;
}

static int f_bit_array_insert_sort(struct bit_array *p_ba, int bit)
{
    int i = 0, j = 0;

    while (p_ba->bits[i] != -1) {

        if (p_ba->bits[i] > bit)
            break;
        i++;
    }

    /* i is the first element larger than bit or the next slot of the tail */
    for (j = p_ba->bit_num; j > i; j--) {
        p_ba->bits[j] = p_ba->bits[j - 1];
    }
    p_ba->bits[i] = bit;
    p_ba->bit_num++;

    return 0;
}

static int f_bucket_array_init(struct bucket *p_bkts, int bucket_num,
        int max_rule_num) 
{
    int i;
    for (i = 0; i < bucket_num; i++) {
        p_bkts[i].rule_num = 0;
        p_bkts[i].rule_id = (int *)calloc(max_rule_num, sizeof(int));
        if (p_bkts[i].rule_id == NULL) {
            printf("Error calloc rule_id in f_bucket_array_init\n");
            return -ENOMEM;
        }
    }
    return 0;
}

static int f_bucket_array_destroy(struct bucket *p_bkts, int bucket_num) 
{
    int i;
    for (i = 0; i < bucket_num; i++) {
        free(p_bkts[i].rule_id);
    }
    free(p_bkts);
    return 0;
}

static void f_wqe_destroy(struct bc_queue_entry *p_wqe)
{
    free(p_wqe->rule_id);
    free(p_wqe);
    return;
}

void bc_print_stat(const void *result)
{
    const struct bc_result *tmp = (const struct bc_result *)result;
    struct bc_tree *p_tree = tmp->trees;
    int i;
    for (i = 0; i < tmp->tree_num; i++) {
       printf("Tree %d\n", i);
       printf("Max depth %d\n", p_tree->depth_max);
       printf("Average depth %f\n", p_tree->depth_avg);
       /* uint64_t tree_size = (p_tree->inode_num + p_tree->enode_num) * sizeof(struct bc_node) 
        *     + p_tree->inode_num * sizeof(struct bc_node *)
        *     + p_tree->leaf_rule_num * sizeof(int); */
       uint64_t tree_size = p_tree->isize_node_num * INODE_SIZE 
           + p_tree->enode_num * ENODE_SIZE 
           + p_tree->child_ptr_num * 4 // Number of child pointer
           + p_tree->leaf_rule_num * 4; // Leaf rule number * 4 (int size)
       printf("Size %lu KB\n", (tree_size >> 10));
       p_tree++;
    }

    return;
}
