#ifndef __BITCUTS_H__
#define __BITCUTS_H__

#include <stdint.h>
#include "rule_trace.h"

#define BINTH 8
#define SPFAC 4
#define HDR_BIT_NUM 104
#define SEP_PAIR_BITMAP_CHUNK_SIZE 32
// Node type(1 Byte) + Number of Rules(4 Bytes) + Rule list pointer(4 Bytes)
#define ENODE_SIZE (1 + 4 + 4) 
// Node type(1 Byte) + Mask (2 * 8 Bytes) + Number of lower bits(4 Bytes) 
// + Child list pointer(4 Bytes)
#define INODE_SIZE (1 + 16 + 4 + 4)

struct bc_node {
    uint8_t n_type; /* 0 for internal node, 1 for leaf node */
    uint64_t bitmask[2];
    uint8_t right_one_num; /* Number of bits selected in the lower bitmask */
    struct bc_node *child_nodes;
    int rule_num;
    int *rule_id;
    ssize_t node_id;
};

struct bc_tree {
    struct bc_node *p_root;
    int inode_num; /* Internal node number */
    int enode_num; /* Leaf node number */
    int isize_node_num; /* Leaf node number */
    int depth_max;
    int leaf_rule_num;
    double depth_avg;
    int child_ptr_num;
};

struct bc_result {
    struct rule_set *rulesets;
    struct bc_tree *trees;
    int tree_num;
    int def_rule;
};

int bc_build(void *build_result, const struct partition *p_pa);
int bc_search(const struct trace *p_t, const void *built_result);
void bc_destroy(void *built_result);
void bc_print_stat(const void *result);

#endif /* __BITCUTS_H__ */
