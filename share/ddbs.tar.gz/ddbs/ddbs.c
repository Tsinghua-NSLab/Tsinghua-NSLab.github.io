/*
 * DDBS v1.0 : The source code for the DDBS Algorithm
 * Copyright (C) 2007- Tsinghua NSLab
 * Authors: Baohua Yang<yangbaohua@gmail.com> 
 * Last Modified: 2010/04/19
 * Create Time: 2010/04/19
 */

#ifdef WINDOWS
#include <STDIO.H>
#include <STDLIB.H>
#include <MEMORY.H>
#include <WINDOWS.H>
#include <CONIO.H>
#include <MATH.H>
#else
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <getopt.h>
#include <assert.h>
#include <unistd.h>
#include <time.h>
#endif

#include "ddbs.h"

static PINFO_STAT info_stat=NULL; //store stat info in this bit
static PBLOCK pblock=NULL; //splited ruleset into blocks
U16 h_table[256]; //return number of 1 in bitstring i
float similar_matrix[NUM_BIT_HDR][NUM_BIT_HDR]; //similar value between different bit dims

static const char* fp_history="history.txt";
static const char* fp_result="result.txt";

static int CountStat(pFiltSet pfiltset);
static int CountFilter(pFilter pfilter);
static void PrintBitCount();
static U16 PrintBlockStat(U32 len_bitstring,pFiltSet pfiltset, FILE *fp);
static U32 SplitRuleSet(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock);
static void SplitFilter(pFilter pfilter,U32 *bitstring,U32 len_bitstring,PBLOCK pblock);
static void LookupTest(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring);
static U32 GetBitValue(U32 bit,U32 srcIP,U32 dstIP,U16 srcPort,U16 dstPort,U8 proto);
static U32 LookupBlock(U32 *rule_list,U16 num_rule,pFiltSet pfiltset,U32 srcIP,U32 dstIP,U16 srcPort,U16 dstPort,U8 proto);
static void InitBitstring(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring);
static void GetSimilarMatrix(U32 num_rule);
static float GetSimilarValue(U32 *rlist1,U32 len1,U32 *rlist2,U32 len2,U32 max_rules);
static void InitHashTable();
static U16 CountOneNum(U16 v);
static void SortNumArray(U32 *array,U32 len);
static void CpyNumArray(U32 *array_src,U32 *array_dst,U32 num);
static int FindID(U32 id,U32 *bitstring,U32 len_bitstring);
static int BuildBitstring0(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock);
static int BuildBitstring1(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock);
static int BuildBitstring2(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock);
static int BuildBitstring3(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock);
static U32 GetMaxBlockSize(PBLOCK pblock,U32 num_block);
static void InsertRule(PRuleSeg pRuleSegHdr,pFilter pfilter,U16 dim);
static U64 GetSubSpaceNum(pFiltSet pfiltset);
static U64 GetMaxSubSpaceNum(PBLOCK pblock,U32 num_block,pFiltSet pfiltset);
static U64 SplitSpace(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock);

//API to ClassBenchv2
void DDBSInit(pFiltSet pfiltset)
{
#if _DEBUG_
    printf("[DDBSInit] Start\n");
#endif
    srand((U32)time(0));
    U32 i=0,j=0,len_bitstring=LEN_BITSTRING,result,max=0;
    U32 *bitstring=(U32*)malloc(sizeof(U32)*len_bitstring);
    U32 *bitstring_bak=(U32*)malloc(sizeof(U32)*len_bitstring);
    /*init the info_stat, check each bit position and store information*/
    info_stat = (PINFO_STAT)malloc(sizeof(INFO_STAT)*NUM_BIT_HDR);
    for (i=0;i<NUM_BIT_HDR;i++){
        info_stat[i].id=i;
        info_stat[i].num_rule_0=0; //number of rules that meet 0 at this bit
        info_stat[i].num_rule_1=0; //number of rules that meet 1 at this bit
        info_stat[i].num_rule_x=0; //number of rules that meet * at this bit
        info_stat[i].rule_list0=(U32*)malloc(sizeof(U32)*pfiltset->numFilters);
        info_stat[i].rule_list1=(U32*)malloc(sizeof(U32)*pfiltset->numFilters);
    }
    /*init the pblock[]*/
    pblock = (PBLOCK)malloc(sizeof(BLOCK)*(1<<len_bitstring));
    for (i=0;i<(1<<len_bitstring);i++){
        pblock[i].num_rule=0;
        pblock[i].num_subspace=0;
        pblock[i].rule_list=NULL;
    }
    /*init the hash table*/
    InitHashTable();
    /*analysis the global ruleset and stat info*/
    CountStat(pfiltset);
    //PrintBitCount();//print out the bit stat info

    /*calculate the bitstring value*/
#if METHOD_BS_BUILD==0 //split with a given bitstring value
    InitBitstring(pfiltset,bitstring,len_bitstring); //set up the init value
    BuildBitstring0(pfiltset,bitstring,len_bitstring,pblock);
#elif METHOD_BS_BUILD==1 //choose the greedy scheme to incrementally build bitstring 
    BuildBitstring1(pfiltset,bitstring,len_bitstring,pblock);
#elif METHOD_BS_BUILD==2 //choose the Heuristic Switch scheme to improve given bitstring
    InitBitstring(pfiltset,bitstring,len_bitstring); //set up the init value
    BuildBitstring2(pfiltset,bitstring,len_bitstring,pblock);
#elif METHOD_BS_BUILD==3 //choose the minimize subspace num scheme
    BuildBitstring3(pfiltset,bitstring,len_bitstring,pblock);
    SplitSpace(pfiltset,bitstring,len_bitstring,pblock);
#endif
    //FILE *fp=fopen(fp_result,"a+");
    FILE *fp=NULL; //do not collect result
    printf("bitstring[%u]: ",len_bitstring);
    if (fp!=NULL) {
        fprintf(fp,"bitstring[%u]: ",len_bitstring);
    }
    for (i=0;i<len_bitstring;i++){
        printf("%u,",bitstring[i]);
        if (fp!=NULL) {
            fprintf(fp,"%u ",bitstring[i]);
        }
    }
    printf("\n");
    /*split the global ruleset with the result bitstring*/
    max=PrintBlockStat(len_bitstring,pfiltset,fp);
    if (fp!=NULL) {
        fclose(fp);
    }
#if _VALIDATE_
    LookupTest(pfiltset,bitstring,len_bitstring);
#endif
#if _DEBUG_
    printf("[DDBSInit] End\n");
#endif
}

/*Only test DBS/DDBS on hardware platform, as software needs more with bitmasking*/
int DDBSSearch(U32 dest, U32 source, U32 sp, U32 dp, unsigned char pr)
{
    return 0;
#ifdef LITTLE_ENDIAN //x86
    U32 destIP=dest;
    U32 srcIP=source;
#else
    U32 destIP=LBConvL(dest);
    U32 srcIP=LBConvL(source);
#endif
    U16 proto = (U16)pr;
}

/**
 * do a validation with pkt at the rule's border point.
 * \param pfiltset the ruleset to test
 * \param bitstring bitstring used
 * \param len_bitstring length of the bitstring
 */
static void LookupTest(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring)
{
    U32 i=0,j=0,srcIP,dstIP=0;
    U16 srcPort=0,dstPort=0;
    U8 proto=0;
    U32 bit=0,index_value=0,bit_value=0,rule_id=0;
    pFilter pfilter = NULL,pfilter_get=NULL;
    for (i=0;i<pfiltset->numFilters;i++) { //for each rule
        index_value=0;
        pfilter=&pfiltset->filtArr[i];
        srcIP=pfilter->ipHEX[0];
        dstIP=pfilter->ipHEX[1];
        srcPort=pfilter->fromPort[0];
        dstPort=pfilter->fromPort[1];
        proto=pfilter->protPref;
        //printf("pkt:%x,%x,%hu,%hu,%u\n",srcIP,dstIP,srcPort,dstPort,proto);

        for (j=0;j<len_bitstring;j++) { //for each bit
            bit = bitstring[j];
            bit_value = GetBitValue(bit,srcIP,dstIP,srcPort,dstPort,proto);
            //printf("bit=%u,value=%u\n",bit,bit_value);
            index_value +=(bit_value<<(len_bitstring-1-j));
        }
        //printf("pkt#%u:%x,%x,%hu,%hu,%u\n",i,srcIP,dstIP,srcPort,dstPort,proto);
        rule_id= LookupBlock(pblock[index_value].rule_list,pblock[index_value].num_rule,pfiltset,srcIP,dstIP,srcPort,dstPort,proto);
        if (rule_id+1>pfilter->cost) { //check p[index]
            pfilter_get=&pfiltset->filtArr[rule_id];
            printf("pkt#%u[%x %x %u %u %u]:index=%u,match=#%u[%x/%u %x/%u %u:%u %u:%u %u/%u], right=#%u[%x/%u %x/%u %u:%u %u:%u %u/%u]\n",i,srcIP,dstIP,srcPort,dstPort,proto,index_value,rule_id,pfilter_get->ipHEX[0],pfilter_get->len[0],pfilter_get->ipHEX[1],pfilter_get->len[1],pfilter_get->fromPort[0],pfilter_get->toPort[0],pfilter_get->fromPort[1],pfilter_get->toPort[1],pfilter_get->protPref,pfilter_get->protLen,pfilter->cost-1,pfilter->ipHEX[0],pfilter->len[0],pfilter->ipHEX[1],pfilter->len[1],pfilter->fromPort[0],pfilter->toPort[1],pfilter->fromPort[1],pfilter->toPort[1],pfilter->protPref,pfilter->protLen);
        }
    }
}

/**
 * find a matched rule in the block
 * \param rule_list rule list in the block
 * \param num_rule the number of rules in the list
 * \param pfiltset global ruleset
 * \return matched rule id,-1 if not found
 */
static U32 LookupBlock(U32 *rule_list,U16 num_rule,pFiltSet pfiltset,U32 srcIP,U32 dstIP,U16 srcPort,U16 dstPort,U8 proto)
{
    U16 i=0,id=0,rule_id=pfiltset->numFilters;
    U32 srcIP_0=0,dstIP_0=0;
    U16 srcPort_0=0,dstPort_0=0;
    U8 proto_0=0;
    for (i=0;i<num_rule;i++) {
        id=rule_list[i];
        srcIP_0 = pfiltset->filtArr[id].ipHEX[0];
        dstIP_0 = pfiltset->filtArr[id].ipHEX[1];
        srcPort_0 = pfiltset->filtArr[id].fromPort[0];
        dstPort_0 = pfiltset->filtArr[id].fromPort[1];
        proto_0 = pfiltset->filtArr[id].protPref;
        if (
                (srcIP==srcIP_0)
                &&(dstIP==dstIP_0)
                &&(srcPort==srcPort_0)
                &&(dstPort==dstPort_0)
                &&(proto==proto_0)
           ) { //if match
            return id;
        }
    }
    /*not found, then print all rules in block*/
    printf("num_rule=%u\n",num_rule);
    for (i=0;i<num_rule;i++) {
        id=rule_list[i];
        srcIP_0 = pfiltset->filtArr[id].ipHEX[0];
        dstIP_0 = pfiltset->filtArr[id].ipHEX[1];
        srcPort_0 = pfiltset->filtArr[id].fromPort[0];
        dstPort_0 = pfiltset->filtArr[id].fromPort[1];
        proto_0 = pfiltset->filtArr[id].protPref;
        printf("rule#%u:%x,%x,%hu,%hu,%u\n",id,srcIP_0,dstIP_0,srcPort_0,dstPort_0,proto_0);
    }
    return -1;
}

/**
 * get one bit value from pkt header, this could be implemented in hardware
 * \param bit the bit to filter out
 * \param srcIP pkt header data
 * \return value of the bit
 */
static U32 GetBitValue(U32 bit,U32 srcIP,U32 dstIP,U16 srcPort,U16 dstPort,U8 proto)
{
    if(bit<32) { //srcIP
        //printf("bit=%u,srcIP=%x\n",bit,srcIP);;
        if((srcIP&(1<<(31-bit)))==0) {
            return 0;
        } else {
            return 1;
        }
        //return (srcIP &&(1<<(31-bit)))>>(31-bit);
    } else if (32<=bit && bit<64) { //dstIP
        if((dstIP&(1<<(63-bit)))==0)
            return 0;
        else return 1;
        //return (dstIP &&(1<<(63-bit)))>>(63-bit);
    } else if (64<=bit && bit<80) { //srcPort
        if((srcPort&(1<<(79-bit)))==0)
            return 0;
        else return 1;
    } else if (80<=bit && bit<96) { //dstPort
        if((dstPort&(1<<(95-bit)))==0)
            return 0;
        else return 1;
    } else if (96<=bit && bit<NUM_BIT_HDR){ //proto
        if((proto&(1<<(103-bit)))==0)
            return 0;
        else return 1;
        //return (proto &&(1<<(103-bit)))>>(103-bit);
    }
    return -1;
}

/**
 * split the ruleset into blocks with given bitstring.
 * \param pfiltset the global ruleset
 * \param bitstring the bitstring given
 * \param len_bitstring length of the bitstring
 * \param pblock the blocks to store rule ids
 * \return size of largest block after spliting
 */
static U32 SplitRuleSet(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock)
{
    U32 i=0;
    for (i=0;i<(1<<len_bitstring);i++){
        pblock[i].num_rule=0;
        if (pblock[i].rule_list!=NULL) {
            free(pblock[i].rule_list);
            pblock[i].rule_list=NULL;
        }
        if (len_bitstring>13) {//we think 13 bits can split into lessthan-MAX_BLOCK_SIZE subsets
            pblock[i].rule_list=(U32*)malloc(sizeof(U32)*MAX_BLOCK_SIZE);
        } else {
            pblock[i].rule_list=(U32*)malloc(sizeof(U32)*pfiltset->numFilters);
        }
    }
    for (i=0;i<pfiltset->numFilters;i++){
        SplitFilter(pfiltset->filtArr+i,bitstring,len_bitstring,pblock);
    }
    return GetMaxBlockSize(pblock,1<<len_bitstring);
}

/**
 * split one filter into matched blocks with given bitstring.
 * \param pfilter the filter to test
 * \param bitstring given bitstring
 * \param len_bitstring length of the bitstring
 * \param pblock the blocks to store rule ids
 */
static void SplitFilter(pFilter pfilter,U32 *bitstring,U32 len_bitstring,PBLOCK pblock)
{
    U32 i=0,index=0,index_in=0,bit=0;
    U32 mask_index=0,mask_rule=0,port_xor=0;
	unsigned char  len[2]; // 1 + 1 bytes
	unsigned int ipHEX[2];
	unsigned int fromPort[2]; // 2 + 2 bytes, start of src&dst ports
	unsigned int toPort[2]; // 2 + 2 bytes, end of...
	unsigned int cost; // 4 bytes
	unsigned char  protPref; // 1 byte
	unsigned char  protLen; //actually the mask
    len[0]=pfilter->len[0];
    len[1]=pfilter->len[1];
    ipHEX[0]=pfilter->ipHEX[0];
    ipHEX[1]=pfilter->ipHEX[1];
    fromPort[0]=pfilter->fromPort[0];
    fromPort[1]=pfilter->fromPort[1];
    toPort[0]=pfilter->toPort[0];
    toPort[1]=pfilter->toPort[1];
    cost=pfilter->cost;
    protPref=pfilter->protPref;
    protLen=pfilter->protLen;

    for(index=0;index<(1<<len_bitstring);index++) { //check each cell if covered by this rule
        index_in = 1;
        for(i=0;i<len_bitstring;i++) { //check each bit of the index
            mask_index=1<<(len_bitstring-1-i);
            bit=bitstring[i]; //a bit from selected bits
            if (bit==-1) //ignore this bit:???
                continue;
            if(0<=bit && bit<31){ //src addr
                mask_rule=1<<(31-bit); //mask out the bit
                if (bit+1<=len[0]) {//pref check
                    if (((index&mask_index)>>(len_bitstring-1-i))!=((ipHEX[0]&mask_rule)>>(31-bit))) { //not match
                        index_in=0;
                        break;
                    }
                }
            } else if (32<=bit && bit<64) { //dst addr
                mask_rule=1<<(63-bit); //mask out the bit
                if (bit+1-32<=len[1]) {//pref check
                    if (((index&mask_index)>>(len_bitstring-1-i))!=((ipHEX[1]&mask_rule)>>(63-bit))) { //not match
                        index_in=0;
                        break;
                    }
                }
            } else if (64<=bit && bit<80) { //src port
                mask_rule=1<<(79-bit); //mask out the bit
                if (mask_rule>toPort[0]-fromPort[0]) { //may not cover
                    port_xor=fromPort[0]^toPort[0];
                    if ((port_xor&mask_rule)==0) { //that bit not change
                        if(((index&mask_index)>>(len_bitstring-1-i))!=((fromPort[0]&mask_rule)>>(79-bit))) {
                            index_in=0;
                            break;
                        }
                    }
                }
            } else if (80<=bit && bit<96) { //dst port
                mask_rule=1<<(95-bit); //mask out the bit
                if (mask_rule>toPort[1]-fromPort[1]) { //may not cover
                    port_xor=fromPort[1]^toPort[1];
                    if ((port_xor&mask_rule)==0) { //that bit not change
                        if(((index&mask_index)>>(len_bitstring-1-i))!=((fromPort[1]&mask_rule)>>(95-bit))) {
                            index_in=0;
                            break;
                        }
                    }
                }
            } else if (96<=bit && bit<NUM_BIT_HDR) { //proto
                if (protLen!=0x00) {
                    mask_rule=1<<(103-bit); //mask out the bit
                    if (((index&mask_index)>>(len_bitstring-1-i))!=((protPref&mask_rule)>>(103-bit))) { //not match
                        index_in=0;
                        break;
                    }
                } 
            }
        } //end for bitstring
        if (index_in==1){ //if this rule is in
            /*if (pblock[index].num_rule>=MAX_BLOCK_SIZE) {
              printf("block overflow,max block size=%u while ruleNum=%u.\n",MAX_BLOCK_SIZE,pblock[index].num_rule);
              return;
              }*/
            pblock[index].rule_list[pblock[index].num_rule++]=cost-1; //store the id of rule
        }
    }
}
/**
 * count the stat info of ruleset.
 * \param pfiltset the ruleset
 * \return 0 if success
 */
static int CountStat(pFiltSet pfiltset)
{
    U32 i=0;
    for (i=0;i<pfiltset->numFilters;i++){
        CountFilter(pfiltset->filtArr+i);
    }
    return 0;
}

/**
 * count the stat info of a filter, rules cover each bit if 0 or 1
 * \param pfilter the filter to check
 * \return 0 if success
 */
static int CountFilter(pFilter pfilter)
{
    U32 i=0,j=0,mask=1,port_xor=0;
    //check src field
    for (i=0;i<32;i++) {
        if (i<pfilter->len[0]) { //the prefix length
            mask=1<<(31-i);
            if ((pfilter->ipHEX[0]&mask)==0) { //this bit is 0
                info_stat[i].rule_list0[info_stat[i].num_rule_0]=pfilter->cost-1; //store the id of rule
                info_stat[i].num_rule_0++;
            } else {
                info_stat[i].rule_list1[info_stat[i].num_rule_1]=pfilter->cost-1; //store the id of rule
                info_stat[i].num_rule_1++;
            }
        } else { //the star length
            info_stat[i].rule_list0[info_stat[i].num_rule_0]=pfilter->cost-1; //store the id of rule
            info_stat[i].rule_list1[info_stat[i].num_rule_1]=pfilter->cost-1; //store the id of rule
            info_stat[i].num_rule_0++;
            info_stat[i].num_rule_1++;
            info_stat[i].num_rule_x++;
        }
    }

    //check dst
    for (i=0;i<32;i++){
        if (i<pfilter->len[1]){ //the prefix length
            mask=1<<(31-i);
            if((pfilter->ipHEX[1]&mask)==0){ //this bit is 0
                info_stat[32+i].rule_list0[info_stat[32+i].num_rule_0]=pfilter->cost-1; //store the id of rule
                info_stat[32+i].num_rule_0++;
            } else {
                info_stat[32+i].rule_list1[info_stat[32+i].num_rule_1]=pfilter->cost-1; //store the id of rule
                info_stat[32+i].num_rule_1++;
            }
        } else { //the star length
            info_stat[32+i].rule_list0[info_stat[32+i].num_rule_0]=pfilter->cost-1; //store the id of rule
            info_stat[32+i].rule_list1[info_stat[32+i].num_rule_1]=pfilter->cost-1; //store the id of rule
            info_stat[32+i].num_rule_0++;
            info_stat[32+i].num_rule_1++;
            info_stat[32+i].num_rule_x++;
        }
    }

    //check sport
    port_xor=pfilter->fromPort[0]^pfilter->toPort[0];
    for (i=0;i<16;i++) {
        mask=1<<(15-i);
        if ((port_xor&mask)!=0) { //changes: means cover
            for (j=i;j<16;j++) {
                info_stat[64+i].rule_list0[info_stat[64+i].num_rule_0]=pfilter->cost-1; //store the id of rule
                info_stat[64+i].rule_list1[info_stat[64+i].num_rule_1]=pfilter->cost-1; //store the id of rule
                info_stat[64+j].num_rule_0++;
                info_stat[64+j].num_rule_1++;
                info_stat[64+j].num_rule_x++;
            }
            break;
        } else { //no change, mean not cover
            if((pfilter->fromPort[0]&mask)==0){ //this bit is 0
                info_stat[64+i].rule_list0[info_stat[64+i].num_rule_0]=pfilter->cost-1; //store the id of rule
                info_stat[64+i].num_rule_0++;
            } else {
                info_stat[64+i].rule_list1[info_stat[64+i].num_rule_1]=pfilter->cost-1; //store the id of rule
                info_stat[64+i].num_rule_1++;
            }
        }
    }

    //check dport
    port_xor=pfilter->fromPort[1]^pfilter->toPort[1];
    for (i=0;i<16;i++) {
        mask=1<<(15-i);
        if ((port_xor&mask)!=0) { //changes: means cover
            for (j=i;j<16;j++) {
                info_stat[80+i].rule_list0[info_stat[80+i].num_rule_0]=pfilter->cost-1; //store the id of rule
                info_stat[80+i].rule_list1[info_stat[80+i].num_rule_1]=pfilter->cost-1; //store the id of rule
                info_stat[80+j].num_rule_0++;
                info_stat[80+j].num_rule_1++;
                info_stat[80+j].num_rule_x++;
            }
            break;
        } else { //no change, mean not cover
            if((pfilter->fromPort[1]&mask)==0){ //this bit is 0
                info_stat[80+i].rule_list0[info_stat[80+i].num_rule_0]=pfilter->cost-1; //store the id of rule
                info_stat[80+i].num_rule_0++;
            } else {
                info_stat[80+i].rule_list1[info_stat[80+i].num_rule_1]=pfilter->cost-1; //store the id of rule
                info_stat[80+i].num_rule_1++;
            }
        }
    }

    //check proto
    if (pfilter->protLen==0xff) {
        for (i=0;i<8;i++) {
            mask=1<<(7-i);
            if ((pfilter->protPref&mask)==0) { //this bit is 0
                info_stat[96+i].rule_list0[info_stat[96+i].num_rule_0]=pfilter->cost-1; //store the id of rule
                info_stat[96+i].num_rule_0++;
            } else {
                info_stat[96+i].rule_list1[info_stat[96+i].num_rule_1]=pfilter->cost-1; //store the id of rule
                info_stat[96+i].num_rule_1++;
            }
        }
    } else if (pfilter->protLen==0x00) {
        for (i=0;i<8;i++) {
            info_stat[96+i].rule_list0[info_stat[96+i].num_rule_0]=pfilter->cost-1; //store the id of rule
            info_stat[96+i].rule_list1[info_stat[96+i].num_rule_1]=pfilter->cost-1; //store the id of rule
            info_stat[96+i].num_rule_0++;
            info_stat[96+i].num_rule_1++;
            info_stat[96+i].num_rule_x++;
        }
    } else {
        printf("Error? protLen=0x%x\n",pfilter->protLen);
    }
    return 0;
}

static void PrintBitCount()
{
    U32 i=0;
    FILE *fp=fopen("bit_statistic.txt","w");
    printf("id\t0\t1\tx\n");
    for (i=0;i<NUM_BIT_HDR;i++) {
        printf("%u\t%u\t%u\t%u\n",i,info_stat[i].num_rule_0,info_stat[i].num_rule_1,info_stat[i].num_rule_x);
        fprintf(fp,"%u\t%u\t%u\t%u\n",i,info_stat[i].num_rule_0,info_stat[i].num_rule_1,info_stat[i].num_rule_x);
    }
    fclose(fp);
    return;
}

/**
 * get the max pblock's size: number of rules in it.
 * \param pblock the block to check
 * \param num_block number of blocks
 * \return the max pblock's size
 */
static U32 GetMaxBlockSize(PBLOCK pblock,U32 num_block)
{
    U32 i=0,max=0;
    for (i=0;i<num_block;i++){
        if (max < pblock[i].num_rule){
            max = pblock[i].num_rule;
        }
    }
    return max;
    //printf("block[%u] %u\n",i,pblock[i].num_rule);
}

void CpySubSet(pFiltSet psubfiltset,pFiltSet pfiltset,PBLOCK pblock)
{
    U32 i=0;
    psubfiltset->numFilters=pblock->num_rule;
    for (i=0;i<psubfiltset->numFilters;i++) {
        psubfiltset->filtArr[i].cost=pfiltset->filtArr[pblock->rule_list[i]].cost;
        psubfiltset->filtArr[i].pref[0][0]=pfiltset->filtArr[pblock->rule_list[i]].pref[0][0];
        psubfiltset->filtArr[i].pref[0][1]=pfiltset->filtArr[pblock->rule_list[i]].pref[0][1];
        psubfiltset->filtArr[i].pref[0][2]=pfiltset->filtArr[pblock->rule_list[i]].pref[0][2];
        psubfiltset->filtArr[i].pref[0][3]=pfiltset->filtArr[pblock->rule_list[i]].pref[0][3];
        psubfiltset->filtArr[i].pref[1][0]=pfiltset->filtArr[pblock->rule_list[i]].pref[1][0];
        psubfiltset->filtArr[i].pref[1][1]=pfiltset->filtArr[pblock->rule_list[i]].pref[1][1];
        psubfiltset->filtArr[i].pref[1][2]=pfiltset->filtArr[pblock->rule_list[i]].pref[1][2];
        psubfiltset->filtArr[i].pref[1][3]=pfiltset->filtArr[pblock->rule_list[i]].pref[1][3];
        psubfiltset->filtArr[i].ipHEX[0]=pfiltset->filtArr[pblock->rule_list[i]].ipHEX[0];
        psubfiltset->filtArr[i].ipHEX[1]=pfiltset->filtArr[pblock->rule_list[i]].ipHEX[1];
        psubfiltset->filtArr[i].len[0]=pfiltset->filtArr[pblock->rule_list[i]].len[0];
        psubfiltset->filtArr[i].len[1]=pfiltset->filtArr[pblock->rule_list[i]].len[1];
        psubfiltset->filtArr[i].fromPort[0]=pfiltset->filtArr[pblock->rule_list[i]].fromPort[0];
        psubfiltset->filtArr[i].fromPort[1]=pfiltset->filtArr[pblock->rule_list[i]].fromPort[1];
        psubfiltset->filtArr[i].toPort[0]=pfiltset->filtArr[pblock->rule_list[i]].toPort[0];
        psubfiltset->filtArr[i].toPort[1]=pfiltset->filtArr[pblock->rule_list[i]].toPort[1];
        psubfiltset->filtArr[i].protPref=pfiltset->filtArr[pblock->rule_list[i]].protPref;
        psubfiltset->filtArr[i].protLen=pfiltset->filtArr[pblock->rule_list[i]].protLen;
        psubfiltset->filtArr[i].cost=pfiltset->filtArr[pblock->rule_list[i]].cost;
    }
}

/**
 * get the max pblock's size: number of rules in it.
 * \param pblock the block to check
 * \param num_block number of blocks
 * \return the max pblock's size
 */
static U64 GetMaxSubSpaceNum(PBLOCK pblock,U32 num_block,pFiltSet pfiltset)
{
    pFiltSet psubfiltset = (pFiltSet)malloc(sizeof(struct FILTSET));
    U32 i=0;
    U64 num_subspace=0,max_subspace=0;
    for (i=0;i<num_block;i++){
        CpySubSet(psubfiltset,pfiltset,&pblock[i]);
        pblock[i].num_subspace = GetSubSpaceNum(psubfiltset);
        //printf("num_rule=%u, num_subspace=%llu\n",pblock[i].num_rule,pblock[i].num_subspace);
        if (max_subspace < pblock[i].num_subspace) {
            max_subspace = pblock[i].num_subspace;
        }
    }
    free(psubfiltset);
    //printf("max_subspace=%llu\n",max_subspace);
    return max_subspace;
    //printf("block[%u] %u\n",i,pblock[i].num_rule);
}


/**
 * print out the status of each rule block.
 * \param len_bitstring the length of bitstring
 * \param pfiltset the rule set
 */
static U16 PrintBlockStat(U32 len_bitstring,pFiltSet pfiltset, FILE* fp)
{
    U32 i=0,index_max=0;
    U16 min=0xffff,max=0;
    U32 sum=0;
    float avg=0.0;
    for (i=0;i<(1<<len_bitstring);i++){
        //printf("%u ",pblock[i].num_rule);
        if (min>=pblock[i].num_rule){
            min = pblock[i].num_rule;
        }
        if (max<=pblock[i].num_rule){
            max = pblock[i].num_rule;
            index_max=i;
        }
        sum += pblock[i].num_rule;
        //printf("block[%u] %u\n",i,pblock[i].num_rule);
    }
    avg =(float) sum/(1<<len_bitstring);
    U32 id,srcIP,src_mask,dstIP,dst_mask,srcPort_0,srcPort_1,dstPort_0,dstPort_1,proto,proto_mask;
    //printf("the max block is %u.\n",index_max);
    printf("%u blocks,min=%u,max=%u,avg=%f,sum=%u,SBlock_mem=%u KB\n",1<<len_bitstring,min,max,avg,sum,(sum*sizeof(U32))>>10);
    if (fp!=NULL) {
        fprintf(fp," stat: %u %u %f %u\n",min,max,avg,sum);
    }
    return max;
}

/**
 * Init a bitstring.
 * @param pfiltset the ruleset.
 * @param bitstring bit to initialize.
 * @param len_bitstring the length of the bitstring.
 */
static void InitBitstring(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring)
{
#if _DEBUG_
    printf("[InitBitstring] Start\n");
#endif
    U32 bitPool[]={1,2,6,41,43,44,48,90,103,105,33,33,41,42,43,44,49,53};//24
    U32 i=0, j=0;
    U32 max_g100,max=0;
    U32 i_g=0,j_g=0;
    //#define ACL_OP
#if METHOD_BS_INIT==0 //method 0 means set value manually
#if _DEBUG_
    printf("InitBitstring Manually with: ");
    for (i=0;i<len_bitstring;i++) {
        printf("%u ",bitPool[i]);
    }
    printf("\n");
#endif
    CpyNumArray(bitPool,bitstring,len_bitstring);
#elif METHOD_BS_INIT==1 //method 1 means randomly generating
#if _DEBUG_
    printf("InitBitstring Manually with randomly generating.\n");
#endif
    for (i=0;i<len_bitstring;i++) {
        do {
            bitstring[i] = rand()%NUM_BIT_HDR;
        }while(FindID(bitstring[i],bitstring,i)==1);
    }
    /*
#elif METHOD_BS_INIT==2 //method 2 means use greedy build to init
    fprintf(fp,"Init Method 2:greedy.\n");
    BuildBitstring1(pfiltset,bitstring,len_bitstring,pblock);
    */
#endif
    SortNumArray(bitstring,len_bitstring);
#if _DEBUG_
    printf("[InitBitstring] End\n");
#endif
}

/**
 * get the similar matrix with given rules.
 * \param num_rule rule number
 */
static void getsimilarmatrix(U32 num_rule)
{
    U32 i=0,j=0;
    float similar_value1=0.0,similar_value2=0.0;
    for (i=0;i<103;i++){
        for (j=i+1;j<NUM_BIT_HDR;j++){
            similar_value1=GetSimilarValue(info_stat[i].rule_list0,info_stat[i].num_rule_0,info_stat[j].rule_list0,info_stat[j].num_rule_0,num_rule);
            similar_value2=GetSimilarValue(info_stat[i].rule_list0,info_stat[i].num_rule_0,info_stat[j].rule_list1,info_stat[j].num_rule_1,num_rule);
            if (similar_value1>similar_value2) { //get the max similar_value
                similar_matrix[i][j]=similar_value1;
                similar_matrix[j][i]=similar_value1;
            } else {
                similar_matrix[i][j]=similar_value2;
                similar_matrix[j][i]=similar_value2;
            }
        }
    }
#if 0
    FILE *fp=fopen("similar_matrix.txt","w");
    float similar_value = 0.0;
    float max_value=0.0,min_value=0.0;
    U32 max_id,min_id;
    for (i=0;i<NUM_BIT_HDR;i++){
        for (j=0;j<NUM_BIT_HDR;j++){
            similar_value = similar_matrix[i][j];
            /*if (max<similar_value) {
              max_value = similar_value;
              max_id = j;
              }
              if (min<similar_value) {
              max_value = similar_value;
              max_id = j;
              }
              */
            //fprintf(fp,"%f\t",similar_value);
        }
        //fprintf(fp,"\n");
    }
    fclose(fp);
#endif
}

/**
 * get the similar value between two rulelist.
 * \param rlist1 rule list 1
 * \param len1 the length of rule list 1
 * \param rlist2 rule list 2
 * \param len1 the length of rule list 2
 * \param max_rules the size of global ruleset
 * \return the similar value
 */
static float GetSimilarValue(U32 *rlist1,U32 len1,U32 *rlist2,U32 len2,U32 max_rules)
{
    U32 longer_len=0;
    if (len1>len2) {
        longer_len = len1;
    } else {
        longer_len = len2;
    }
    U16 num_map=max_rules>>5; //32 bit each
    if (max_rules%32!=0) {
        num_map++;
    }
    U32 *map1=(U32*)malloc(sizeof(U32)*num_map);
    memset(map1,0,sizeof(U32)*num_map);
    U32 *map2=(U32*)malloc(sizeof(U32)*num_map);
    memset(map2,0,sizeof(U32)*num_map);
    U32 i=0,j=0,id_rule=0,id_map=0,id_bit=0;
    for (i=0;i<len1;i++) { //set each rule
        id_rule = rlist1[i];
        id_map=id_rule>>5; //32 bit each
        id_bit = id_rule - id_map<<5;
        map1[id_map] |= (1<<(31-id_bit));
    }
    for (i=0;i<len2;i++) { //set each rule
        id_rule = rlist2[i];
        id_map=id_rule>>5; //32 bit each
        id_bit = id_rule - id_map<<5;
        map2[id_map] |= (1<<(31-id_bit));
    }

    U32 num_similar=0,a=0;
    U8 a1,a2,a3,a4;
    for (i=0;i<num_map;i++) { //check each map
        a = map1[i]&map2[i];
        a1=(a&0xff000000)>>24;
        a2=(a&0x00ff0000)>>16;
        a3=(a&0x0000ff00)>>8;
        a4=(a&0x000000ff);
        num_similar += h_table[a1];
        num_similar += h_table[a2];
        num_similar += h_table[a3];
        num_similar += h_table[a4];
    }

    free(map1);
    free(map2);
    float result= (float)num_similar/longer_len;
    //printf("similar_value=%u\n",num_similar);
    return result;
}

/**
 * init the hash table.
 */
static void InitHashTable()
{
    U16 i=0;
    for (i=0;i<256;i++) {
        h_table[i]=CountOneNum(i);
    }
}

/**
 * count the 1 number in the given binary string v.
 * \param v the number to count
 * \return 1 number
 */
static U16 CountOneNum(U16 v)
{
    U16 num=0;
    while(v){
        num += v &0x01;
        v >>= 1;
    }
    return num;
}

/**
 * Build the bitstring with the given one
 * \param pfiltset global ruleset
 * \param bitstring the bitstring basicly
 * \param len_bitstring the length of bitstring
 * \param pblock the final blocks to store rules
 * \return 1 if find a better one with the scheme, else 0
 */
static int BuildBitstring0(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock)
{
#if _DEBUG_
    printf("BuildBitstring0 starting...\n");
#endif
#if _DEBUG_DETAIL_
    FILE *fp=fopen(fp_history,"a+");
    if (fp!=NULL) {
        fprintf(fp,"Choose building method 0: mannually.\n");
    }
#endif
    U32 i,j,k,max_old=pfiltset->numFilters,max_curr=0,bit_best=0;
    U32 bitstring_tmp[len_bitstring];
    U32 bitstring_tmp2[len_bitstring];
    PBLOCK pblock_tmp=NULL;
#if 0
    for (i=0;i<len_bitstring;i++) { //try to get each best bit value
        pblock_tmp = (PBLOCK)malloc(sizeof(BLOCK)*(1<<(i+1)));
        memset(pblock_tmp,0,sizeof(BLOCK)*(1<<(i+1)));
        bit_best = -1;
#if _DEBUG_
        printf("i=%u,bitstring_tmp=%u %u %u\n",i,bitstring_tmp[0],bitstring_tmp[1],bitstring_tmp[2]);
#endif
        for (j=0;j<NUM_BIT_HDR;j++) { //try each bit in pkt header
            if (FindID(j,bitstring_tmp,i)==0) { //not use yet
                bitstring_tmp[i]=j;
                CpyNumArray(bitstring_tmp,bitstring_tmp2,i+1);
                SortNumArray(bitstring_tmp2,i+1);
                //printf("try take bit %u,after sort,bitstring_tmp=%u %u %u\n",j,bitstring_tmp[0],bitstring_tmp[1],bitstring_tmp[2]);
                max_curr=SplitRuleSet(pfiltset,bitstring_tmp2,i+1,pblock_tmp);
#if _DEBUG_DETAIL_
                printf("i=%u,test bit %u,max_old=%u,max_curr=%u\n",i,j,max_old,max_curr);
#endif
                if (max_old > max_curr) { //find a better one
                    max_old = max_curr;
                    bit_best = j;
#if _DEBUG_DETAIL_
                    printf("get a bit_best %u,max=%u\n",bit_best,max_old);
#endif
                }
            }
        }
        free(pblock_tmp);
        if (bit_best==-1) { //bit pos i does not work
            printf("Error, cannot continue spliting, i=%u\n",i);
            printf("current bitstring:");
            for (k=0;k<i+1;k++) {
                printf("%u ",bitstring_tmp[k]);
            }
            printf("\n");
        } else {
            bitstring_tmp[i]=bit_best;
#if _DEBUG_DETAIL_
            printf("add bit %u\n",bit_best);
            printf("max=%u\n",max_old);
#endif
            fprintf(fp,"i=%u:get bit %u\n",i,bit_best);
        }
#if _DEBUG_DETAIL_
        printf("current bitstring:");
        fprintf(fp,"current bitstring:");
        for (k=0;k<i+1;k++) {
            printf("%u ",bitstring_tmp[k]);
            fprintf(fp,"%u ",bitstring_tmp[k]);
        }
        printf("\n");
        fprintf(fp,"\n");
#endif
    }
#endif
//SortNumArray(bitstring_tmp,len_bitstring);
    //max_curr=SplitRuleSet(pfiltset,bitstring_tmp,len_bitstring,pblock); //store rules into pblock
    SortNumArray(bitstring,len_bitstring);
    max_curr=SplitRuleSet(pfiltset,bitstring,len_bitstring,pblock); //store rules into pblock
    //CpyNumArray(bitstring_tmp,bitstring,len_bitstring);
#if _DEBUG_DETAIL_
    printf("final bitstring:");
    fprintf(fp,"Get final bitstring:");
    for (k=0;k<len_bitstring;k++) {
        printf("%u ",bitstring_tmp[k]);
        fprintf(fp,"%u ",bitstring_tmp[k]);
    }
    printf("max=%u\n",max_curr);
    fprintf(fp,"max=%u\n",max_curr);
    fclose(fp);
#endif
#if _DEBUG_
    printf("BuildBitstring0 end.\n");
#endif
    return 1;
}


/**
 * Build the bitstring with greed scheme.
 * \param pfiltset global ruleset
 * \param bitstring the bitstring basicly
 * \param len_bitstring the length of bitstring
 * \param pblock the final blocks to store rules
 * \return 1 if find a better one with the scheme, else 0
 */
static int BuildBitstring1(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock)
{
#if _DEBUG_
    printf("BuildBitstring1 starting...\n");
#endif
    FILE *fp=fopen(fp_history,"a+");
    if (fp!=NULL) {
        fprintf(fp,"Choose BS building method 1.\n");
    }
    U32 i,j,k,max_old=pfiltset->numFilters,max_curr=0,bit_best=0;
    U32 bitstring_tmp[len_bitstring];
    U32 bitstring_tmp2[len_bitstring];
    PBLOCK pblock_tmp=NULL;
    for (i=0;i<len_bitstring;i++) { //try to get each best bit value
        pblock_tmp = (PBLOCK)malloc(sizeof(BLOCK)*(1<<(i+1)));
        memset(pblock_tmp,0,sizeof(BLOCK)*(1<<(i+1)));
        bit_best = -1;
        //printf("i=%u,bitstring_tmp=%u %u %u\n",i,bitstring_tmp[0],bitstring_tmp[1],bitstring_tmp[2]);
        for (j=0;j<NUM_BIT_HDR;j++) { //try each bit in pkt header
            if (FindID(j,bitstring_tmp,i)==0) { //not use yet
                bitstring_tmp[i]=j;
                CpyNumArray(bitstring_tmp,bitstring_tmp2,i+1);
                SortNumArray(bitstring_tmp2,i+1);
                //printf("try take bit %u,after sort,bitstring_tmp=%u %u %u\n",j,bitstring_tmp[0],bitstring_tmp[1],bitstring_tmp[2]);
                max_curr=SplitRuleSet(pfiltset,bitstring_tmp2,i+1,pblock_tmp);
#if _DEBUG_DETAIL_
                printf("i=%u,test bit %u,max_old=%u,max_curr=%u\n",i,j,max_old,max_curr);
#endif
                if (max_old > max_curr) { //find a better one
                    max_old = max_curr;
                    bit_best = j;
#if _DEBUG_DETAIL_
                    printf("get a bit_best %u,max=%u\n",bit_best,max_old);
#endif
                }
            }
        }
        free(pblock_tmp);
        if (bit_best==-1) { //bit pos i does not work
            printf("Error, cannot continue spliting, i=%u\n",i);
            printf("current bitstring:");
            for (k=0;k<i+1;k++) {
                printf("%u ",bitstring_tmp[k]);
            }
            printf("\n");
        } else {
            bitstring_tmp[i]=bit_best;
#if _DEBUG_DETAIL_
            printf("add bit %u\n",bit_best);
            printf("max=%u\n",max_old);
#endif
            fprintf(fp,"i=%u:get bit %u\n",i,bit_best);
        }
#if _DEBUG_DETAIL_
        printf("current bitstring:");
        fprintf(fp,"current bitstring:");
        for (k=0;k<i+1;k++) {
            printf("%u ",bitstring_tmp[k]);
            fprintf(fp,"%u ",bitstring_tmp[k]);
        }
        printf("\n");
        fprintf(fp,"\n");
#endif
    }
    SortNumArray(bitstring_tmp,len_bitstring);
    CpyNumArray(bitstring_tmp,bitstring,len_bitstring);
    max_curr=SplitRuleSet(pfiltset,bitstring,len_bitstring,pblock); //store rules into pblock
#if _DEBUG_DETAIL_
    printf("final bitstring:");
    fprintf(fp,"Get final bitstring:");
    for (k=0;k<len_bitstring;k++) {
        printf("%u ",bitstring_tmp[k]);
        fprintf(fp,"%u ",bitstring_tmp[k]);
    }
    printf("max=%u\n",max_curr);
    fprintf(fp,"max=%u\n",max_curr);
#endif
#if _DEBUG_
    printf("BuildBitstring1 end.\n");
#endif
    fclose(fp);
    return 1;
}

void ResetArray(U32 array[],U32 len, U32 value)
{
    int i=0;
    for (i=0;i<len;i++) {
        array[i]=value;
    }
}

int IsSwapable(U32 array[],U32 len, U32 value)
{
    int i=0;
    for (i=0;i<len;i++) {
        if(array[i]==value) {
            return 1;
        }
    }
    return 0;
}

void PrintArray(U32 array[],U32 len)
{
    int i=0;
    for (i=0;i<len;i++) {
      printf("%u ",array[i]);
    }
}

/**
 * Build the best bitstring with Heuristic Switch scheme:
 * test each bit incrementally and try swaping.
 * \param pfiltset the global ruleset
 * \param bitstring the bitstring basicly
 * \param len_bitstring the length of bitstring
 * \param pblock the blocks to store rule ids
 * \return 1 if find a better one with the scheme, else 0
 */
static int BuildBitstring2(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock)
{
#if _DEBUG_
    printf("[BuildBitstring2] Start\n");
#endif
    FILE *fp=fopen(fp_history,"a+");
    if (fp!=NULL) {
        fprintf(fp,"Choose BS building method 2.\n");
    }
    U32 max_init=0,max_curr=0,i=0,j=0,k=0,bit_next=0,from_bit=0,to_bit=0,to_bit_best=-1,max_old=0,max_new=0;
    U32 bitstring_tmp1[len_bitstring],bitstring_tmp2[len_bitstring];
    CpyNumArray(bitstring,bitstring_tmp1,len_bitstring);

    U32 swapable[len_bitstring]; //mark some bit are OK for swapping
    ResetArray(swapable,len_bitstring,1);

    /*try to swap each bit in bitstring with unchosen ones*/
    //for (i=0;i<len_bitstring;) { //get a bit from bitstring, try replace it
    for (k=0;k<200;k++) {
        if(IsSwapable(swapable,len_bitstring,1)==0) { //no bit is available for swapping
            printf("No bit is available for swapping\n");
            break;
        }
        do {
            i = rand()%len_bitstring;
        } while (swapable[i]==0); //find an available bit
        swapable[i]=0;
        printf("k=%u,i=%u\n",k,i);
        from_bit = bitstring_tmp1[i];
        if (from_bit == to_bit_best) { // consider as just swaping one
            //printf("from_bit=%u,to_bit_best=%u\n",from_bit,to_bit_best);
            i++; //try next i
            continue;
        }
        to_bit_best = -1;
        max_old=SplitRuleSet(pfiltset,bitstring_tmp1,len_bitstring,pblock);//get the init max_block size
        /*try all other bits for replacing,find the best one*/
        for(to_bit=0;to_bit<NUM_BIT_HDR;to_bit++) { 
            if(FindID(to_bit,bitstring_tmp1,len_bitstring)==0) { //to_bit not in bitstring now
                CpyNumArray(bitstring_tmp1,bitstring_tmp2,len_bitstring); //backup tmp1
                bitstring_tmp2[i] = to_bit;
                SortNumArray(bitstring_tmp2,len_bitstring);
                max_new=SplitRuleSet(pfiltset,bitstring_tmp2,len_bitstring,pblock);//get the init max_block size
#if _DEBUG_DETAIL_
                printf("to_bit=%u,max_old=%u,max_new=%u\n",to_bit,max_old,max_new);
#endif
                if (max_old >= max_new) {//find a better one
#if _DEBUG_DETAIL_
                    printf("select this as to_bit_best\n");
#endif
                    to_bit_best = to_bit;
                    max_old = max_new;
                }
            }
        }
        if (to_bit_best!=-1) { //find a better one
#if _DEBUG_
            printf("current bitstring:");
            PrintArray(bitstring_tmp1,len_bitstring);
            printf("\n");
            printf("replace %u with %u: max=%u\n",bitstring_tmp1[i],to_bit_best,max_old);
#endif
#if _DEBUG_DETAIL_
            fprintf(fp,"current bitstring: ");
            for (j=0;j<len_bitstring;j++) {
                fprintf(fp,"%u ",bitstring_tmp1[j]);
            }
            fprintf(fp,"\n");
            fprintf(fp,"replace %u with %u: max=%u\n",bitstring_tmp1[i],to_bit_best,max_old);
#endif
            bitstring_tmp1[i]=to_bit_best;
            SortNumArray(bitstring_tmp1,len_bitstring);
            ResetArray(swapable,len_bitstring,1); //reset all are swapable now
        } else { //not find a better one
            i++;
        }
    }
    CpyNumArray(bitstring_tmp1,bitstring,len_bitstring);
    SortNumArray(bitstring,len_bitstring);
    SplitRuleSet(pfiltset,bitstring,len_bitstring,pblock); //split with the new bitstring
#if _DEBUG_
    printf("[BuildBitstring2] final bitstring:");
    PrintArray(bitstring,len_bitstring);
    printf("max=%u\n",max_old);
#endif
#if _DEBUG_DETAIL_
    fprintf(fp,"final bitstring:");
    for (j=0;j<len_bitstring;j++) {
        fprintf(fp,"%u ",bitstring[j]);
    }
    fprintf(fp,"max=%u\n",max_old);
#endif
#if _DEBUG_
    printf("[BuildBitstring2] End\n");
#endif
    fclose(fp);
    return 1;
}

static U32 GetMaxNumRule(PBLOCK pblock,U32 len_bitstring)
{
    U32 i=0,max=0;
    for (i=0;i<(1<<len_bitstring);i++){
        if (max<pblock[i].num_rule){
            max = pblock[i].num_rule;
        }
    }
    return max;
}

/**
 * Build the bitstring with Minimal subspace scheme.
 * \param pfiltset global ruleset
 * \param bitstring the bitstring basicly
 * \param len_bitstring the length of bitstring
 * \param pblock the final blocks to store rules
 * \return 1 if find a better one with the scheme, else 0
 */
static int BuildBitstring3(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock)
{
#if _DEBUG_
    printf("BuildBitstring3 starting...\n");
#endif
    FILE *fp=fopen(fp_history,"a+");
    if (fp!=NULL) {
        fprintf(fp,"Choose BS building method 3.\n");
    }
    U32 i,j,k,bit_best=0;
    U64 max_old = -1,max_curr=0;
    U32 bitstring_tmp[len_bitstring];
    U32 bitstring_tmp2[len_bitstring];
    PBLOCK pblock_tmp=NULL;
    for (i=0;i<len_bitstring;i++) { //try to get each best bit value incrementally
        pblock_tmp = (PBLOCK)malloc(sizeof(BLOCK)*(1<<(i+1)));
        memset(pblock_tmp,0,sizeof(BLOCK)*(1<<(i+1)));
        bit_best = -1;
        //printf("i=%u,bitstring_tmp=%u %u %u\n",i,bitstring_tmp[0],bitstring_tmp[1],bitstring_tmp[2]);
        for (j=0;j<NUM_BIT_HDR;j++) { //try each bit in pkt header
            if (FindID(j,bitstring_tmp,i)==0) { //j is not used yet
                bitstring_tmp[i]=j;
                CpyNumArray(bitstring_tmp,bitstring_tmp2,i+1);
                SortNumArray(bitstring_tmp2,i+1);
                //printf("try take bit %u,after sort,bitstring_tmp=%u %u %u\n",j,bitstring_tmp[0],bitstring_tmp[1],bitstring_tmp[2]);
                max_curr=SplitSpace(pfiltset,bitstring_tmp2,i+1,pblock_tmp); //split with new bitstring
#if _DEBUG_
                printf("i=%u,test bit %u,max_old=%llu,max_curr=%llu\n",i,j,max_old,max_curr);
#endif
                if (max_old > max_curr) { //find a better one
                    max_old = max_curr;
                    bit_best = j;
#if _DEBUG_
                    printf("get a bit_best %u,max=%u\n",bit_best,max_old);
#endif
                }
            }
        }
        free(pblock_tmp);
        if (bit_best==-1) { //bit pos i does not work
            printf("Error, cannot continue spliting, i=%u\n",i);
            printf("current bitstring:");
            for (k=0;k<i+1;k++) {
                printf("%u ",bitstring_tmp[k]);
            }
            printf("\n");
        } else {
            bitstring_tmp[i]=bit_best;
#if _DEBUG_
            printf("add bit %u\n",bit_best);
            printf("max=%u\n",max_old);
#endif
            fprintf(fp,"i=%u:get bit %u\n",i,bit_best);
        }
#if _DEBUG_
        printf("current bitstring:");
        fprintf(fp,"current bitstring:");
        for (k=0;k<i+1;k++) {
            printf("%u ",bitstring_tmp[k]);
            fprintf(fp,"%u ",bitstring_tmp[k]);
        }
        printf("\n");
        fprintf(fp,"\n");
#endif
    }
    SortNumArray(bitstring_tmp,len_bitstring);
    max_curr=SplitSpace(pfiltset,bitstring_tmp,len_bitstring,pblock); //store rules into pblock
    CpyNumArray(bitstring_tmp,bitstring,len_bitstring);
#if _DEBUG_
    printf("final bitstring:");
    fprintf(fp,"Get final bitstring:");
    for (k=0;k<len_bitstring;k++) {
        printf("%u ",bitstring_tmp[k]);
        fprintf(fp,"%u ",bitstring_tmp[k]);
    }
    printf("\n");
    fprintf(fp,"\n");
    printf("max subspace=%u\n",max_curr);
    fprintf(fp,"max subspace=%u\n",max_curr);
#endif
#if _DEBUG_
    printf("BuildBitstring3 end.\n");
#endif
    fclose(fp);
    return 1;
}



/**
 * copy array content to another.
 * \param array_src the source array
 * \param array_dst the destination array
 * \param num number of units to copy
 */
static void CpyNumArray(U32 *array_src,U32 *array_dst,U32 num)
{
    memcpy(array_dst,array_src,num*sizeof(U32));
/*
    U32 i = 0;
    for (i=0;i<num;i++) {
        array_dst[i] = array_src[i];
    }
    */
}

int cmp(const void *a, const void *b)
{
    return(*(int *)a-*(int *)b);
}

/**
 * sort numbers in array incrementally.
 * \param array the array to sort
 * \param len the length of array
 */
static void SortNumArray(U32 *array,U32 len)
{
    if(len<=1) return;
    qsort(array,len,sizeof(array[0]),cmp);
    /*
    U32 i=0,j=0,tmp=0;
    for (i=0;i<len-1;i++) {
        for (j=i+1;j<len;j++) {
            if (array[i]>array[j]){
                tmp = array[i];
                array[i] = array[j];
                array[j] = tmp;
            }
        }
    }
    */
}

/**
 * test if the id already exsited in bitstring.
 * \param id the id to test
 * \param bitstring the bitstring to search in
 * \param len_bitstring the length of bitstring
 * \return 1 if found, else 0
 */
static int FindID(U32 id,U32 *bitstring,U32 len_bitstring)
{
    U32 i=0;
    if (len_bitstring>0) {
        for (i=0;i<len_bitstring;i++) {
            if (id==bitstring[i])
                return 1;
        }
    }
    return 0;
}

/**
 * set the valud to given segment.
 * \param pSeg the seg pointer
 * \param start the start point
 * \param end the end point
 * \param rule_id the rule_id to set
 * \param next the next pointer
 * \param numSeg the number of current segs in list
 */
static void SetSeg(PRuleSeg pSeg,U32 start,U32 end,U32 rule_id,PRuleSeg*next,U32 numSeg)
{
    pSeg->start=start;
    pSeg->end=end;
    pSeg->rule_id=rule_id;
    pSeg->next=next;
    if (numSeg!=-1)
        pSeg->numSeg=numSeg;
}

void PrintList(PRuleSeg pSeg)
{
    while(pSeg!=NULL){
        printf("[%u,%u] ",pSeg->start,pSeg->end);
        pSeg = pSeg->next;
    }
    printf("\n");
}

/**
 * Add each rule to build the rule segment list.
 * \param pRuleSegHdr the header
 * \param pfilter the rule
 */
static void InsertRule(PRuleSeg pRuleSegHdr,pFilter pfilter,U16 dim)
{
    U32 mask,start,end;
    PRuleSeg pSegcur=NULL;
    PRuleSeg pSegnxt=NULL;
    if (dim>=0 && dim<=1) { //ip range
        if (pfilter->len[dim]==0)
            mask=0xffffffff;
        else 
            mask = (1<<(32-pfilter->len[dim]))-1;
        start = pfilter->ipHEX[dim];
        end = pfilter->ipHEX[dim]|mask;
    } else if (dim>=2 && dim<=3){ //port range
        start=pfilter->fromPort[dim-2];
        end=pfilter->toPort[dim-2];
    }else if(dim==4){ //proto
        if (pfilter->protLen==0) {
            start = 0;
            end = 0xff;
        } else {
            start = pfilter->protPref;
            end = pfilter->protPref;
        }
    }else{
        printf("Dim error,dim=%u\n",dim);
    }
#if _DEBUG_DETAIL_
    printf("mask=0x%x, rule range=[%u,%u]\n",mask,start,end);
#endif

    if (pRuleSegHdr->numSeg==0) { //no rule yet
        SetSeg(pRuleSegHdr,start,end,pfilter->cost,NULL,1);
        return;
    } 

    //check the start point
    pSegcur = pRuleSegHdr;
    while (pSegcur!=NULL) { //find a good segment
        if (start<=pSegcur->end) {
            break;
        }
        pSegcur = pSegcur->next;
    }
    if (pSegcur==NULL) { //no suitable rule found
        printf(">>Error, could not find suitable rulecurr.\n");
        return;
    } 

    pSegnxt=pSegcur->next;
    if (end <= pSegcur->end) {//contained in one seg, only check the start point
#if _DEBUG_DETAIL_
        printf("One Seg found[%u,%u], insert[%u,%u].\n",pSegcur->start,pSegcur->end,start,end);
#endif
        if (start==pSegcur->start && end==pSegcur->end) { //exactly match
            SetSeg(pSegcur,pSegcur->start,pSegcur->end,pfilter->cost,pSegnxt,-1);
        } else if (start>pSegcur->start && end<pSegcur->end){ //both intercut
            pSegcur->next = (PRuleSeg)malloc(sizeof(RuleSeg));
            pSegcur->next->next = (PRuleSeg)malloc(sizeof(RuleSeg));
            SetSeg(pSegcur->next->next,end+1,pSegcur->end,pSegcur->rule_id,pSegnxt,-1);
            SetSeg(pSegcur->next,start,end,pfilter->cost,pSegcur->next->next,-1);
            SetSeg(pSegcur,pSegcur->start,start-1,pSegcur->rule_id,pSegcur->next,-1);
#if _DEBUG_DETAIL_
            printf("Seg inc 2\n");
            PrintList(pRuleSegHdr);
#endif
            pRuleSegHdr->numSeg += 2;
        } else if (start==pSegcur->start && end<pSegcur->end) {//first half intercut
            pSegcur->next = (PRuleSeg)malloc(sizeof(RuleSeg));
            SetSeg(pSegcur->next,end+1,pSegcur->end,pSegcur->rule_id,pSegnxt,-1);
            SetSeg(pSegcur,start,end,pfilter->cost,pSegcur->next,-1);
#if _DEBUG_DETAIL_
            printf("Seg inc 1\n");
            PrintList(pRuleSegHdr);
#endif
            pRuleSegHdr->numSeg ++;
        } else if (start>pSegcur->start && end==pSegcur->end) {//last half intercut
            pSegcur->next = (PRuleSeg)malloc(sizeof(RuleSeg));
            SetSeg(pSegcur,pSegcur->start,start-1,pSegcur->rule_id,pSegcur->next,-1);
            SetSeg(pSegcur->next,start,end,pfilter->cost,pSegnxt,-1);
#if _DEBUG_DETAIL_
            printf("Seg inc 1\n");
            PrintList(pRuleSegHdr);
#endif
            pRuleSegHdr->numSeg ++;
        }
    } else { //cover more than one seg, check the start and end point
#if _DEBUG_DETAIL_
        printf("More than one Seg found[%u,%u], insert[%u,%u].\n",pSegcur->start,pSegcur->end,start,end);
#endif
#if _DEBUG_DETAIL_
        printf("Check the start point\n");
#endif
        //check the start point
        if (start==pSegcur->start) { //
            SetSeg(pSegcur,pSegcur->start,pSegcur->end,pfilter->cost,pSegnxt,-1);
        } else if (start>pSegcur->start) { //
            pSegcur->next = (PRuleSeg)malloc(sizeof(RuleSeg));
            SetSeg(pSegcur,pSegcur->start,start-1,pSegcur->rule_id,pSegcur->next,-1);
            SetSeg(pSegcur->next,start,end,pfilter->cost,pSegnxt,-1);
#if _DEBUG_DETAIL_
            printf("Seg inc 1\n");
            PrintList(pRuleSegHdr);
#endif
            pRuleSegHdr->numSeg ++;
        }
        pSegcur = pSegnxt;
#if _DEBUG_DETAIL_
        printf("Check the end point\n");
        printf("currSeg is [%u,%u]\n",pSegcur->start,pSegcur->end);
#endif
        //check the end point
        while (pSegcur!=NULL) { //find a good segment
            if (end<=pSegcur->end) {
                break;
            }
            pSegcur = pSegcur->next;
        }
        if (pSegcur==NULL) { //no suitable rule found
            printf(">>Error, could not find suitable rulecurr.\n");
            return;
        } else {
#if _DEBUG_DETAIL_
            printf(">>found suitable rulecurr [%u,%u].\n",pSegcur->start,pSegcur->end);
#endif
        }
        pSegnxt=pSegcur->next;
        if (end==pSegcur->end) { //
            SetSeg(pSegcur,pSegcur->start,pSegcur->end,pfilter->cost,pSegnxt,-1);
        } else { //end < pSegcur->end
            pSegcur->next = (PRuleSeg)malloc(sizeof(RuleSeg));
            SetSeg(pSegcur->next,end+1,pSegcur->end,pSegcur->rule_id,pSegnxt,-1);
            SetSeg(pSegcur,start,end,pfilter->cost,pSegcur->next,-1);
#if _DEBUG_DETAIL_
            printf("Seg inc 1\n");
            PrintList(pRuleSegHdr);
#endif
            pRuleSegHdr->numSeg ++;
        }
    }
}

/**
 * split the space with rules, and get the matched rule for each subspace.
 */
static U64 GetSubSpaceNum(pFiltSet pfiltset)
{
    U32 **segMatrix=NULL;
    U32 numSeg[5];
    U64 productSeg=1;
    U32 i=0,j=0;
    PRuleSeg pRuleSegHdr[5];
    for (i=0;i<5;i++) {
        pRuleSegHdr[i] = (PRuleSeg)malloc(sizeof(RuleSeg));
        if (i>=0 && i<=1) { //ip range
            SetSeg(pRuleSegHdr[i],0,0xffffffff,-1,NULL,1);
        } else if(i>=2 && i<=3){ //port range
            SetSeg(pRuleSegHdr[i],0,0xffff,-1,NULL,1);
        } else if(i==4){ //proto
            SetSeg(pRuleSegHdr[i],0,0xff,-1,NULL,1);
        }
    }

    /*Check each rule to get the cut point number for the two first dimensions*/
    pFilter pfilter;
    for (i=0;i<pfiltset->numFilters;i++) {
        pfilter = &pfiltset->filtArr[i];
#if _DEBUG_DETAIL_
        printf("Insert rule src %u\n",i);
#endif
        for (j=0;j<5;j++) {
#if _DEBUG_DETAIL_
        printf("check dim %u\n",j);
#endif
            InsertRule(pRuleSegHdr[j],pfilter,j);
        }
    }
    for (i=0;i<5;i++) {
        numSeg[i] = pRuleSegHdr[i]->numSeg;
        productSeg *= (U64)numSeg[i];
#if _DEBUG_DETAIL_
        printf("productSeg=%llu\n",productSeg);
#endif
    }
#if _DEBUG_DETAIL_
    printf("Segments and product:\n%u %u %u %u %u %llu\n",numSeg[0],numSeg[1],numSeg[2],numSeg[3],numSeg[4],productSeg);
#endif
    /*free the temp memory*/
    PRuleSeg pseg,psegnxt=NULL;
    for (i=0;i<5;i++) {
        pseg=pRuleSegHdr[i];
        while (pseg!=NULL){
            psegnxt = pseg->next;
            free(pseg);
            pseg = psegnxt;
        }
    }
    return productSeg;
    segMatrix = (U32**)malloc(sizeof(U32*)*numSeg[0]);
    for (i=0;i<numSeg[0];i++) {
        segMatrix[i] = (U32*)malloc(sizeof(U32)*numSeg[1]);
        memset(segMatrix+i,0,sizeof(U32)*numSeg[1]);
    }
}

/**
 * split the space into subspaces with a given bitstring.
 * \param pfiltset the global ruleset
 * \param bitstring the bitstring given
 * \param len_bitstring length of the bitstring
 * \param pblock the blocks to store rule ids
 * \return size of largest block after spliting
 */
static U64 SplitSpace(pFiltSet pfiltset,U32 *bitstring,U32 len_bitstring,PBLOCK pblock)
{
    U32 i=0;
    /*init the pblock*/
    for (i=0;i<(1<<len_bitstring);i++){
        pblock[i].num_rule=0;
        pblock[i].num_subspace=0;
        if (pblock[i].rule_list!=NULL) {
            free(pblock[i].rule_list);
            pblock[i].rule_list=NULL;
        }
        if (len_bitstring>10) {//we think 10 bits can split into lessthan-MAX_BLOCK_SIZE subsets
            pblock[i].rule_list=(U32*)malloc(sizeof(U32)*MAX_BLOCK_SIZE);
        } else {
            pblock[i].rule_list=(U32*)malloc(sizeof(U32)*pfiltset->numFilters);
        }
    }

    for (i=0;i<pfiltset->numFilters;i++){
        SplitFilter(pfiltset->filtArr+i,bitstring,len_bitstring,pblock);
    }
    return GetMaxSubSpaceNum(pblock,1<<len_bitstring,pfiltset);
}


