/*
 * DDBS v1.0 : The source code for the DDBS Algorithm
 * Copyright (C) 2007- Tsinghua NSLab
 * Authors: Baohua Yang<yangbaohua@gmail.com> 
 * Last Modified: 2010/04/19
 * Create Time: 2010/04/19
 */

#include"ClassBenchv2.h"

#ifndef __F_H__
#define __F_H__

//#define fatal(x, args...)  do { printf(x, ## args); exit(1); } while(0)
#define bug_on(x) do { if ((x)) { printf("** BUG at line %d\n" , __LINE__); }} while (0)

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif
#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif


#define METHOD_BS_INIT 0 //method to init bitstring: 0 for mannually setting, 1 for randomly generating
#define METHOD_BS_BUILD 2 //method to get bitstring: 0 for splitting with the given one, 1 for greedy, 2 for HS, 3 for testing the subspace principle
#define ACL_OP

#define NUM_BIT_HDR 104
#define LEN_BITSTRING 10 //length of the bitstring
#define MAX_BLOCK_SIZE 320 //max rule number stored in one block
/* globle variables */
typedef unsigned char   U8;
typedef unsigned short  U16;
typedef unsigned int  U32;
typedef unsigned long long U64;

typedef struct INFO_STAT_T{
    U8 id;
    U32 num_rule_0;
    U32 num_rule_1;
    U32 num_rule_x;
    U32 *rule_list0;
    U32 *rule_list1;
}INFO_STAT;
typedef INFO_STAT* PINFO_STAT;

/*struct of the S-block unit*/
typedef struct BLOCK_T{
    U32 num_rule;
    U64 num_subspace;
    U32 *rule_list;
}BLOCK;

typedef struct RULESEG{
    U32 start;
    U32 end;
    U32 rule_id;
    struct RULESEG *next;
    U32 numSeg; //seg number of the whole list
}RuleSeg;
typedef RuleSeg *PRuleSeg;

typedef BLOCK* PBLOCK;
void DDBSInit(pFiltSet pfiltset);
int DDBSSearch(U32 dest, U32 source, U32 sp, U32 dp, unsigned char pr);

#endif

