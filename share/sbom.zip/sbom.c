#include "sbom.h"

#define CHECK 0

static int max_memory=0;


/*
*     malloc memory function
*/ 
static void * SBOM_MALLOC (int n) 
{
	void *p;
	p = malloc (n);
	if (p)
		max_memory += n;
	return p;
}

void GetMem( int * memnum)
{
	*memnum=max_memory/1024;
}

/************************************************************************/
/* Queue Operation Function from Snort AC Algorithm                     */
/************************************************************************/

//Simple QUEUE NODE 
typedef struct _qnode
{
	int state;
	struct _qnode *next;
}QNODE;

//Simple QUEUE Structure 
typedef struct _queue
{
	QNODE * head, *tail;
	int count;
}QUEUE;

//Queue Init Operation
static void queue_init (QUEUE * s) 
{
	s->head = s->tail = 0;
	s->count = 0;
}


//Queue Add Operation
static void queue_add (QUEUE * s, int state) 
{
	QNODE * q;
	if (!s->head)
    {
		q = s->tail = s->head = (QNODE *) SBOM_MALLOC (sizeof (QNODE));
//		MEMASSERT (q, "queue_add");
		q->state = state;
		q->next = 0;
    }
	else
    {
		q = (QNODE *) SBOM_MALLOC (sizeof (QNODE));
//		MEMASSERT (q, "queue_add");
		q->state = state;
		q->next = 0;
		s->tail->next = q;
		s->tail = q;
    }
	s->count++;
}


//Queue Remove Operation
static int queue_remove (QUEUE * s) 
{
	int state = 0;
	QNODE * q;
	if (s->head)
    {
		q = s->head;
		state = q->state;
		s->head = s->head->next;
		s->count--;
		if (!s->head)
		{
			s->tail = 0;
			s->count = 0;
		}
//		AC_free (q);
		free(q);
    }
	return state;
}


//Queue Count Operation
static int queue_count (QUEUE * s) 
{
	return s->count;
}


//Queue Free Operation
static void queue_free (QUEUE * s) 
{
	while (queue_count (s))
    {
		queue_remove (s);
    }
}


#if defined(SAVE_STATE)

void SaveState(void* vp, FILE* fp)
{
	SBOM_Machine* sbom = (SBOM_Machine*)vp;
	int j,i=0;
	PatternList* p;
	
	fprintf(fp,"SBOM INFO\n");
	for(i=0;i<sbom->num_state;i++)
	{
		fprintf(fp,"\n----state: %d----\n",i);
		fprintf(fp,"state->end:%d\n",sbom->state[i].state_id);
		fprintf(fp,"supply link:%d\n",sbom->state[i].supplyNode);
		for(j=0;j<256;j++)
		{
			if(sbom->state[i].nextNode[j]!=-1)
			{
				fprintf(fp,"next[%c]=%d\n",j,sbom->state[i].nextNode[j]);
			}
		}
		
		p=sbom->state[i].pat;
		if(p)
		{			
			fprintf(fp,"pattern:{");
			while(p)
			{
				for(j=0;j<p->n;j++)
					fprintf(fp,"%c",p->pattern[j]);
				fprintf(fp,",");
				p=p->next;
			}
			fprintf(fp,"}\n");
		}
	}
	
}

void SaveSbom(SBOM_Machine *sbom, char* file)
{
	int i = 0;
	
	FILE* fp = fopen(file,"w");
	
	SaveState(sbom,fp);
	
	fclose(fp);
}
#endif


/************************************************************************/
/* STATIC FUNCTION IMPLEMENTATION                                                                 */
/************************************************************************/

static void BFSTraverse(SBOM_Machine* sbom, int (*visit)(void* p,int n))
{
	unsigned char* visited=NULL;
	int u,w,v=0;
	int i = 0;
	QUEUE Q, *q=&Q;

	visited = (unsigned char*)SBOM_MALLOC(sbom->num_state);
	memset(visited,0,sbom->num_state);
	queue_init(q);

	for(v=0;v<sbom->num_state;v++)
	{
		if(visited[v]==0){
			visited[v]=1;
			visit(sbom,v);
			queue_add(q,v);


			while(queue_count(q)>0)
			{
				u=queue_remove(q);
				
				for(i=0;i<256;i++)
				{
					if(w=sbom->state[u].nextNode[i]!=-1)		
					{
						if(visited[w]==0)
						{
							visited[w]=1;
							visit(sbom,w);
							queue_add(q,w);
						}
					}
					
				}
			}
		}
	}



	queue_free(q);
	free(visited);

}


static unsigned char* SBOM_Reverse(unsigned char *pat,int n)
{
	unsigned char *ch = NULL;
	int i = 0;
	
	ch = (unsigned char*)SBOM_MALLOC(n);

	for(i=0; i<n;i++)
	{
		ch[n-1-i]=pat[i];
	}

	return ch;

}

//use len min of patterns to build trie
static void AddPatternTrie(SBOM_Machine* sbom, PatternList* pat)
{
	int i = 0;
	unsigned char* p ,*h= NULL;
	unsigned int state=0, next,n;
	PatternList *pt = NULL;
	
	n=0;

	sbom->state[0].state_id = 0;


	while (pat)
	{
	
		state = 0;
		/*reserve pattern*/
		h=p = SBOM_Reverse(pat->pattern,pat->n);
		i=sbom->lmin;
		p=h+pat->n-sbom->lmin;
		
		for (; i > 0; p++, i--)
		{	
			next = sbom->state[state].nextNode[*p];
		
			if(next==-1)
				break;
		
			state = next;
		}
		//
		for (; i > 0; p++, i--)
		{
			sbom->num_state++;
			sbom->state[state].nextNode[*p] = sbom->num_state;
			sbom->state[sbom->num_state].state_id =sbom->num_state;
			state=sbom->num_state;
			
		}

		pt = (PatternList*)SBOM_MALLOC(sizeof(PatternList));
		memcpy(pt,pat,sizeof(PatternList));
		pt->next=sbom->state[state].pat;
		sbom->state[state].pat=pt;
		free(h);
		h=NULL;
		p=NULL;
		pat=pat->next;
		
	}
	
	sbom->num_state++;

}



//Travel Factor Oracle
static int TravelOracle(void* pv,int state)
{
	int i;
	int par,cur,down;
	SBOM_Machine* sbom=(SBOM_Machine*)pv;

	par = state;


	for(i=0;i<256;i++)
	{
		cur = sbom->state[par].nextNode[i];
		
		if(cur==-1)
			continue;
		down = sbom->state[par].supplyNode;
		
		while(down!=-1&&sbom->state[down].nextNode[i]==-1)
		{
				sbom->state[down].nextNode[i]=cur;
				down=sbom->state[down].supplyNode;
		}
					
		if(down !=-1)
		{
			sbom->state[cur].supplyNode = sbom->state[down].nextNode[i];
		}
		else
		{
			sbom->state[cur].supplyNode = 0;
		}
					
	}
	
	return 0;
}


void* SBOM_New()
{
	SBOM_Machine* sbom = (SBOM_Machine*)SBOM_MALLOC(sizeof(SBOM_Machine));
	if(!sbom)
		return NULL;
	memset(sbom,0,sizeof(SBOM_Machine));
	return sbom;
}

void  SBOM_Free(void*sb)
{
	int i = 0;
	PatternList* p,*t;

	SBOM_Machine* sbom = (SBOM_Machine*)sb;

	for(i=0;i<sbom->max_state;i++)
	{
		p = sbom->state[i].pat;

		while(p)
		{
			t = p->next;
			memset(p,0,sizeof(PatternList));
			free(p);
			p = t;
		}

		memset(&sbom->state[i],0,sizeof(SBOM_State));
	}
	free(sbom->state);
	sbom->state = NULL;

	p = sbom->pat;
	while(p)
	{
		t = p->next;
	//	free(p->pattern);
		memset(p,0,sizeof(PatternList));		
		free(p);
		p = t;
	}



	free(sbom);

}

int SBOM_Preproccess(void* par1, void*pv)
{
	SBOM_Machine* sbom = (SBOM_Machine*)par1;
	PatternList *list,* p = (PatternList*)pv;
	SBOM_State* root=sbom->state;
	int lmin = 32768;
	int lmax = 0;
	int i = 0;
	sbom->max_state = 0;
	list = p;

	sbom->pat = p;
	
	//find pattern min len and max len, max states
	while(p)
	{
		if(p->n<lmin)
			lmin = p->n;
		if(p->n>lmax)
			lmax = p->n;
		
		sbom->total_pattern_bytes+=p->n;
		p=p->next;
		sbom->num_pat++;

	}
	sbom->lmin = lmin;
	sbom->lmax = lmax;
	sbom->max_state = sbom->lmin* sbom->num_pat;

	sbom->state = (SBOM_State*)SBOM_MALLOC(sbom->max_state*sizeof(SBOM_State));

	memset(sbom->state,-1,sbom->max_state*sizeof(SBOM_State));

	for(i=0;i<sbom->max_state;i++)
	{
		sbom->state[i].pat=NULL;
	}
	//build trie
	p=list;

	AddPatternTrie(sbom,p);

	root = sbom->state;

	sbom->state[0].supplyNode=-1;
	// build oracle

	BFSTraverse(sbom,TravelOracle);

#if defined(SAVE_STATE)	
	SaveSbom(sbom,"sbom.txt");
#endif
	return sbom->num_pat;
}

/*
int   SBOM_Search(void* vp,unsigned char * T, int m, int ( *callback )( void *data,int), void * data )
{
	SBOM_MachineS* sbom = (SBOM_MachineS*)vp;
	int i,pos ,j=0;
	unsigned char* Tx = (unsigned char* )data;
	int root, cur;
	PatternListS* list;
	int nfound = 0;
	int n = T-Tx;
	int id = 0;
	root = 0;// sbom->state;
	pos=0;
	
	while(pos<=m-sbom->lmin)
	{
		
		j =sbom->lmin-1;
		cur=root;
		
		while(j>=0&&cur!=-1)
		{

			cur = sbom->state[cur].nextNode[T[pos+j]];
			
			j--;
		}
		
		
		if(cur!=-1 && j<=0)
		{
			for(i=0;i<sbom->state[cur].pat_num;i++)
			{
				list = (PatternListS*)&sbom->pat[sbom->state[cur].match_start+i];
				
				if(list->psLen==sbom->lmin)
				{
					/*if(callback)
					{
						callback(list,pos);
					}*/
					
					nfound++;
				}
				else //if(n-pos >=list->psLen)
				{
					
					if(memcmp(&T[pos+sbom->lmin],&(list->psPat[sbom->lmin]),list->psLen-sbom->lmin)==0)
					{
						/*if(callback)
						{
							callback(list,pos);
						}*/						
						nfound++;
						
					}
				}
			}
			
			j=1;
		}
		
		if(j<=0)
			j=1;
		
		
		pos=pos+j;
	}
	
	return nfound;
}
*/

int   SBOM_Search1(void* vp,unsigned char * T, int m, int ( *callback )( void *data,int), void * data )
{
	SBOM_Machine* sbom = (SBOM_Machine*)vp;
	int pos ,j=0;
	unsigned char* Tx = (unsigned char* )data;
	int root, cur;
	PatternList* list;
	int nfound = 0;
	int n = T-Tx;
	int id = 0;
	root = 0;// sbom->state;
	pos=0;
//	printf("search set back oracle machine\n");
	
	while(pos<=m-sbom->lmin)
	{
		
		j =sbom->lmin-1;
		cur=root;
		
		while(j>=0 && cur!=-1)
		{

			cur = sbom->state[cur].nextNode[T[pos+j]];
			
			j--;
		}
		
		
		if(cur!=-1 && j<=0)
		{
			list = sbom->state[cur].pat;
			while(list)
			{
				
				
				if(list->n==sbom->lmin)
				{
					if(callback)
					{
						callback(list,pos);
					}
					
					nfound++;
				}
				else //if(n-pos >=list->psLen)
				{
					
					if(memcmp(&T[pos+sbom->lmin],&(list->pattern[sbom->lmin]),list->n-sbom->lmin)==0)
					{
						if(callback)
						{
							callback(list,pos);
						}						
						nfound++;
						
					}
				}

				list = list->next;
			}
			
			j=1;
		}
		
		if(j<=0)
			j=1;
		
		
		pos=pos+j;
	}
	
	return nfound;
}


int SBOM_Save(void* vp, char* file)
{
	FILE* fp =NULL;
	PatternList* pat;
//	SBOM_State* state;
	int len,i = 0;
	int  num = 0;
	int string_id = 0;
	int start = 0;
	int num_patterns = 0;
	SBOM_Machine* sbom=(SBOM_Machine*)vp;

	len = 0;

	if(!file||!sbom)
		return -1;

	fp= fopen(file,"wb");

	if(!fp)
		return -1;


	fwrite(&sbom->lmin,sizeof(int),1,fp);//4byte
	fwrite(&sbom->lmax,sizeof(int),1,fp);//4byte
	fwrite(&sbom->num_state,sizeof(int),1,fp);//4byte
	fwrite(&sbom->total_pattern_bytes,sizeof(int),1,fp);//write pattern data length = 0 first , we will modified it later.
	fwrite(&sbom->num_pat,sizeof(int),1,fp);//number of patterns

	/************************************************************************
	 --state save structure--:
	 next_node[0..256]: next_nod_num*4bytes
	 pattern_start: 4byte
	 pattern_num: 4byte
	 pattern[0].len: 4byte
	 pattern[0].data: pattern[0].len bytes
	 ...
	 pattern[num].len: 4byte
	 pattern[num].data: pattern[num].len bytes
	 --end---
	************************************************************************/
	for(i=0;i<sbom->num_state;i++)
	{
		len = 0;


		//next states
		fwrite(&sbom->state[i].nextNode[0],sizeof(int),256,fp);//save next node

		pat = sbom->state[i].pat;
		start = string_id;

		while(pat)
		{
			string_id++;
			pat=pat->next;
		}

		num = string_id - start;
		fwrite(&start,sizeof(int),1,fp);
		fwrite(&num,sizeof(int),1,fp);
		pat = sbom->state[i].pat;

		while(pat)
		{
			fwrite(&pat->n,sizeof(int),1,fp);
			fwrite(&pat->id,sizeof(int),1,fp);
			fwrite(pat->pattern,pat->n,1,fp);
			pat = pat->next;
		}
	}

	fclose(fp);

	return 0;
}

void* SBOM_Load(char* file)
{
	FILE* fp;
	SBOM_MachineS* sbom=NULL;
//	SBOM_StateS* state;
//	PatternListS* pat;
	unsigned char* line = NULL;
	int len;
	unsigned int id;
	int j,i = 0;



	sbom = (SBOM_MachineS*)SBOM_MALLOC(sizeof(SBOM_MachineS));
	memset(sbom,0,sizeof(SBOM_MachineS));

	if(!sbom||!file)
		return NULL;

	fp = fopen(file,"rb");

	if(!fp)
	{
		return NULL;
	}

	fread(&sbom->lmin,sizeof(int),1,fp);
	fread(&sbom->lmax,sizeof(int),1,fp);
	fread(&sbom->num_state,sizeof(int),1,fp);
	fread(&sbom->max_state,sizeof(int),1,fp);//pattern length
	fread(&sbom->num_pat,sizeof(int),1,fp);
	//ALLOC pattern struct 
	sbom->pat = (PatternListS*)SBOM_MALLOC(sizeof(PatternListS)*sbom->num_pat);

	if(!sbom->pat)
	{
		free(sbom);
		sbom=NULL;
		fclose(fp);
		return NULL;
	}
	//alloc state 
	sbom->state = (SBOM_StateS*)SBOM_MALLOC(sizeof(SBOM_StateS)*sbom->num_state);

	if(!sbom->state)
	{

		free(sbom->pat);
		free(sbom);
		sbom=NULL;
		fclose(fp);
		return NULL;
	}


	sbom->pat_data = (unsigned char*)SBOM_MALLOC(sbom->max_state);

	if(!sbom->pat_data)
	{
		free(sbom->state);
		free(sbom->pat);
		free(sbom);
		sbom=NULL;
		fclose(fp);
		return NULL;
	}

	memset(sbom->pat_data,sbom->max_state,0);
	memset(sbom->pat,0,sizeof(PatternListS)*sbom->num_pat);
	memset(sbom->state,0,sizeof(SBOM_StateS)*sbom->num_state);
	/************************************************************************
	 --state save structure--:
	 next_node[0..256]: 256*4bytes
	 pattern_start: 4byte
	 pattern_num: 4byte
	 pattern[0].len: 4byte
	 pattern[0].data: pattern[0].len bytes
	 ...
	 pattern[num].len: 4byte
	 pattern[num].data: pattern[num].len bytes
	 --end---
	************************************************************************/
	line = (unsigned char*)&sbom->pat_data[0];
	
	for(i=0;i<sbom->num_state;i++)
	{
		fread(&sbom->state[i].nextNode[0],sizeof(int)*256,1,fp);//read next states
		fread(&sbom->state[i].match_start,sizeof(int),1,fp);//read start of pattern id
		fread(&sbom->state[i].pat_num,sizeof(int),1,fp);// read num of patterns

		for(j=0;j<sbom->state[i].pat_num;j++)
		{
			fread(&len,sizeof(int),1,fp);//len of each pattern
			fread(&id,sizeof(int),1,fp);
			fread(line,len,1,fp);// read data of pattern
			sbom->pat[sbom->state[i].match_start + j].psLen = len;//set len
			sbom->pat[sbom->state[i].match_start + j].id = id;//set len
			sbom->pat[sbom->state[i].match_start + j].psPat = line;//set pattern entries
			line+=len;
		}
	}

	fclose(fp);

	return (void*)sbom;
}

void SBOM_Release(void* vp)
{
	SBOM_MachineS* sbom = (SBOM_MachineS*)vp;
	int i = 0;

	if(!sbom)
		return;

	if(sbom->pat_data)
		free(sbom->pat_data);
	if(sbom->pat)
		free(sbom->pat);
	if(sbom->state)
		free(sbom->state);
	free(sbom);
	return;

}

/************************************************************************/
/* Example for test                                                             */
/************************************************************************/


int main(int argc, char *argv[])
{
	//
	SBOM_Machine * sbom;
	PatternList * plist;
	char * text;
	int tsize

	//prepare text (Read from file or manually set)
	//You should write ReadText(&tsize) by yourself, do forget to set tsize as the length of the text
	text=ReadText(&tsize);

	//prepare pattern set(Read from file or manually set)
	//You shold write InitPatternList () according to sbom.h and your patten set information
	plist=InitPatternList();
	
	//preprocess stage of SBOM
	sbom=(SBOM_Machine *)SBOM_New();
	SBOM_Preproccess(sbom,plist);
	
	//search stage of SBOM
	SBOM_Search1(sbom,text,tsize,NULL,NULL);
	
	//free SBOM data struture
	SBOM_Free(sbom);

	return 0;
}

