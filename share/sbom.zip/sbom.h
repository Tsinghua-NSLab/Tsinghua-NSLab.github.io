#ifndef _SBOM_H_
#define _SBOM_H_
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


/************************************************************************/
/* macros                                                               */
/************************************************************************/

//#define SBOM_ONLY

#define UNDEFINE	  -1
#define CHARSET_SIZE 256


/************************************************************************
	following data structures are used in prepare time
************************************************************************/
typedef struct SBOM_StateT
{
	int state_id ;
	PatternList * pat;
	int supplyNode;
	int nextNode[CHARSET_SIZE];
}SBOM_State;

typedef struct SBOM_MachineT
{
	int num_state;
	int max_state;
	int lmin;
	int lmax;
	int num_pat;
	int total_pattern_bytes;
	PatternList * pat;
	SBOM_State* state;
}SBOM_Machine;

/*---------------following data structures are used in search time-----------------*/

typedef struct PatternListST  {
	unsigned char *psPat;   // pattern array, case(exact)
	unsigned int  psLen;   // length of pattern in bytes
	unsigned int id;
} PatternListS;

typedef struct SBOM_StateST
{
	int match_start;
	int pat_num;
	int nextNode[CHARSET_SIZE];
}SBOM_StateS;

typedef struct SBOM_MachineST
{
	int num_state;
	int max_state;
	int lmin;
	int lmax;
	int num_pat;
	unsigned char* pat_data;
	PatternListS* pat;
	SBOM_StateS* state;
}SBOM_MachineS;


void* SBOM_New(void);
void GetMem(int * memnum);
void  SBOM_Free(void*sb);
int   SBOM_Preproccess(void* sbom, void*p);
int   SBOM_Search1 (void* vp,unsigned char * T, int n, int ( *match )( void *data,int), void * data );
// ---------------------------------------------------------------------------------------------------
int   SBOM_Save(void* sbom, char* file);
void* SBOM_Load(char* file);
int   SBOM_Search (void* vp,unsigned char * T, int n, int ( *match )( void *data,int), void * data );
void  SBOM_Release(void* sbom);
#endif
